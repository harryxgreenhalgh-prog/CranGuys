// CranGuys server entry point.  `npm start`  ->  http://localhost:8080
import fs from 'node:fs';
import path from 'node:path';
import { randomBytes } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { openStore } from './db.js';
import { Auth } from './auth.js';
import { Economy } from './economy.js';
import { WSServer } from './ws.js';
import { GameServer } from './gameserver.js';
import { createHttp } from './http.js';
import { MAX_PLAYERS, TIMING } from '../shared/config.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const env = process.env;
const cfg = {
  port: +(env.PORT || 8080),
  host: env.HOST || '0.0.0.0',
  dataDir: path.resolve(env.DATA_DIR || path.join(ROOT, 'data')),
  maxPlayers: Math.min(MAX_PLAYERS, +(env.MAX_PLAYERS || MAX_PLAYERS)),
  maxHumans: +(env.MAX_HUMANS || MAX_PLAYERS),
  lobbySecs: +(env.LOBBY_SECONDS || TIMING.lobbyOnline),
  botFill: env.BOT_FILL !== 'false',
  timeScale: Math.max(1, Math.min(20, +(env.TIME_SCALE || 1))), // test hook: simulate N ticks per tick
  corsOrigins: (env.CORS_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean),
};

function loadSecret() {
  if (env.CRANGUYS_SECRET && env.CRANGUYS_SECRET.length >= 16) return env.CRANGUYS_SECRET;
  const f = path.join(cfg.dataDir, 'secret.key');
  try { return fs.readFileSync(f, 'utf8').trim(); } catch {}
  const s = randomBytes(32).toString('hex');
  fs.mkdirSync(cfg.dataDir, { recursive: true });
  fs.writeFileSync(f, s, { mode: 0o600 });
  return s;
}

const log = {
  info: (...a) => console.log(new Date().toISOString(), ...a),
  warn: (...a) => console.warn(new Date().toISOString(), ...a),
  error: (...a) => console.error(new Date().toISOString(), ...a),
};

const store = await openStore(cfg.dataDir);
const secret = loadSecret();
const auth = new Auth(secret, store);
const econ = new Economy(store);
const roots = [['/shared/', path.join(ROOT, 'shared')], ['/', path.join(ROOT, 'client')]];

let gs;
const server = createHttp({ econ, auth, store, getGs: () => gs, cfg, roots, log });
const wss = new WSServer({ server, path: '/ws' }); // sockets are token-authenticated, any origin may connect
gs = new GameServer({ wss, auth, econ, store, cfg, log });

server.listen(cfg.port, cfg.host, () => {
  log.info(`CranGuys server listening on http://localhost:${cfg.port}  (store: ${store.kind}, max ${cfg.maxPlayers} per show, bots ${cfg.botFill ? 'on' : 'off'})`);
});

function shutdown(sig) {
  log.info(`${sig} — shutting down`);
  gs.stop(); wss.close(); server.close();
  setTimeout(() => { try { store.close(); } catch {} process.exit(0); }, 600).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

export { server, gs, store };
