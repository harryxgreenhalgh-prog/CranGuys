// CranGuys — minimal, dependency-free RFC 6455 WebSocket server.
// Supports text/binary, fragmentation, ping/pong keep-alive, close handshake, size limits and backpressure.
import { createHash } from 'node:crypto';
import { EventEmitter } from 'node:events';

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const OP = { CONT: 0, TEXT: 1, BIN: 2, CLOSE: 8, PING: 9, PONG: 10 };

export class WSServer extends EventEmitter {
  constructor({ server, path = '/ws', maxPayload = 64 * 1024, allowOrigin = null }) {
    super();
    this.path = path; this.maxPayload = maxPayload; this.allowOrigin = allowOrigin;
    this.clients = new Set();
    server.on('upgrade', (req, socket, head) => this.handleUpgrade(req, socket, head));
    this.pinger = setInterval(() => {
      for (const c of this.clients) {
        if (Date.now() - c.lastSeen > 35000) { c.terminate(); continue; }
        c.ping();
      }
    }, 15000);
    this.pinger.unref?.();
  }

  handleUpgrade(req, socket, head) {
    const url = new URL(req.url, 'http://x');
    const key = req.headers['sec-websocket-key'];
    const fail = (code, msg) => { socket.end(`HTTP/1.1 ${code} ${msg}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`); };
    if (url.pathname !== this.path) return fail(404, 'Not Found');
    if ((req.headers.upgrade || '').toLowerCase() !== 'websocket' || !key || req.headers['sec-websocket-version'] !== '13') return fail(400, 'Bad Request');
    if (this.allowOrigin && req.headers.origin && !this.allowOrigin(req.headers.origin)) return fail(403, 'Forbidden');
    const accept = createHash('sha1').update(key + GUID).digest('base64');
    socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n' + `Sec-WebSocket-Accept: ${accept}\r\n\r\n`);
    socket.setNoDelay(true);
    const ws = new WSConn(socket, this.maxPayload, req);
    this.clients.add(ws);
    ws.on('close', () => this.clients.delete(ws));
    if (head && head.length) ws.feed(head);
    this.emit('connection', ws, req);
  }

  close() { clearInterval(this.pinger); for (const c of this.clients) c.close(1001, 'server shutdown'); }
}

export class WSConn extends EventEmitter {
  constructor(socket, maxPayload, req) {
    super();
    this.socket = socket; this.maxPayload = maxPayload; this.req = req;
    this.buf = Buffer.alloc(0); this.frag = null; this.fragOp = 0; this.open = true; this.lastSeen = Date.now();
    this.ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || socket.remoteAddress;
    socket.on('data', (d) => this.feed(d));
    socket.on('close', () => this.finish());
    socket.on('error', () => this.finish());
  }
  get bufferedAmount() { return this.socket.writableLength; }

  feed(chunk) {
    this.lastSeen = Date.now();
    this.buf = this.buf.length ? Buffer.concat([this.buf, chunk]) : chunk;
    while (this.open) {
      const b = this.buf;
      if (b.length < 2) return;
      const fin = (b[0] & 0x80) !== 0, op = b[0] & 0x0f, masked = (b[1] & 0x80) !== 0;
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; const hi = b.readUInt32BE(2), lo = b.readUInt32BE(6); if (hi) return this.close(1009, 'too big'); len = lo; off = 10; }
      if (len > this.maxPayload) return this.close(1009, 'too big');
      if (!masked) return this.close(1002, 'unmasked client frame');
      if (b.length < off + 4 + len) return;
      const mask = b.subarray(off, off + 4); off += 4;
      const data = Buffer.allocUnsafe(len);
      for (let i = 0; i < len; i++) data[i] = b[off + i] ^ mask[i & 3];
      this.buf = b.subarray(off + len);
      this.frame(fin, op, data);
    }
  }

  frame(fin, op, data) {
    switch (op) {
      case OP.TEXT: case OP.BIN:
        if (this.frag) return this.close(1002, 'expected continuation');
        if (fin) return this.emit('message', op === OP.TEXT ? data.toString('utf8') : data, op === OP.BIN);
        this.frag = [data]; this.fragOp = op; return;
      case OP.CONT: {
        if (!this.frag) return this.close(1002, 'unexpected continuation');
        this.frag.push(data);
        const total = this.frag.reduce((n, x) => n + x.length, 0);
        if (total > this.maxPayload) return this.close(1009, 'too big');
        if (fin) { const all = Buffer.concat(this.frag); const bin = this.fragOp === OP.BIN; this.frag = null; this.emit('message', bin ? all : all.toString('utf8'), bin); }
        return;
      }
      case OP.PING: return this.write(OP.PONG, data);
      case OP.PONG: return;
      case OP.CLOSE: {
        const code = data.length >= 2 ? data.readUInt16BE(0) : 1005;
        if (this.open) { this.write(OP.CLOSE, data.subarray(0, 2)); }
        this.socket.end(); return this.finish(code);
      }
      default: return this.close(1002, 'bad opcode');
    }
  }

  write(op, payload) {
    if (!this.open || this.socket.destroyed) return false;
    const len = payload.length;
    let head;
    if (len < 126) { head = Buffer.allocUnsafe(2); head[1] = len; }
    else if (len < 65536) { head = Buffer.allocUnsafe(4); head[1] = 126; head.writeUInt16BE(len, 2); }
    else { head = Buffer.allocUnsafe(10); head[1] = 127; head.writeUInt32BE(0, 2); head.writeUInt32BE(len, 6); }
    head[0] = 0x80 | op;
    this.socket.cork(); this.socket.write(head); this.socket.write(payload); this.socket.uncork();
    return true;
  }

  send(data) {
    if (typeof data === 'string') return this.write(OP.TEXT, Buffer.from(data, 'utf8'));
    if (data instanceof Uint8Array) return this.write(OP.BIN, Buffer.isBuffer(data) ? data : Buffer.from(data.buffer, data.byteOffset, data.byteLength));
    return this.write(OP.TEXT, Buffer.from(JSON.stringify(data), 'utf8'));
  }
  ping() { this.write(OP.PING, Buffer.alloc(0)); }
  close(code = 1000, reason = '') {
    if (!this.open) return;
    const r = Buffer.from(String(reason).slice(0, 100)), p = Buffer.allocUnsafe(2 + r.length);
    p.writeUInt16BE(code, 0); r.copy(p, 2);
    this.write(OP.CLOSE, p);
    this.open = false;
    setTimeout(() => this.socket.destroy(), 500).unref?.();
    this.finish(code);
  }
  terminate() { this.socket.destroy(); this.finish(1006); }
  finish(code = 1006) {
    if (this.closed) return;
    this.closed = true; this.open = false;
    this.emit('close', code);
  }
}
