// CranGuys — accounts & economy service. All balance changes go through the ledger (idempotent refs),
// purchases are atomic transactions, and rewards are only ever computed server-side from match results.
import { CATALOG, itemById, DEFAULT_OWNED, DEFAULT_LOADOUT, START_BALANCE, sanitizeLoadout, dailyShop, computeRewards, levelForXp, LEVEL_UP_BONUS } from '../shared/cosmetics.js';
import { beanName } from '../shared/names.js';
import { newId, cleanDisplay } from './auth.js';

export class EconomyError extends Error { constructor(code, msg) { super(msg || code); this.code = code; } }

export class Economy {
  constructor(store) { this.store = store; }

  newGuest(display) {
    const id = newId();
    const name = cleanDisplay(display) || beanName(Math.random);
    this.store.tx(() => {
      this.store.createUser({ id, display: name, guest: true });
      this.store.createProfile(id, START_BALANCE, DEFAULT_LOADOUT);
      for (const it of DEFAULT_OWNED) this.store.grant(id, it, 'starter');
      this.store.credit(id, { kind: 'starter', ref: 'starter', berries: 0, crowns: 0, xp: 0 });
    });
    return this.store.userById(id);
  }

  profile(userId) {
    const u = this.store.userById(userId), p = this.store.getProfile(userId);
    if (!u || !p) throw new EconomyError('not_found', 'Profile not found');
    const owned = this.store.owned(userId);
    return {
      id: u.id, name: u.display, username: u.username, guest: !!u.guest,
      berries: p.berries, crowns: p.crowns, xp: p.xp, level: levelForXp(p.xp),
      wins: p.wins, shows: p.shows, finals: p.finals, rounds: p.rounds,
      owned: [...owned], loadout: sanitizeLoadout(p.loadout, owned),
    };
  }

  loadout(userId) { const p = this.store.getProfile(userId); return sanitizeLoadout(p && p.loadout, this.store.owned(userId)); }

  equip(userId, loadout) {
    const owned = this.store.owned(userId);
    for (const [slot, id] of Object.entries(loadout || {})) {
      if (id && !owned.has(id)) throw new EconomyError('not_owned', `You don't own ${itemById(id) ? itemById(id).name : id}`);
    }
    const clean = sanitizeLoadout({ ...this.loadout(userId), ...loadout }, owned);
    this.store.setLoadout(userId, clean);
    return this.profile(userId);
  }

  shop(now = new Date()) {
    const s = dailyShop(now);
    return { ...s, catalog: [s.featured, ...s.items].map((id) => itemById(id)) };
  }

  buy(userId, itemId, now = new Date()) {
    const it = itemById(itemId);
    if (!it) throw new EconomyError('bad_item', 'Unknown item');
    const s = dailyShop(now);
    if (itemId !== s.featured && !s.items.includes(itemId)) throw new EconomyError('not_in_shop', 'That item is not in today’s shop');
    this.store.tx(() => {
      if (this.store.owned(userId).has(itemId)) throw new EconomyError('owned', 'You already own this');
      const p = this.store.getProfile(userId);
      const cb = it.price.b || 0, cc = it.price.c || 0;
      if (p.berries < cb || p.crowns < cc) throw new EconomyError('funds', 'Not enough ' + (cb ? 'Cranberries' : 'Crowns'));
      this.store.credit(userId, { kind: 'purchase', ref: 'buy:' + itemId, berries: -cb, crowns: -cc, xp: 0 });
      this.store.grant(userId, itemId, 'shop');
    });
    return this.profile(userId);
  }

  rename(userId, display) {
    const d = cleanDisplay(display);
    if (!d) throw new EconomyError('bad_name', 'Names need 2–16 letters or numbers');
    this.store.setDisplay(userId, d);
    return this.profile(userId);
  }

  // Called by the authoritative game server when a player's show is over.
  reward(userId, res) {
    const r = computeRewards(res);
    let applied = false, levelUp = 0;
    this.store.tx(() => {
      const before = this.store.getProfile(userId);
      if (!before) return;
      applied = this.store.credit(userId, { kind: 'match', ref: 'match:' + res.matchId, berries: r.berries, crowns: r.crowns, xp: r.xp });
      if (!applied) return;
      this.store.addStats(userId, { wins: res.won ? 1 : 0, shows: 1, finals: res.rounds >= res.totalRounds - 1 ? 1 : 0, rounds: res.rounds });
      const l0 = levelForXp(before.xp), l1 = levelForXp(before.xp + r.xp);
      if (l1 > l0) {
        levelUp = l1;
        this.store.credit(userId, { kind: 'levelup', ref: 'level:' + l1, berries: LEVEL_UP_BONUS * (l1 - l0), crowns: 0, xp: 0 });
      }
      if (res.won && !this.store.owned(userId).has('h_crown') && before.wins === 0) this.store.grant(userId, 'h_crown', 'first-win'); // first win unlocks the Royal Crown
    });
    return { ...r, applied, levelUp, bonus: levelUp ? LEVEL_UP_BONUS : 0 };
  }
}
