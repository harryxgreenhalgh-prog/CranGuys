// CranGuys — persistence. Uses Node's built-in SQLite (node:sqlite, Node >= 22.5) with WAL + transactions.
// Falls back to an atomic JSON file store if SQLite is unavailable, behind the same interface.
import fs from 'node:fs';
import path from 'node:path';

const SCHEMA = `
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT UNIQUE COLLATE NOCASE,
  display TEXT NOT NULL,
  pass TEXT,
  guest INTEGER NOT NULL DEFAULT 1,
  token_ver INTEGER NOT NULL DEFAULT 1,
  created INTEGER NOT NULL,
  last_seen INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS profiles (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  berries INTEGER NOT NULL DEFAULT 0 CHECK (berries >= 0),
  crowns INTEGER NOT NULL DEFAULT 0 CHECK (crowns >= 0),
  xp INTEGER NOT NULL DEFAULT 0,
  wins INTEGER NOT NULL DEFAULT 0,
  shows INTEGER NOT NULL DEFAULT 0,
  finals INTEGER NOT NULL DEFAULT 0,
  rounds INTEGER NOT NULL DEFAULT 0,
  loadout TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS inventory (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  item_id TEXT NOT NULL,
  source TEXT NOT NULL,
  acquired INTEGER NOT NULL,
  PRIMARY KEY (user_id, item_id)
);
CREATE TABLE IF NOT EXISTS ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  berries INTEGER NOT NULL DEFAULT 0,
  crowns INTEGER NOT NULL DEFAULT 0,
  xp INTEGER NOT NULL DEFAULT 0,
  ref TEXT NOT NULL,
  ts INTEGER NOT NULL,
  UNIQUE (user_id, ref)
);
CREATE TABLE IF NOT EXISTS matches (
  id TEXT PRIMARY KEY,
  started INTEGER NOT NULL,
  ended INTEGER NOT NULL,
  rounds INTEGER NOT NULL,
  humans INTEGER NOT NULL,
  winner_name TEXT,
  winner_user TEXT,
  data TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_profiles_wins ON profiles(wins DESC);
CREATE INDEX IF NOT EXISTS idx_ledger_user ON ledger(user_id, ts DESC);
`;

class SqliteStore {
  constructor(DatabaseSync, file) {
    this.kind = 'sqlite';
    this.db = new DatabaseSync(file);
    this.db.exec(SCHEMA);
    const q = (s) => this.db.prepare(s);
    this.s = {
      insUser: q('INSERT INTO users (id, username, display, pass, guest, created, last_seen) VALUES (?, ?, ?, ?, ?, ?, ?)'),
      userById: q('SELECT * FROM users WHERE id = ?'),
      userByName: q('SELECT * FROM users WHERE username = ?'),
      setCred: q('UPDATE users SET username = ?, pass = ?, guest = 0, token_ver = token_ver + 1 WHERE id = ?'),
      setDisplay: q('UPDATE users SET display = ? WHERE id = ?'),
      touch: q('UPDATE users SET last_seen = ? WHERE id = ?'),
      insProfile: q('INSERT INTO profiles (user_id, berries, crowns, loadout) VALUES (?, ?, ?, ?)'),
      profile: q('SELECT * FROM profiles WHERE user_id = ?'),
      owned: q('SELECT item_id FROM inventory WHERE user_id = ?'),
      grant: q('INSERT OR IGNORE INTO inventory (user_id, item_id, source, acquired) VALUES (?, ?, ?, ?)'),
      setLoadout: q('UPDATE profiles SET loadout = ? WHERE user_id = ?'),
      ledgerHas: q('SELECT 1 FROM ledger WHERE user_id = ? AND ref = ?'),
      ledgerIns: q('INSERT INTO ledger (user_id, kind, berries, crowns, xp, ref, ts) VALUES (?, ?, ?, ?, ?, ?, ?)'),
      credit: q('UPDATE profiles SET berries = berries + ?, crowns = crowns + ?, xp = xp + ? WHERE user_id = ?'),
      stats: q('UPDATE profiles SET wins = wins + ?, shows = shows + ?, finals = finals + ?, rounds = rounds + ? WHERE user_id = ?'),
      insMatch: q('INSERT OR REPLACE INTO matches (id, started, ended, rounds, humans, winner_name, winner_user, data) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'),
      board: q(`SELECT u.display AS name, p.wins, p.crowns, p.xp, p.shows FROM profiles p JOIN users u ON u.id = p.user_id
                WHERE p.shows > 0 ORDER BY p.wins DESC, p.xp DESC LIMIT ?`),
      counts: q('SELECT (SELECT COUNT(*) FROM users) AS users, (SELECT COUNT(*) FROM matches) AS matches'),
      history: q('SELECT kind, berries, crowns, xp, ref, ts FROM ledger WHERE user_id = ? ORDER BY ts DESC LIMIT ?'),
    };
  }
  tx(fn) {
    this.db.exec('BEGIN IMMEDIATE');
    try { const r = fn(); this.db.exec('COMMIT'); return r; } catch (e) { try { this.db.exec('ROLLBACK'); } catch {} throw e; }
  }
  createUser(u) { this.s.insUser.run(u.id, u.username || null, u.display, u.pass || null, u.guest ? 1 : 0, Date.now(), Date.now()); }
  userById(id) { return this.s.userById.get(id) || null; }
  userByName(n) { return this.s.userByName.get(n) || null; }
  setCredentials(id, username, pass) { this.s.setCred.run(username, pass, id); }
  setDisplay(id, d) { this.s.setDisplay.run(d, id); }
  touch(id) { this.s.touch.run(Date.now(), id); }
  createProfile(id, bal, loadout) { this.s.insProfile.run(id, bal.berries, bal.crowns, JSON.stringify(loadout)); }
  getProfile(id) { const p = this.s.profile.get(id); if (!p) return null; return { ...p, loadout: JSON.parse(p.loadout) }; }
  owned(id) { return new Set(this.s.owned.all(id).map((r) => r.item_id)); }
  grant(id, item, source) { this.s.grant.run(id, item, source, Date.now()); }
  setLoadout(id, lo) { this.s.setLoadout.run(JSON.stringify(lo), id); }
  // idempotent ledger entry; returns false if this ref was already applied
  credit(id, { berries = 0, crowns = 0, xp = 0, kind, ref }) {
    if (this.s.ledgerHas.get(id, ref)) return false;
    this.s.ledgerIns.run(id, kind, berries, crowns, xp, ref, Date.now());
    this.s.credit.run(berries, crowns, xp, id);
    return true;
  }
  addStats(id, s) { this.s.stats.run(s.wins || 0, s.shows || 0, s.finals || 0, s.rounds || 0, id); }
  saveMatch(m) { this.s.insMatch.run(m.id, m.startedAt, m.endedAt, m.rounds, m.players.filter((p) => !p.bot).length, m.winner ? m.winner.name : null, m.winner ? m.winner.userId : null, JSON.stringify(m)); }
  leaderboard(n = 20) { return this.s.board.all(n); }
  history(id, n = 20) { return this.s.history.all(id, n); }
  counts() { return this.s.counts.get(); }
  close() { this.db.close(); }
}

// JSON fallback (single process). Writes are debounced & atomic (tmp file + rename).
class JsonStore {
  constructor(file) {
    this.kind = 'json'; this.file = file;
    this.d = { users: {}, profiles: {}, inv: {}, ledger: {}, matches: [] };
    try { this.d = JSON.parse(fs.readFileSync(file, 'utf8')); } catch {}
    this.timer = null;
  }
  save() {
    if (this.timer) return;
    this.timer = setTimeout(() => { this.timer = null; const tmp = this.file + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(this.d)); fs.renameSync(tmp, this.file); }, 250);
  }
  tx(fn) {
    const snap = JSON.stringify(this.d);
    try { const r = fn(); this.save(); return r; } catch (e) { this.d = JSON.parse(snap); throw e; }
  }
  createUser(u) {
    if (u.username && this.userByName(u.username)) throw new Error('UNIQUE constraint failed: users.username');
    this.d.users[u.id] = { id: u.id, username: u.username || null, display: u.display, pass: u.pass || null, guest: u.guest ? 1 : 0, token_ver: 1, created: Date.now(), last_seen: Date.now() }; this.save();
  }
  userById(id) { return this.d.users[id] || null; }
  userByName(n) { n = String(n).toLowerCase(); return Object.values(this.d.users).find((u) => u.username && u.username.toLowerCase() === n) || null; }
  setCredentials(id, username, pass) { if (this.userByName(username)) throw new Error('UNIQUE constraint failed: users.username'); const u = this.d.users[id]; u.username = username; u.pass = pass; u.guest = 0; u.token_ver++; this.save(); }
  setDisplay(id, dsp) { this.d.users[id].display = dsp; this.save(); }
  touch(id) { if (this.d.users[id]) this.d.users[id].last_seen = Date.now(); }
  createProfile(id, bal, loadout) { this.d.profiles[id] = { user_id: id, berries: bal.berries, crowns: bal.crowns, xp: 0, wins: 0, shows: 0, finals: 0, rounds: 0, loadout }; this.save(); }
  getProfile(id) { const p = this.d.profiles[id]; return p ? { ...p, loadout: { ...p.loadout } } : null; }
  owned(id) { return new Set(this.d.inv[id] || []); }
  grant(id, item) { const a = (this.d.inv[id] = this.d.inv[id] || []); if (!a.includes(item)) a.push(item); this.save(); }
  setLoadout(id, lo) { this.d.profiles[id].loadout = lo; this.save(); }
  credit(id, { berries = 0, crowns = 0, xp = 0, kind, ref }) {
    const L = (this.d.ledger[id] = this.d.ledger[id] || []);
    if (L.some((e) => e.ref === ref)) return false;
    const p = this.d.profiles[id];
    if (p.berries + berries < 0 || p.crowns + crowns < 0) throw new Error('CHECK constraint failed: balance');
    L.push({ kind, berries, crowns, xp, ref, ts: Date.now() });
    p.berries += berries; p.crowns += crowns; p.xp += xp; this.save(); return true;
  }
  addStats(id, s) { const p = this.d.profiles[id]; p.wins += s.wins || 0; p.shows += s.shows || 0; p.finals += s.finals || 0; p.rounds += s.rounds || 0; this.save(); }
  saveMatch(m) { this.d.matches.push({ id: m.id, ended: m.endedAt, winner: m.winner && m.winner.name }); if (this.d.matches.length > 500) this.d.matches.shift(); this.save(); }
  leaderboard(n = 20) {
    return Object.values(this.d.profiles).filter((p) => p.shows > 0).sort((a, b) => b.wins - a.wins || b.xp - a.xp).slice(0, n)
      .map((p) => ({ name: this.d.users[p.user_id].display, wins: p.wins, crowns: p.crowns, xp: p.xp, shows: p.shows }));
  }
  history(id, n = 20) { return (this.d.ledger[id] || []).slice(-n).reverse(); }
  counts() { return { users: Object.keys(this.d.users).length, matches: this.d.matches.length }; }
  close() {}
}

export async function openStore(dir) {
  fs.mkdirSync(dir, { recursive: true });
  try {
    const { DatabaseSync } = await import('node:sqlite');
    return new SqliteStore(DatabaseSync, path.join(dir, 'cranguys.db'));
  } catch (e) {
    console.warn('[db] node:sqlite unavailable (' + e.message + ') — using JSON store');
    return new JsonStore(path.join(dir, 'cranguys.json'));
  }
}
