// CranGuys — authentication: HMAC-SHA256 signed tokens (JWT-compatible HS256), scrypt password hashing,
// guest accounts that can later be upgraded to username/password accounts.
import { createHmac, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';

const b64u = (b) => Buffer.from(b).toString('base64url');
const HEADER = b64u(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
const TOKEN_DAYS = 120;

export class Auth {
  constructor(secret, store) { this.secret = secret; this.store = store; }

  sign(user) {
    const now = Math.floor(Date.now() / 1000);
    const body = b64u(JSON.stringify({ sub: user.id, v: user.token_ver || 1, iat: now, exp: now + TOKEN_DAYS * 86400 }));
    const sig = createHmac('sha256', this.secret).update(HEADER + '.' + body).digest('base64url');
    return `${HEADER}.${body}.${sig}`;
  }

  // returns the user row or null
  verify(token) {
    if (typeof token !== 'string' || token.length > 1024) return null;
    const parts = token.split('.');
    if (parts.length !== 3 || parts[0] !== HEADER) return null;
    const want = createHmac('sha256', this.secret).update(parts[0] + '.' + parts[1]).digest();
    let got; try { got = Buffer.from(parts[2], 'base64url'); } catch { return null; }
    if (got.length !== want.length || !timingSafeEqual(got, want)) return null;
    let p; try { p = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8')); } catch { return null; }
    if (!p || typeof p.sub !== 'string' || p.exp < Date.now() / 1000) return null;
    const u = this.store.userById(p.sub);
    if (!u || (u.token_ver || 1) !== p.v) return null;
    return u;
  }

  hashPassword(pw) {
    const salt = randomBytes(16);
    const hash = scryptSync(pw, salt, 32, { N: 16384, r: 8, p: 1 });
    return `scrypt$16384$${salt.toString('base64')}$${hash.toString('base64')}`;
  }
  checkPassword(pw, stored) {
    if (typeof stored !== 'string') return false;
    const [alg, n, salt, hash] = stored.split('$');
    if (alg !== 'scrypt') return false;
    const want = Buffer.from(hash, 'base64');
    const got = scryptSync(String(pw), Buffer.from(salt, 'base64'), want.length, { N: +n, r: 8, p: 1 });
    return timingSafeEqual(got, want);
  }
}

export const validUsername = (u) => typeof u === 'string' && /^[A-Za-z0-9_]{3,16}$/.test(u);
export const validPassword = (p) => typeof p === 'string' && p.length >= 6 && p.length <= 72;
const BAD = /(fuck|shit|cunt|nigg|fag|bitch|whore|rape|nazi|hitler)/i;
export function cleanDisplay(s) {
  s = String(s || '').replace(/[^\p{L}\p{N}_ .-]/gu, '').trim().slice(0, 16);
  if (s.length < 2 || BAD.test(s)) return null;
  return s;
}
export function newId() { return randomBytes(9).toString('base64url'); }
