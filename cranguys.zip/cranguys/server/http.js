// CranGuys — HTTP: REST API (auth, profile, locker, shop, leaderboard) + gzip static file serving.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { validUsername, validPassword } from './auth.js';
import { EconomyError } from './economy.js';

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.woff2': 'font/woff2' };

class HttpError extends Error { constructor(status, code, msg) { super(msg || code); this.status = status; this.code = code; } }

// tiny token-bucket rate limiter keyed by ip+bucket
function limiter() {
  const b = new Map();
  setInterval(() => { const now = Date.now(); for (const [k, v] of b) if (now - v.t > 600000) b.delete(k); }, 60000).unref?.();
  return (key, perMin) => {
    const now = Date.now(); let e = b.get(key);
    if (!e) b.set(key, (e = { tokens: perMin, t: now }));
    e.tokens = Math.min(perMin, e.tokens + ((now - e.t) / 60000) * perMin); e.t = now;
    if (e.tokens < 1) return false;
    e.tokens -= 1; return true;
  };
}

export function createHttp({ econ, auth, store, getGs, cfg, roots, log = console }) {
  const allow = limiter();
  const gzCache = new Map();

  const json = (res, status, obj, extra = {}) => {
    const body = JSON.stringify(obj);
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extra });
    res.end(body);
  };
  const readBody = (req) => new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', (c) => { n += c.length; if (n > 16384) { reject(new HttpError(413, 'too_large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { if (!n) return resolve({}); try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(new HttpError(400, 'bad_json', 'Invalid JSON')); } });
    req.on('error', reject);
  });
  const userOf = (req) => {
    const h = req.headers.authorization || '';
    const u = h.startsWith('Bearer ') ? auth.verify(h.slice(7)) : null;
    if (!u) throw new HttpError(401, 'auth', 'Please sign in again');
    return u;
  };
  const session = (u) => ({ token: auth.sign(u), profile: econ.profile(u.id) });

  const routes = {
    'GET /api/status': () => ({ ok: true, name: 'CranGuys', ...getGs().status(), store: store.kind, ...store.counts() }),
    'POST /api/auth/guest': async (req, body) => session(econ.newGuest(body.name)),
    'POST /api/auth/login': async (req, body) => {
      const u = validUsername(body.username) ? store.userByName(body.username) : null;
      if (!u || !auth.checkPassword(String(body.password || ''), u.pass)) throw new HttpError(401, 'bad_login', 'Wrong username or password');
      return session(u);
    },
    'POST /api/auth/register': async (req, body) => {
      const u = userOf(req);
      if (!u.guest) throw new HttpError(400, 'registered', 'This account already has a login');
      if (!validUsername(body.username)) throw new HttpError(400, 'bad_username', 'Usernames are 3–16 letters, numbers or _');
      if (!validPassword(body.password)) throw new HttpError(400, 'bad_password', 'Passwords need at least 6 characters');
      if (store.userByName(body.username)) throw new HttpError(409, 'taken', 'That username is taken');
      store.setCredentials(u.id, body.username, auth.hashPassword(body.password));
      return session(store.userById(u.id));
    },
    'GET /api/me': (req) => ({ profile: econ.profile(userOf(req).id) }),
    'POST /api/me/name': async (req, body) => ({ profile: econ.rename(userOf(req).id, body.name) }),
    'POST /api/locker/equip': async (req, body) => ({ profile: econ.equip(userOf(req).id, body.loadout) }),
    'GET /api/shop': () => econ.shop(),
    'POST /api/shop/buy': async (req, body) => ({ profile: econ.buy(userOf(req).id, String(body.itemId || '')) }),
    'GET /api/leaderboard': () => ({ top: store.leaderboard(20) }),
    'GET /api/history': (req) => ({ history: store.history(userOf(req).id, 25) }),
  };

  const cors = (req, res) => {
    const o = req.headers.origin;
    if (!o || !cfg.corsOrigins.length) return;
    if (cfg.corsOrigins.includes('*') || cfg.corsOrigins.includes(o)) {
      res.setHeader('Access-Control-Allow-Origin', o); res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization'); res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    }
  };

  async function api(req, res, url) {
    const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress;
    const isAuth = url.pathname.startsWith('/api/auth/');
    if (!allow(ip + (isAuth ? ':auth' : ':api'), isAuth ? 20 : 240)) return json(res, 429, { error: 'rate', message: 'Slow down a little!' });
    const fn = routes[req.method + ' ' + url.pathname];
    if (!fn) return json(res, 404, { error: 'not_found' });
    try {
      const body = req.method === 'POST' ? await readBody(req) : {};
      json(res, 200, await fn(req, body));
    } catch (e) {
      if (e instanceof HttpError) return json(res, e.status, { error: e.code, message: e.message });
      if (e instanceof EconomyError) return json(res, 400, { error: e.code, message: e.message });
      log.error('[api]', req.method, url.pathname, e);
      json(res, 500, { error: 'server', message: 'Something went wrong' });
    }
  }

  function serveStatic(req, res, url) {
    let p = decodeURIComponent(url.pathname);
    if (p === '/') p = '/index.html';
    let file = null;
    for (const [prefix, dir] of roots) {
      if (!p.startsWith(prefix)) continue;
      const rel = p.slice(prefix.length);
      const f = path.normalize(path.join(dir, rel));
      if (!f.startsWith(dir)) continue; // traversal guard
      if (fs.existsSync(f) && fs.statSync(f).isFile()) { file = f; break; }
    }
    if (!file) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    const ext = path.extname(file), type = MIME[ext] || 'application/octet-stream';
    const st = fs.statSync(file);
    const etag = `"${st.size.toString(36)}-${Math.floor(st.mtimeMs).toString(36)}"`;
    const headers = { 'Content-Type': type, ETag: etag, 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300', 'X-Content-Type-Options': 'nosniff' };
    if (req.headers['if-none-match'] === etag) { res.writeHead(304, headers); return res.end(); }
    const compressible = /text|javascript|json|svg/.test(type);
    if (compressible && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) {
      let c = gzCache.get(file);
      if (!c || c.etag !== etag) { c = { etag, body: zlib.gzipSync(fs.readFileSync(file), { level: 8 }) }; gzCache.set(file, c); }
      res.writeHead(200, { ...headers, 'Content-Encoding': 'gzip', Vary: 'Accept-Encoding', 'Content-Length': c.body.length });
      return res.end(req.method === 'HEAD' ? undefined : c.body);
    }
    res.writeHead(200, { ...headers, 'Content-Length': st.size });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  }

  return http.createServer((req, res) => {
    const url = new URL(req.url, 'http://localhost');
    res.setHeader('Referrer-Policy', 'no-referrer');
    cors(req, res);
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
    if (url.pathname === '/healthz') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok'); }
    if (url.pathname.startsWith('/api/')) return api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    serveStatic(req, res, url);
  });
}
