// CranGuys — realtime game service: WebSocket sessions, matchmaking queue, authoritative 30 Hz match loop.
import { Match } from '../shared/game.js';
import { PROTO, TICK_HZ, PHASE, TIMING } from '../shared/config.js';
import { decodeInput } from '../shared/protocol.js';

export class GameServer {
  constructor({ wss, auth, econ, store, cfg, log = console }) {
    Object.assign(this, { wss, auth, econ, store, cfg, log });
    this.sessions = new Set();
    this.byUser = new Map();     // userId -> session
    this.inMatch = new Map();    // userId -> { match, slot }  (survives disconnects for reconnection)
    this.matches = new Map();
    this.queue = [];
    this.stats = { matchesStarted: 0, matchesEnded: 0, peakOnline: 0 };
    wss.on('connection', (ws) => this.onConnection(ws));
    this.startLoops();
  }

  // ---------------- loops ----------------
  startLoops() {
    const dtMs = 1000 / TICK_HZ;
    let next = performance.now();
    const tick = () => {
      const now = performance.now();
      let steps = 0;
      while (now >= next && steps < 5) {
        for (const m of this.matches.values()) { try { for (let k = 0; k < (this.cfg.timeScale || 1); k++) m.step(); } catch (e) { this.log.error('[match]', m.id, e); this.killMatch(m, 'crash'); } }
        next += dtMs; steps++;
      }
      if (now - next > 250) next = now; // we fell far behind: resync rather than spiral
      this.loop = setTimeout(tick, Math.max(1, next - performance.now()));
    };
    this.loop = setTimeout(tick, dtMs);
    this.mmLoop = setInterval(() => this.processQueue(), 250);
    this.statusLoop = setInterval(() => this.broadcastStatus(), 1500);
  }
  stop() { clearTimeout(this.loop); clearInterval(this.mmLoop); clearInterval(this.statusLoop); }

  online() { let n = 0; for (const s of this.sessions) if (s.user) n++; return n; }
  status() {
    let playing = 0, lobbies = 0;
    for (const m of this.matches.values()) { if (m.phase === PHASE.LOBBY) lobbies++; else playing++; }
    return { online: this.online(), queue: this.queue.length, shows: playing, lobbies, version: PROTO };
  }
  broadcastStatus() {
    const st = { t: 'mm', ...this.status() };
    for (const s of this.sessions) {
      if (!s.user) continue;
      if (s.st === 'idle' || s.st === 'queued') s.ws.send(JSON.stringify(s.st === 'queued' ? { ...st, st: 'queued', waited: (Date.now() - s.ticket.since) / 1000 } : { ...st, st: 'idle' }));
    }
  }

  // ---------------- sessions ----------------
  onConnection(ws) {
    const s = { ws, user: null, st: 'new', match: null, slot: -1, ticket: null, inputs: 0, inputWindow: Date.now(), msgs: 0 };
    this.sessions.add(s);
    this.stats.peakOnline = Math.max(this.stats.peakOnline, this.sessions.size);
    const helloTimer = setTimeout(() => { if (!s.user) ws.close(4001, 'hello timeout'); }, 8000);
    ws.on('message', (data, binary) => {
      try { binary ? this.onBinary(s, data) : this.onText(s, data); } catch (e) { this.log.warn('[ws] bad message', e.message); }
    });
    ws.on('close', () => { clearTimeout(helloTimer); this.onClose(s); });
  }

  send(s, msg) { if (s && s.ws.open) s.ws.send(typeof msg === 'string' || msg instanceof Uint8Array ? msg : JSON.stringify(msg)); }

  onText(s, raw) {
    if (raw.length > 4096) return;
    if (++s.msgs > 200) { s.ws.close(4008, 'rate'); return; }
    setTimeout(() => s.msgs--, 1000);
    const m = JSON.parse(raw);
    if (!m || typeof m.t !== 'string') return;
    if (m.t === 'ping') return this.send(s, { t: 'pong', c: m.c, s: Date.now() });
    if (m.t === 'hello') return this.hello(s, m);
    if (!s.user) return this.send(s, { t: 'err', code: 'auth', msg: 'Say hello first' });
    switch (m.t) {
      case 'queue': return this.enqueue(s);
      case 'unqueue': return this.unqueue(s);
      case 'leave': return this.leaveMatch(s, true);
      case 'resync': if (s.match) s.match.welcome(s.slot); return;
    }
  }

  onBinary(s, buf) {
    if (!s.match) return;
    const now = Date.now();
    if (now - s.inputWindow > 1000) { s.inputWindow = now; s.inputs = 0; }
    if (++s.inputs > 100) return; // > 3x tick rate: drop
    const inp = decodeInput(buf);
    if (inp) s.match.input(s.slot, inp.epoch, inp.tick, inp.mx, inp.mz, inp.b);
  }

  hello(s, m) {
    if (m.v !== PROTO) return this.send(s, { t: 'err', code: 'version', msg: 'Please refresh — the game was updated.' });
    const u = this.auth.verify(m.token);
    if (!u) return this.send(s, { t: 'err', code: 'auth', msg: 'Session expired — signing you in again.' });
    const old = this.byUser.get(u.id);
    if (old && old !== s) { old.replaced = true; this.send(old, { t: 'err', code: 'replaced', msg: 'Signed in on another device.' }); old.ws.close(4002, 'replaced'); }
    s.user = u; s.st = 'idle';
    this.byUser.set(u.id, s);
    this.store.touch(u.id);
    this.send(s, { t: 'welcome', profile: this.econ.profile(u.id), ...this.status() });
    // reconnect into a running show
    const im = this.inMatch.get(u.id);
    if (im && !im.match.ended && !im.match.players[im.slot].left) {
      s.match = im.match; s.slot = im.slot; s.st = 'match';
      im.match._sessions.set(im.slot, s);
      im.match.reconnect(im.slot);
    }
  }

  onClose(s) {
    this.sessions.delete(s);
    if (s.user && this.byUser.get(s.user.id) === s) this.byUser.delete(s.user.id);
    this.unqueue(s, true);
    if (s.match && !s.replaced) { s.match.disconnect(s.slot); s.match._sessions.delete(s.slot); }
  }

  // ---------------- matchmaking ----------------
  enqueue(s) {
    if (s.st === 'queued') return;
    if (s.match) this.leaveMatch(s, false);
    s.ticket = { session: s, since: Date.now(), cancel: false };
    s.st = 'queued';
    this.queue.push(s.ticket);
    this.send(s, { t: 'mm', st: 'queued', waited: 0, ...this.status() });
  }
  unqueue(s, silent) {
    if (s.ticket) { s.ticket.cancel = true; this.queue = this.queue.filter((t) => t !== s.ticket); s.ticket = null; }
    if (s.st === 'queued') { s.st = 'idle'; if (!silent) this.send(s, { t: 'mm', st: 'idle', ...this.status() }); }
  }

  openLobby() {
    let best = null;
    for (const m of this.matches.values()) {
      if (m.phase !== PHASE.LOBBY || m.locked || m.ended) continue;
      if (m.humanCount() >= this.cfg.maxHumans || m.activeCount() >= m.max) continue;
      if (m.phaseT < 3 * TICK_HZ) continue;
      if (!best || m.humanCount() > best.humanCount()) best = m; // fill the fullest lobby first
    }
    return best;
  }

  createMatch() {
    let m = null;
    m = new Match({
      max: this.cfg.maxPlayers, botFill: this.cfg.botFill, lobbySecs: this.cfg.lobbySecs,
      send: (slot, msg) => { if (m) this.route(m, slot, msg); },
      hooks: { onPlayerDone: (pl, res) => this.onPlayerDone(m, pl, res), onEnd: (sum) => this.onMatchEnd(m, sum) },
    });
    m._sessions = new Map();
    this.matches.set(m.id, m);
    this.stats.matchesStarted++;
    this.log.info(`[mm] new show ${m.id} (lobby ${this.cfg.lobbySecs}s)`);
    return m;
  }

  processQueue() {
    let guard = 200;
    while (this.queue.length && guard-- > 0) {
      const t = this.queue[0];
      if (t.cancel || !t.session.ws.open) { this.queue.shift(); continue; }
      const s = t.session;
      const m = this.openLobby() || this.createMatch();
      const slot = m.addPlayer({ userId: s.user.id, name: s.user.display, cos: this.econ.loadout(s.user.id), bot: false });
      if (slot < 0) { m.locked = true; continue; }
      this.queue.shift();
      s.ticket = null; s.st = 'match'; s.match = m; s.slot = slot;
      m._sessions.set(slot, s);
      this.inMatch.set(s.user.id, { match: m, slot });
      this.send(s, { t: 'mm', st: 'found', ...this.status() });
      m.welcome(slot);
    }
  }

  leaveMatch(s, notify) {
    const m = s.match; if (!m) return;
    m.leave(s.slot); m._sessions.delete(s.slot);
    if (s.user) this.inMatch.delete(s.user.id);
    s.match = null; s.slot = -1; s.st = 'idle';
    if (notify) this.send(s, { t: 'left', ...this.status() });
  }

  route(m, slot, msg) {
    if (!m._sessions) return;
    const bin = msg instanceof Uint8Array;
    if (slot === -1) {
      const str = bin ? null : JSON.stringify(msg);
      for (const s of m._sessions.values()) if (s.ws.open) s.ws.send(bin ? msg : str);
      return;
    }
    const s = m._sessions.get(slot);
    if (!s || !s.ws.open) return;
    if (bin && s.ws.bufferedAmount > 512 * 1024) return; // congested client: skip a snapshot instead of queueing lag
    s.ws.send(bin ? msg : JSON.stringify(msg));
  }

  onPlayerDone(m, pl, res) {
    if (!pl.userId) return;
    let rw = null;
    try { rw = this.econ.reward(pl.userId, res); } catch (e) { this.log.error('[econ] reward failed', e); }
    const s = m._sessions.get(pl.slot) || this.byUser.get(pl.userId);
    if (s) this.send(s, { t: 'reward', ...res, reward: rw, profile: this.econ.profile(pl.userId) });
  }

  onMatchEnd(m, sum) {
    this.stats.matchesEnded++;
    try { if (sum.reason !== 'empty') this.store.saveMatch(sum); } catch (e) { this.log.error('[db] saveMatch', e); }
    for (const [slot, s] of m._sessions) { if (s.match === m) { s.match = null; s.slot = -1; s.st = 'idle'; } }
    for (const [uid, im] of this.inMatch) if (im.match === m) this.inMatch.delete(uid);
    setTimeout(() => this.matches.delete(m.id), 1000);
    this.log.info(`[mm] show ${m.id} ended (${sum.reason}) winner=${sum.winner ? sum.winner.name : '-'}`);
  }

  killMatch(m, why) { try { m.end(why); } catch {} this.matches.delete(m.id); }
}
