// CranGuys — cosmetics catalog, shop rotation and reward rules. Shared so the server economy, the offline
// economy and the client UI all agree on prices, rarities and payouts.
import { mulberry32, hashStr } from './math.js';

export const RARITY = {
  common: { name: 'Common', price: { b: 400 }, col: '#5cc8ff' },
  rare: { name: 'Rare', price: { b: 900 }, col: '#b07bff' },
  epic: { name: 'Epic', price: { b: 1800 }, col: '#ff5fa2' },
  legendary: { name: 'Legendary', price: { c: 4 }, col: '#ffc83d' },
};

const colors = [
  ['bubblegum', 'Bubblegum', '#ff7ab8', 'common'], ['sky', 'Sky', '#5cc8ff', 'common'], ['lime', 'Lime', '#8fe34d', 'common'],
  ['sunny', 'Sunny', '#ffd23f', 'common'], ['tangerine', 'Tangerine', '#ff8a3d', 'common'], ['grape', 'Grape', '#8b4dff', 'common'],
  ['mint', 'Mint', '#40e0a8', 'common'], ['cloud', 'Cloud', '#f4f0ff', 'common'], ['coral', 'Coral', '#ff6f61', 'rare'],
  ['cranberry', 'Cranberry', '#d6195a', 'rare'], ['teal', 'Teal', '#14b8b0', 'rare'], ['lilac', 'Lilac', '#c9a6ff', 'rare'],
  ['peach', 'Peach', '#ffb38a', 'rare'], ['ink', 'Ink', '#2b2350', 'epic'], ['cherry', 'Cherry', '#ff2e4d', 'epic'],
  ['gold', 'Gold', '#ffc83d', 'legendary'], ['rainbow', 'Rainbow', 'rainbow', 'legendary'],
];
const patterns = [
  ['solid', 'Solid', 0, 'common'], ['stripes', 'Stripes', 1, 'common'], ['polka', 'Polka Dots', 2, 'common'], ['zigzag', 'Zigzag', 3, 'rare'],
  ['checker', 'Checkers', 4, 'rare'], ['split', 'Half & Half', 5, 'rare'], ['stars', 'Starry', 6, 'epic'], ['swirl', 'Swirl', 7, 'epic'],
  ['fade', 'Gradient', 8, 'common'], ['hearts', 'Hearts', 9, 'epic'],
];
const faces = [
  ['classic', 'Classic', 0, 'common'], ['happy', 'Happy', 1, 'common'], ['sleepy', 'Sleepy', 2, 'rare'], ['shades', 'Cool Shades', 3, 'epic'],
  ['lovey', 'Lovestruck', 4, 'rare'], ['grumpy', 'Grumpy', 5, 'rare'], ['wink', 'Wink', 6, 'common'], ['starry', 'Starstruck', 7, 'epic'],
];
const hats = [
  ['none', 'No Hat', 0, 'common'], ['party', 'Party Cone', 1, 'common'], ['crown', 'Royal Crown', 2, 'legendary'], ['bunny', 'Bunny Ears', 3, 'rare'],
  ['propeller', 'Propeller Cap', 4, 'rare'], ['halo', 'Halo', 5, 'epic'], ['tophat', 'Top Hat', 6, 'rare'], ['cone', 'Traffic Cone', 7, 'common'],
  ['viking', 'Viking Horns', 8, 'epic'], ['chef', 'Chef Hat', 9, 'common'], ['leaf', 'Cranberry Sprig', 10, 'epic'], ['antenna', 'Antennae', 11, 'common'],
  ['flower', 'Daisy', 12, 'rare'], ['beanie', 'Bobble Beanie', 13, 'common'], ['pirate', 'Pirate Hat', 14, 'legendary'], ['headphones', 'Headphones', 15, 'rare'],
];

export const CATALOG = [];
for (const [id, name, hex, rarity] of colors) CATALOG.push({ id: 'c_' + id, slot: 'color', name, hex, rarity });
for (const [id, name, k, rarity] of patterns) CATALOG.push({ id: 'p_' + id, slot: 'pattern', name, k, rarity });
for (const [id, name, k, rarity] of faces) CATALOG.push({ id: 'f_' + id, slot: 'face', name, k, rarity });
for (const [id, name, k, rarity] of hats) CATALOG.push({ id: 'h_' + id, slot: 'hat', name, k, rarity });
for (const it of CATALOG) it.price = { ...RARITY[it.rarity].price };

const BY_ID = new Map(CATALOG.map((i) => [i.id, i]));
export const itemById = (id) => BY_ID.get(id);
export const SLOTS = ['color', 'color2', 'pattern', 'face', 'hat'];
export const slotCategory = (slot) => (slot === 'color2' ? 'color' : slot);

export const DEFAULT_OWNED = ['c_bubblegum', 'c_sky', 'c_lime', 'c_sunny', 'c_cloud', 'p_solid', 'p_stripes', 'p_fade', 'f_classic', 'f_happy', 'h_none', 'h_party'];
export const DEFAULT_LOADOUT = { color: 'c_bubblegum', color2: 'c_cloud', pattern: 'p_solid', face: 'f_classic', hat: 'h_none' };
export const START_BALANCE = { berries: 1200, crowns: 0 };

// validate & normalise a loadout against an owned set
export function sanitizeLoadout(lo, owned) {
  const out = { ...DEFAULT_LOADOUT };
  if (!lo || typeof lo !== 'object') return out;
  for (const slot of SLOTS) {
    const id = lo[slot], it = itemById(id);
    if (it && it.slot === slotCategory(slot) && (!owned || owned.has(id))) out[slot] = id;
  }
  return out;
}

export function randomLoadout(rng) {
  const by = (s) => CATALOG.filter((i) => i.slot === s);
  const pick = (arr) => arr[Math.floor(rng() * arr.length) % arr.length].id;
  const hats = by('hat');
  return {
    color: pick(by('color')), color2: pick(by('color')), pattern: pick(by('pattern')), face: pick(by('face')),
    hat: rng() < 0.45 ? 'h_none' : pick(hats),
  };
}

// Daily rotating shop: 6 items + 1 featured legendary, identical for everyone on a given UTC day.
export function dailyShop(date = new Date()) {
  const day = date.toISOString().slice(0, 10);
  const rng = mulberry32(hashStr('cranguys-shop-' + day));
  const pool = CATALOG.filter((i) => !DEFAULT_OWNED.includes(i.id) && i.rarity !== 'legendary' && i.id !== 'h_none');
  const legend = CATALOG.filter((i) => i.rarity === 'legendary');
  const picks = [];
  while (picks.length < 6) { const it = pool[Math.floor(rng() * pool.length)]; if (!picks.includes(it.id)) picks.push(it.id); }
  const featured = legend[Math.floor(rng() * legend.length)].id;
  const next = new Date(day + 'T00:00:00Z'); next.setUTCDate(next.getUTCDate() + 1);
  return { day, featured, items: picks, refreshAt: next.getTime() };
}

// Rewards are computed only on the authority (server, or the offline local server).
export function computeRewards({ rounds = 0, won = false, totalRounds = 3, eliminated = false }) {
  let berries = 40 + rounds * 90, xp = 60 + rounds * 120, crowns = 0;
  if (rounds >= totalRounds - 1) berries += 60;          // made the final
  if (won) { berries += 400; xp += 400; crowns += 1; }
  return { berries, crowns, xp };
}
export const XP_PER_LEVEL = 1000;
export const levelForXp = (xp) => 1 + Math.floor(xp / XP_PER_LEVEL);
export const LEVEL_UP_BONUS = 150;
