// Round type: SURVIVAL — "Tile Tumble". Three stacked layers of hex tiles that drop shortly after you
// touch them, swept by spinning laser beams and travelling laser walls (jump the low ones, dive under the high ones).
import { Kit, C, T_PLAY } from './kit.js';

export const TILE = { RC: 1.36, RT: 1.3, HH: 0.35, N: 10, DROP_TICKS: 30 };
const EXT = 26.5; // laser reach (layer radius ~25 m)
export const LAYERS = [28, 20, 12, 4];

export function hexCenters(N, RC) {
  const out = [];
  for (let q = -N; q <= N; q++) for (let r = -N; r <= N; r++) {
    if (Math.abs(q + r) > N) continue;
    out.push({ q, r, x: RC * 1.5 * q, z: RC * Math.sqrt(3) * (r + q / 2), ring: Math.max(Math.abs(q), Math.abs(r), Math.abs(q + r)) });
  }
  return out;
}

export function buildTileTumble(seed) {
  const K = new Kit();
  const pal = [[C.pink, C.bubble, C.hotpink], [C.blue, C.sky, C.teal], [C.yellow, C.cream, C.orange], [C.mint, C.lime, C.teal]];
  const tiles = [];
  const cells = hexCenters(TILE.N, TILE.RC);
  LAYERS.forEach((y, L) => {
    for (const h of cells) {
      const shade = ((h.q - h.r) % 3 + 3) % 3;
      const c = K.cyl([h.x, y - TILE.HH, h.z], TILE.RT, TILE.HH, { dyn: K.dyn(), tag: 'tile', vis: { m: 'tile', c: pal[L][shade], layer: L, ti: tiles.length } });
      tiles.push({ id: tiles.length, x: h.x, z: h.z, y, layer: L, ring: h.ring, col: c, dyn: c.dyn });
    }
  });

  // neighbour lists (same layer, within 5.6 m) for bot planning
  for (const t of tiles) t.nb = [];
  for (let i = 0; i < tiles.length; i++) for (let j = i + 1; j < tiles.length; j++) {
    const a = tiles[i], b = tiles[j];
    if (a.layer !== b.layer) continue;
    const d = Math.hypot(a.x - b.x, a.z - b.z);
    if (d < 5.6) { a.nb.push(j); b.nb.push(i); }
  }
  // lasers (triggers): a spinning beam per layer + two travelling walls per layer
  const lasers = [];
  LAYERS.forEach((y, L) => {
    const beamStart = T_PLAY + [26, 18, 12, 9][L];
    const w = L % 2 ? -0.34 : 0.3;
    K.trig({ shape: 'cap', kind: 'laser', p: [0, y + 0.5, 0], r: 0.18, hl: EXT, knock: 9, kin: { type: 'spin', c: [0, y + 0.5, 0], axis: [0, 1, 0], w, start: beamStart }, vis: { m: 'laser' } });
    lasers.push({ type: 'beam', y, c: [0, y + 0.5, 0], hl: EXT, w, start: beamStart, layer: L });
    const t0low = T_PLAY + [14, 10, 6, 4][L], t0high = T_PLAY + [23.5, 19.5, 15.5, 13.5][L];
    K.trig({ shape: 'box', kind: 'laser', p: [0, y + 0.45, -EXT], h: [EXT, 0.45, 0.12], knock: 10, kin: { type: 'sweep', d: [0, 0, EXT * 2], move: 11, period: 19, t0: t0low, alt: true }, vis: { m: 'laserwall', low: true } });
    lasers.push({ type: 'wall', low: true, y, axis: 2, from: -EXT, travel: EXT * 2, move: 11, period: 19, t0: t0low, alt: true, layer: L });
    K.trig({ shape: 'box', kind: 'laser', p: [-EXT, y + 2.28, 0], h: [0.12, 0.8, EXT], knock: 10, kin: { type: 'sweep', d: [EXT * 2, 0, 0], move: 11, period: 19, t0: t0high, alt: true }, vis: { m: 'laserwall', high: true } });
    lasers.push({ type: 'wall', low: false, y, axis: 0, from: -EXT, travel: EXT * 2, move: 11, period: 19, t0: t0high, alt: true, layer: L });
    // emitter rings around each layer (decor)
    K.deco({ shape: 'ring', p: [0, y - 0.9, 0], r: EXT + 0.6, vis: { c: pal[L][2], m: 'plain' } });
  });
  // central pillar (decor) and neon posts
  K.deco({ shape: 'pillar', p: [0, -6, 0], r: 1.2, h: 30, vis: { c: C.violet, c2: C.white, m: 'stripes' } });

  const top = tiles.filter((t) => t.layer === 0);
  return {
    id: 'tiletumble', type: 'survival', name: 'Tile Tumble', desc: 'Don’t fall through all four floors!', tip: 'Tiles drop moments after you touch them — keep moving. Jump the low lasers, dive under the high ones.',
    colliders: K.cols, triggers: K.trigs, decor: K.decor, ndyn: K.ndyn, hazards: K.hazards, tiles, lasers,
    timeLimit: 180, slimeY: -3.5, theme: 'dusk',
    rules: { killY: -1.5, respawn: false, checkpoints: [{ spawn: [0, 28, 0], spread: [4, 4], yaw: 0, box: [0, 0, 0, 0, 0, 0] }] },
    spawns(n) {
      const ring = top.filter((t) => t.ring >= 2 && t.ring <= 8 && t.ring % 2 === 0).sort((a, b) => Math.atan2(a.z, a.x) - Math.atan2(b.z, b.x) || a.ring - b.ring);
      const out = [];
      for (let i = 0; i < n; i++) { const t = ring[Math.floor((i * ring.length) / Math.max(n, 1)) % ring.length]; out.push([t.x, t.y, t.z, Math.atan2(-t.x, -t.z)]); }
      return out;
    },
    bot: { survival: true },
    cam: [
      { e: [0, 66, -46], l: [0, 14, 0] }, { e: [46, 42, 0], l: [0, 16, 0] }, { e: [0, 38, 44], l: [0, 22, 0] }, { e: [-34, 36, -10], l: [0, 28, 0] }, { e: [0, 35.5, -22], l: [0, 28.5, -6] },
    ],
  };
}
