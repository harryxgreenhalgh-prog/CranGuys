// Level registry. buildLevel(id, seed) is deterministic and cached per (id, seed).
import { buildWhirlWay } from './whirlway.js';
import { buildTileTumble } from './tiletumble.js';
import { buildCrownPeak, crownAt } from './crownpeak.js';
import { buildLobby } from './lobby.js';

export const LEVELS = {
  lobby: { build: buildLobby, type: 'lobby', name: 'Waiting Island', icon: 'fa-umbrella-beach' },
  whirlway: { build: buildWhirlWay, type: 'race', name: 'Whirl Way', icon: 'fa-flag-checkered' },
  tiletumble: { build: buildTileTumble, type: 'survival', name: 'Tile Tumble', icon: 'fa-shapes' },
  crownpeak: { build: buildCrownPeak, type: 'final', name: 'Crown Peak', icon: 'fa-crown' },
};
export const SHOW = ['whirlway', 'tiletumble', 'crownpeak'];

const cache = new Map();
export function buildLevel(id, seed = 1) {
  const k = id + ':' + seed;
  if (!cache.has(k)) { if (cache.size > 12) cache.clear(); cache.set(k, LEVELS[id].build(seed)); }
  return cache.get(k);
}
// Fresh (uncached) copy — World mutates collider objects (cached poses), so each World needs its own.
export function freshLevel(id, seed = 1) { return LEVELS[id].build(seed); }
export { crownAt };
