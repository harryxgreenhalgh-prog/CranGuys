// CranGuys — Match: the authoritative show (lobby -> race -> survival -> final -> podium).
// Isomorphic: the Node server runs one Match per show; the offline mode runs the same class in the browser.
import { PHASE, TIMING, DT, TICK_HZ, SUBSTEPS, MODE, BTN, MAX_PLAYERS, SNAP_EVERY, PHYS } from './config.js';
import { World } from './world.js';
import { freshLevel, SHOW } from './levels/index.js';
import { crownAt } from './levels/crownpeak.js';
import { TILE } from './levels/tiletumble.js';
import { T_PLAY } from './levels/kit.js';
import { newChar, charBegin, charSub, charEnd, packChar, NFIELDS, toRag, charShape } from './character.js';
import { contactSeg, makeHit, segSeg } from './collide.js';
import { BotBrain } from './bots.js';
import { buildSnapBody, encodeSnap } from './protocol.js';
import { mulberry32, clamp } from './math.js';
import { beanName } from './names.js';
import { randomLoadout } from './cosmetics.js';

export const TP = Math.round(T_PLAY * TICK_HZ);   // round tick at which PLAY starts
const NOINP = Object.freeze({ mx: 0, mz: 0, b: 0 });
const F = new Float32Array(NFIELDS);
const HB = makeHit();

export class Match {
  constructor(o = {}) {
    this.id = o.id || 'show-' + Math.floor(Math.random() * 1e9).toString(36);
    this.seed = (o.seed >>> 0) || (Math.floor(Math.random() * 2 ** 31) >>> 0);
    this.secret = (o.secret ?? Math.floor(Math.random() * 2 ** 31)) >>> 0;
    this.rng = mulberry32(this.seed ^ 0x9e3779b9);
    this.max = Math.min(MAX_PLAYERS, o.max || MAX_PLAYERS);
    this.botFill = o.botFill !== false;
    this.send = o.send || (() => {});
    this.hooks = o.hooks || {};
    this.show = (o.show || SHOW).slice();
    this.players = [];
    this.epoch = 0;
    this.roundIdx = -1;
    this.gt = 0;
    this.ended = false;
    this.locked = false;
    this.evq = [];
    this.testMode = !!o.testMode;
    this.createdAt = Date.now();
    this.loadLevel('lobby');
    this.setPhase(PHASE.LOBBY, o.lobbySecs ?? TIMING.lobbyOnline);
  }

  // ---------------- roster ----------------
  activeCount() { let n = 0; for (const p of this.players) if (p.status !== 'gone') n++; return n; }
  humanCount() { let n = 0; for (const p of this.players) if (!p.bot && p.status !== 'gone') n++; return n; }
  pub(pl) { return { s: pl.slot, n: pl.name, c: pl.cos, b: pl.bot ? 1 : 0, st: pl.status, u: pl.bot ? null : pl.userId }; }

  addPlayer({ userId, name, cos, bot = false, skill = 0.6 }) {
    if (this.locked || this.ended || this.activeCount() >= this.max || this.players.length >= 250) return -1;
    const slot = this.players.length;
    const pl = {
      slot, userId: userId || null, name: String(name || 'Bean').slice(0, 16), cos, bot, skill,
      brain: bot ? new BotBrain((this.seed ^ (slot * 7919)) >>> 0, skill) : null,
      st: null, status: 'in', conn: !bot, left: false, done: false, inq: new Map(), last: NOINP, newest: -1, starve: 0,
      qual: 0, place: 0, xRound: -1, inp: NOINP, I: {}, ctx: null, dcAt: 0,
    };
    pl.ctx = { rules: this.level.rules, ev: null, slot, onGround: (c, s, tick) => this.onGround(pl, c, tick), onContact: (c, s, n, vn, tick) => this.onContact(pl, c, n, vn, tick) };
    this.players.push(pl);
    const sp = this.level.spawns(slot + 1)[slot];
    pl.st = newChar([sp[0] + (this.rng() - 0.5), sp[1] + PHYS.STAND + 0.05, sp[2] + (this.rng() - 0.5)], sp[3]);
    this.send(-1, { t: 'join', p: this.pub(pl) });
    if (!bot && this.hooks.onJoin) this.hooks.onJoin(pl);
    return slot;
  }

  addBot() {
    const r = this.rng;
    const skill = clamp(0.25 + r() * 0.65 + (r() < 0.15 ? 0.15 : 0), 0.15, 1);
    return this.addPlayer({ name: beanName(r), cos: randomLoadout(r), bot: true, skill });
  }

  // full state for a (re)joining human
  welcome(slot) {
    this.send(slot, {
      t: 'match', id: this.id, you: slot, max: this.max, show: this.show, round: this.roundIdx, phase: this.phase,
      left: this.phaseT / TICK_HZ, level: this.levelId, seed: this.levelSeed, epoch: this.epoch, tick: this.tick, Q: this.Q || 0,
      players: this.players.filter((p) => p.status !== 'gone').map((p) => this.pub(p)),
      tiles: this.tileTouch ? Array.from(this.tileTouch).map((t, i) => (t >= 0 ? [i, t] : null)).filter(Boolean) : [],
      doors: this.level.doors ? this.level.doors.filter((d) => this.world.dead[d.dyn] < 0x7fffffff).map((d) => [d.id, this.world.dead[d.dyn]]) : [],
    });
  }

  input(slot, epoch, tick, mx, mz, b) {
    const pl = this.players[slot];
    if (!pl || pl.bot || pl.left || epoch !== this.epoch) return;
    if (tick < this.tick || tick > this.tick + 90) { pl.late = (pl.late || 0) + 1; return; }
    if (pl.inq.size > 120) pl.inq.clear();
    pl.inq.set(tick, { mx: clamp(+mx || 0, -1, 1), mz: clamp(+mz || 0, -1, 1), b: b & 15 });
    if (tick > pl.newest) pl.newest = tick;
  }

  disconnect(slot) {
    const pl = this.players[slot]; if (!pl || pl.bot) return;
    pl.conn = false; pl.dcAt = this.gt; pl.last = NOINP; pl.inq.clear();
    if (this.phase === PHASE.LOBBY) this.removeFromLobby(pl);
  }
  reconnect(slot) {
    const pl = this.players[slot]; if (!pl || pl.left) return false;
    pl.conn = true; pl.newest = -1; this.welcome(slot); return true;
  }
  leave(slot) {
    const pl = this.players[slot]; if (!pl || pl.bot || pl.left) return;
    pl.left = true; pl.conn = false;
    if (this.phase === PHASE.LOBBY) { this.removeFromLobby(pl); return; }
    if (pl.status === 'in' || pl.status === 'q') { pl.status = 'x'; pl.xRound = this.roundIdx; if (pl.st) pl.st.mode = MODE.OUT; this.ev('x', pl.slot); }
    this.finishPlayer(pl, false);
  }
  removeFromLobby(pl) {
    pl.status = 'gone'; pl.st = null; pl.left = true;
    this.send(-1, { t: 'leave', s: pl.slot });
  }

  // ---------------- phases ----------------
  setPhase(p, secs) {
    this.phase = p; this.phaseT = Math.max(1, Math.round(secs * TICK_HZ));
    this.send(-1, { t: 'phase', p, left: secs, round: this.roundIdx, tick: this.tick, epoch: this.epoch });
    if (this.hooks.onPhase) this.hooks.onPhase(p);
  }
  shortenLobby(secs) { if (this.phase === PHASE.LOBBY && this.phaseT > secs * TICK_HZ) this.setPhase(PHASE.LOBBY, secs); }

  loadLevel(id) {
    this.levelId = id;
    this.epoch = (this.epoch + 1) & 255;
    this.levelSeed = (this.seed + this.epoch * 7919) >>> 0;
    this.level = freshLevel(id, this.levelSeed);
    this.world = new World(this.level);
    this.tick = 0;
    this.tileTouch = this.level.tiles ? new Int32Array(this.level.tiles.length).fill(-1) : null;
    this.doorByDyn = new Map();
    if (this.level.doors) {
      const r = mulberry32((this.secret ^ this.levelSeed) >>> 0);
      for (let row = 0; row < 3; row++) {
        const ds = this.level.doors.filter((d) => d.row === row), k = 2 + Math.floor(r() * 3);
        const idx = ds.map((_, i) => i).sort(() => r() - 0.5).slice(0, k);
        ds.forEach((d, i) => { d.breakable = idx.includes(i); d.hp = 0.22; this.doorByDyn.set(d.dyn, d); });
      }
    }
    this.ballT = 0; this.ballId = 0;
    this.qualCount = 0; this.winner = -1; this.lastHumanDone = -1;
    for (const pl of this.players) if (pl.ctx) pl.ctx.rules = this.level.rules;
  }

  startRound(i) {
    this.roundIdx = i;
    const inShow = this.players.filter((p) => p.status === 'in' || p.status === 'q');
    for (const p of inShow) p.status = 'in';
    for (const p of this.players) if (p.status !== 'in') p.st = null;
    this.loadLevel(this.show[i]);
    const n = inShow.length, type = this.level.type;
    this.Q = type === 'race' ? (n <= 2 ? n : clamp(Math.round(n * 0.5), 1, n - 1)) : type === 'survival' ? (n <= 2 ? 1 : clamp(Math.round(n * 0.3), 2, n - 1)) : 1;
    const spawns = this.level.spawns(n);
    const order = inShow.slice().sort(() => this.rng() - 0.5);
    order.forEach((pl, k) => {
      const sp = spawns[k];
      pl.st = newChar([sp[0], sp[1] + PHYS.STAND + 0.03, sp[2]], sp[3]);
      pl.inq.clear(); pl.last = NOINP; pl.newest = -1; pl.place = 0;
      if (pl.brain) pl.brain.reset();
    });
    this.send(-1, { t: 'round', i, n: this.show.length, level: this.show[i], seed: this.levelSeed, epoch: this.epoch, Q: this.Q, count: n, type, tp: TP });
    this.setPhase(PHASE.INTRO, TIMING.intro);
  }

  nextPhase() {
    switch (this.phase) {
      case PHASE.LOBBY: {
        if (this.humanCount() === 0 && !this.testMode) return this.end('empty');
        if (this.botFill) while (this.activeCount() < this.max) if (this.addBot() < 0) break;
        this.locked = true;
        return this.startRound(0);
      }
      case PHASE.INTRO: return this.setPhase(PHASE.COUNTDOWN, (TP - this.tick) / TICK_HZ);
      case PHASE.COUNTDOWN: return this.setPhase(PHASE.PLAY, this.level.timeLimit + 2);
      case PHASE.PLAY: return this.endRound('time');
      case PHASE.ROUND_END: return this.results();
      case PHASE.RESULTS: {
        const q = this.players.filter((p) => p.status === 'q');
        const last = this.roundIdx >= this.show.length - 1;
        if (!this.testMode && !this.anyHumanWatching()) return this.end('no-humans');
        if (last || q.length <= 1) return this.podium(q.length === 1 && !last ? q[0].slot : this.winner);
        return this.startRound(this.roundIdx + 1);
      }
      case PHASE.PODIUM: return this.end('done');
      default: return this.end('done');
    }
  }

  anyHumanWatching() { return this.players.some((p) => !p.bot && !p.left && (p.conn || this.gt - p.dcAt < TIMING.disconnectGrace * TICK_HZ)); }

  // ---------------- main tick ----------------
  step() {
    if (this.ended) return;
    this.gt++;
    const ph = this.phase;
    const sim = ph === PHASE.LOBBY || ph === PHASE.INTRO || ph === PHASE.COUNTDOWN || ph === PHASE.PLAY || ph === PHASE.ROUND_END;
    if (sim) this.simTick(ph === PHASE.PLAY || ph === PHASE.LOBBY);
    if (ph === PHASE.PLAY) this.rules();
    if (ph === PHASE.LOBBY) this.lobbyTick();
    this.graceCheck();
    if (sim && this.tick % SNAP_EVERY === 0) this.broadcastSnap();
    this.flushEvents();
    this.tick++;
    if (--this.phaseT <= 0 && this.phase === ph) this.nextPhase();
  }

  simTick(apply) {
    const W = this.world, tick = this.tick, act = [];
    for (const pl of this.players) {
      if (!pl.st || pl.st.mode === MODE.OUT || pl.status === 'gone') continue;
      let inp = NOINP;
      if (pl.bot) inp = apply ? pl.brain.input(this, pl) : NOINP;
      else {
        const q = pl.inq.get(tick);
        if (q) { pl.inq.delete(tick); pl.last = q; } else if (pl.conn) pl.starve++;
        if (pl.inq.size) for (const k of pl.inq.keys()) if (k < tick) pl.inq.delete(k);
        inp = apply && pl.conn ? pl.last : NOINP;
      }
      pl.inp = inp;
      charBegin(pl.st, inp, pl.I);
      act.push(pl);
    }
    this.act = act;
    const dts = DT / SUBSTEPS;
    for (let k = 0; k < SUBSTEPS; k++) {
      W.setTime((tick * SUBSTEPS + k + 1) * dts);
      for (const pl of act) charSub(pl.st, pl.I, W, tick, pl.ctx);
    }
    for (const pl of act) charEnd(pl.st, W, tick, pl.ctx);
    this.playerCollisions(act);
    this.grabs(act);
    if (this.level.boulders) this.boulderStep();
  }

  onGround(pl, c, tick) {
    if (c.tag === 'tile' && this.phase === PHASE.PLAY) {
      const id = c.vis.ti;
      if (this.tileTouch[id] < 0) {
        this.tileTouch[id] = tick;
        this.world.kill(c.dyn, tick + TILE.DROP_TICKS);
        this.ev('tile', id, tick);
      }
    }
  }
  onContact(pl, c, n, vn, tick) {
    if (c.tag !== 'door' || this.phase !== PHASE.PLAY) return;
    const d = this.doorByDyn.get(c.dyn);
    if (!d || !d.breakable || this.world.isDead(c.dyn, tick + 1) || n[2] > -0.6) return;
    d.hp -= vn > 6 ? 1 : (DT / SUBSTEPS) * (1 + Math.max(0, vn) * 0.6);
    if (d.hp <= 0) { this.world.kill(c.dyn, tick + 1); this.ev('door', d.id, tick + 1, pl.slot); }
  }

  playerCollisions(act) {
    const list = act.filter((p) => { const m = p.st.mode; return m !== MODE.RESPAWN && m !== MODE.OUT && m !== MODE.LEDGE && m !== MODE.CLIMB; });
    const grid = new Map(), A1 = [0, 0, 0], B1 = [0, 0, 0], A2 = [0, 0, 0], B2 = [0, 0, 0];
    const key = (x, z) => ((Math.floor(x / 2) + 2048) << 12) | (Math.floor(z / 2) + 2048);
    for (const p of list) { const k = key(p.st.p[0], p.st.p[2]); let a = grid.get(k); if (!a) grid.set(k, (a = [])); a.push(p); }
    for (const p of list) {
      const s1 = p.st, cx = Math.floor(s1.p[0] / 2), cz = Math.floor(s1.p[2] / 2);
      for (let ix = cx - 1; ix <= cx + 1; ix++) for (let iz = cz - 1; iz <= cz + 1; iz++) {
        const arr = grid.get(((ix + 2048) << 12) | (iz + 2048)); if (!arr) continue;
        for (const q of arr) {
          if (q.slot <= p.slot) continue;
          const s2 = q.st;
          if (Math.abs(s1.p[1] - s2.p[1]) > 2.2) continue;
          const r1 = charShape(s1, A1, B1), r2 = charShape(s2, A2, B2);
          const [u, v] = segSeg(A1, B1, A2, B2);
          const px = A1[0] + (B1[0] - A1[0]) * u, py = A1[1] + (B1[1] - A1[1]) * u, pz = A1[2] + (B1[2] - A1[2]) * u;
          const qx = A2[0] + (B2[0] - A2[0]) * v, qy = A2[1] + (B2[1] - A2[1]) * v, qz = A2[2] + (B2[2] - A2[2]) * v;
          let nx = px - qx, ny = py - qy, nz = pz - qz; const d = Math.hypot(nx, ny, nz), rr = r1 + r2;
          if (d >= rr) continue;
          if (d < 1e-5) { nx = 1; ny = 0; nz = 0; } else { nx /= d; ny /= d; nz /= d; }
          const pen = rr - d;
          s1.p[0] += nx * pen * 0.5; s1.p[1] += Math.max(0, ny) * pen * 0.5; s1.p[2] += nz * pen * 0.5;
          s2.p[0] -= nx * pen * 0.5; s2.p[1] += Math.max(0, -ny) * pen * 0.5; s2.p[2] -= nz * pen * 0.5;
          const rvx = s1.v[0] - s2.v[0], rvy = s1.v[1] - s2.v[1], rvz = s1.v[2] - s2.v[2], vn = rvx * nx + rvy * ny + rvz * nz;
          const rel = Math.hypot(rvx, rvy, rvz);
          if (vn < 0) { const j = -vn * 0.55; s1.v[0] += nx * j; s1.v[1] += ny * j; s1.v[2] += nz * j; s2.v[0] -= nx * j; s2.v[1] -= ny * j; s2.v[2] -= nz * j; }
          // standing on someone's head
          if (ny > 0.7) { s1.gr = 1; s1.gn[0] = 0; s1.gn[1] = 1; s1.gn[2] = 0; s1.gv[0] = s2.v[0]; s1.gv[1] = 0; s1.gv[2] = s2.v[2]; s1.co = PHYS.COYOTE; s1.cd = 1; if (s1.v[1] < 0) s1.v[1] = 0; }
          else if (ny < -0.7) { s2.gr = 1; s2.gn[0] = 0; s2.gn[1] = 1; s2.gn[2] = 0; s2.gv[0] = s1.v[0]; s2.gv[1] = 0; s2.gv[2] = s1.v[2]; s2.co = PHYS.COYOTE; s2.cd = 1; if (s2.v[1] < 0) s2.v[1] = 0; }
          // diving tackles knock people over
          if (rel > 8.5) {
            if (s1.mode === MODE.DIVE && s2.mode === MODE.NORMAL && s2.kt <= 0) { toRag(s2); s2.kt = 0.4; s2.v[0] = s1.v[0] * 0.55; s2.v[1] = 3.5; s2.v[2] = s1.v[2] * 0.55; }
            else if (s2.mode === MODE.DIVE && s1.mode === MODE.NORMAL && s1.kt <= 0) { toRag(s1); s1.kt = 0.4; s1.v[0] = s2.v[0] * 0.55; s1.v[1] = 3.5; s1.v[2] = s2.v[2] * 0.55; }
          }
        }
      }
    }
  }

  grabs(act) {
    for (const p of act) p.st.held = 0;
    for (const p of act) {
      const s = p.st;
      if (s.mode !== MODE.GRABBING) continue;
      const tg = this.players[s.gt - 1], ts = tg && tg.st;
      const ok = ts && ts.mode !== MODE.OUT && ts.mode !== MODE.RESPAWN && ts.mode !== MODE.RAG && ts.mode !== MODE.LEDGE && ts.mode !== MODE.CLIMB && tg.status === 'in';
      const fx = Math.sin(s.yaw), fz = Math.cos(s.yaw);
      const ax = s.p[0] + fx * 0.95, az = s.p[2] + fz * 0.95;
      const dist = ok ? Math.hypot(ts.p[0] - ax, ts.p[2] - az) : 99;
      if (!ok || dist > 2.4 || Math.abs(ts.p[1] - s.p[1]) > 1.6) { s.mode = MODE.NORMAL; s.gt = 0; s.gc = PHYS.GRAB_CD; s.mt = 0; continue; }
      ts.held = p.slot + 1;
      if (dist > 0.55) { const k = Math.min(9, (dist - 0.55) * 14) * DT; ts.v[0] += ((ax - ts.p[0]) / dist) * k * 6; ts.v[2] += ((az - ts.p[2]) / dist) * k * 6; }
    }
    for (const p of act) {
      const s = p.st;
      if (s.mode !== MODE.NORMAL || !(p.inp.b & BTN.GRAB) || s.gc > 0 || s.held) continue;
      const q = this.nearestAhead(p, PHYS.GRAB_REACH);
      if (q && !q.st.held && q.st.mode !== MODE.GRABBING) { s.mode = MODE.GRABBING; s.mt = 0; s.gt = q.slot + 1; q.st.held = p.slot + 1; }
    }
  }

  nearestAhead(p, range) {
    const s = p.st, fx = Math.sin(s.yaw), fz = Math.cos(s.yaw);
    let best = null, bd = range;
    for (const q of this.act || []) {
      if (q === p || !q.st) continue;
      const m = q.st.mode; if (m === MODE.OUT || m === MODE.RESPAWN || m === MODE.LEDGE || m === MODE.CLIMB) continue;
      const dx = q.st.p[0] - s.p[0], dz = q.st.p[2] - s.p[2], d = Math.hypot(dx, dz);
      if (d > bd + 0.6 || Math.abs(q.st.p[1] - s.p[1]) > 1.1 || d < 1e-3) continue;
      if ((dx * fx + dz * fz) / d < 0.55) continue;
      if (d - 0.6 < bd) { bd = d - 0.6; best = q; }
    }
    return best;
  }

  boulderStep() {
    const B = this.level.boulders, W = this.world, t = this.tick * DT;
    if ((this.phase === PHASE.PLAY || this.phase === PHASE.ROUND_END) && t >= B.start) {
      this.ballT -= DT;
      if (this.ballT <= 0) {
        this.ballT = B.every * (0.75 + this.rng() * 0.5);
        const x = B.xs[Math.floor(this.rng() * B.xs.length)] + (this.rng() - 0.5) * 1.2;
        this.ballId = (this.ballId + 1) & 255;
        W.balls.push({ id: this.ballId, p: [x, B.y, B.z], v: [(this.rng() - 0.5) * 0.8, 0, -3.5], r: B.r, age: 0 });
      }
    }
    const dts = DT / SUBSTEPS, SV = [0, 0, 0];
    for (let k = 0; k < SUBSTEPS; k++) {
      W.setTime((this.tick * SUBSTEPS + k + 1) * dts);
      for (const b of W.balls) {
        b.v[1] -= PHYS.G * 0.8 * dts;
        b.p[0] += b.v[0] * dts; b.p[1] += b.v[1] * dts; b.p[2] += b.v[2] * dts;
        W.near(b.p[0], b.p[1], b.p[2], b.r + 0.1, this.tick, (c) => {
          if (c.ghost || !contactSeg(c, b.p, b.p, b.r, HB)) return;
          const n = HB.n;
          b.p[0] += n[0] * HB.d; b.p[1] += n[1] * HB.d; b.p[2] += n[2] * HB.d;
          W.surfVel(c, HB.cp, SV);
          const vn = (b.v[0] - SV[0]) * n[0] + (b.v[1] - SV[1]) * n[1] + (b.v[2] - SV[2]) * n[2];
          if (vn < 0) { const k2 = vn < -3 ? 1.25 : 1; b.v[0] -= n[0] * vn * k2; b.v[1] -= n[1] * vn * k2; b.v[2] -= n[2] * vn * k2; }
          if (c.surf === 4) { b.v[0] += n[0] * 4; b.v[2] += n[2] * 4; }
        });
        const sp = Math.hypot(b.v[0], b.v[1], b.v[2]); if (sp > 15) { b.v[0] *= 15 / sp; b.v[1] *= 15 / sp; b.v[2] *= 15 / sp; }
      }
    }
    for (let i = W.balls.length - 1; i >= 0; i--) { const b = W.balls[i]; b.age += DT; if (b.p[1] < this.level.rules.killY - 6 || b.age > 45) W.balls.splice(i, 1); }
  }

  lobbyTick() {
    const left = this.phaseT / TICK_HZ;
    if (this.botFill && left <= TIMING.botFillWindow && this.humanCount() > 0) {
      const want = Math.round(this.max * (1 - left / TIMING.botFillWindow) + 1);
      let guard = 3;
      while (this.activeCount() < Math.min(this.max, want) && guard-- > 0) this.addBot();
    }
    if (this.humanCount() >= this.max) this.shortenLobby(TIMING.lobbyFull);
  }

  graceCheck() {
    if (this.gt % TICK_HZ) return;
    for (const p of this.players) if (!p.bot && !p.conn && !p.left && this.gt - p.dcAt > TIMING.disconnectGrace * TICK_HZ) this.leave(p.slot);
  }

  // ---------------- round rules ----------------
  rules() {
    const L = this.level, el = (this.tick - TP) / TICK_HZ;
    const ins = this.players.filter((p) => p.status === 'in' && p.st);
    const humansIn = ins.filter((p) => !p.bot && p.conn).length;
    if (L.type === 'race') {
      const f = L.finish;
      for (const p of ins) { const q = p.st.p; if (q[0] >= f[0] && q[0] <= f[3] && q[1] >= f[1] && q[1] <= f[4] && q[2] >= f[2] && q[2] <= f[5]) this.qualify(p); }
      if (this.qualCount >= this.Q || el >= L.timeLimit) return this.endRound(el >= L.timeLimit ? 'time' : 'quota');
      if (humansIn === 0 && !this.testMode) { if (this.lastHumanDone < 0) this.lastHumanDone = this.tick; if (this.tick - this.lastHumanDone > 6 * TICK_HZ) return this.endRound('fast'); }
    } else if (L.type === 'survival') {
      for (const p of ins) if (p.st.mode === MODE.OUT) this.eliminate(p);
      const alive = this.players.filter((p) => p.status === 'in').length;
      if (alive <= this.Q || el >= L.timeLimit) return this.endRound(alive <= this.Q ? 'quota' : 'time');
      if (!this.testMode && !this.anyHumanWatching()) return this.endRound('fast');
    } else if (L.type === 'final') {
      const c = crownAt((this.tick + 1) * DT);
      for (const p of ins) {
        const s = p.st; if (s.mode === MODE.RESPAWN) continue;
        const d = Math.hypot(s.p[0] - c[0], s.p[1] + 0.3 - c[1], s.p[2] - c[2]);
        if (d < ((p.inp.b & BTN.GRAB) || s.mode === MODE.GRABBING ? 1.6 : 1.2)) { this.winner = p.slot; this.ev('crown', p.slot); return this.endRound('crown'); }
      }
      if (el >= L.timeLimit) return this.endRound('time');
      if (!this.testMode && ins.length && !this.anyHumanWatching()) return this.endRound('fast');
    }
  }

  qualify(p) {
    if (p.status !== 'in') return;
    p.status = 'q'; p.place = ++this.qualCount; p.qual++;
    if (p.st) p.st.mode = MODE.OUT;
    this.ev('q', p.slot, p.place);
  }
  eliminate(p) {
    if (p.status !== 'in') return;
    p.status = 'x'; p.xRound = this.roundIdx;
    if (p.st) p.st.mode = MODE.OUT;
    this.ev('x', p.slot);
  }

  progress(p) { // for ranking unfinished racers / final climbers
    if (!p.st) return -1e9;
    if (this.level.type === 'final') { const c = crownAt(this.tick * DT); return -Math.hypot(p.st.p[0] - c[0], p.st.p[1] - c[1], p.st.p[2] - c[2]); }
    return p.st.cp * 1000 + p.st.p[2];
  }

  endRound(reason) {
    if (this.phase !== PHASE.PLAY) return;
    const L = this.level, ins = this.players.filter((p) => p.status === 'in');
    if (L.type === 'race') {
      ins.sort((a, b) => this.progress(b) - this.progress(a));
      for (const p of ins) { if (reason === 'fast' && this.qualCount < this.Q) this.qualify(p); else this.eliminate(p); }
    } else if (L.type === 'survival') {
      if (reason === 'fast') { ins.sort(() => this.rng() - 0.5); ins.forEach((p, i) => (i < this.Q ? this.qualify(p) : this.eliminate(p))); }
      else for (const p of ins) this.qualify(p);
    } else if (L.type === 'final') {
      if (this.winner < 0 && ins.length) { ins.sort((a, b) => this.progress(b) - this.progress(a)); this.winner = ins[0].slot; this.ev('crown', this.winner); }
      const rank = ins.slice().sort((a, b) => this.progress(b) - this.progress(a));
      this.runnersUp = rank.filter((p) => p.slot !== this.winner).slice(0, 2).map((p) => p.slot);
      for (const p of ins) { if (p.slot === this.winner) { p.status = 'q'; p.qual++; if (p.st) p.st.mode = MODE.OUT; } else this.eliminate(p); }
    }
    this.flushEvents();
    this.send(-1, { t: 'roundEnd', reason, winner: this.winner });
    this.setPhase(PHASE.ROUND_END, TIMING.roundEnd);
  }

  results() {
    const qualified = this.players.filter((p) => p.status === 'q').map((p) => p.slot);
    const eliminated = this.players.filter((p) => p.status === 'x' && p.xRound === this.roundIdx).map((p) => p.slot);
    const last = this.roundIdx >= this.show.length - 1;
    const next = last || qualified.length <= 1 ? null : this.show[this.roundIdx + 1];
    this.send(-1, { t: 'results', round: this.roundIdx, qualified, eliminated, next, winner: this.winner });
    for (const p of this.players) if (!p.bot && !p.done && p.status === 'x') this.finishPlayer(p, false);
    this.setPhase(PHASE.RESULTS, TIMING.results);
  }

  podium(winnerSlot) {
    const w = this.players[winnerSlot];
    if (w) this.winner = winnerSlot;
    const top = w ? [winnerSlot, ...(this.runnersUp || [])] : [];
    for (const p of this.players) if (!p.bot && !p.done && (p.status === 'q' || p.status === 'in')) this.finishPlayer(p, p.slot === winnerSlot);
    this.send(-1, { t: 'podium', top, winner: w ? this.pub(w) : null });
    this.setPhase(PHASE.PODIUM, TIMING.podium);
  }

  finishPlayer(p, won) {
    if (p.done || p.bot) return;
    p.done = true;
    const res = { rounds: p.qual, won, totalRounds: this.show.length, matchId: this.id };
    if (this.hooks.onPlayerDone) this.hooks.onPlayerDone(p, res);
  }

  end(reason) {
    if (this.ended) return;
    for (const p of this.players) if (!p.bot && !p.done && p.status !== 'gone') this.finishPlayer(p, p.slot === this.winner);
    this.ended = true;
    this.send(-1, { t: 'end', reason, winner: this.winner >= 0 ? this.pub(this.players[this.winner]) : null });
    if (this.hooks.onEnd) this.hooks.onEnd(this.summary(reason));
  }

  summary(reason) {
    return {
      id: this.id, reason, startedAt: this.createdAt, endedAt: Date.now(), rounds: this.roundIdx + 1,
      winner: this.winner >= 0 ? { name: this.players[this.winner].name, userId: this.players[this.winner].userId, bot: this.players[this.winner].bot } : null,
      players: this.players.filter((p) => p.status !== 'gone').map((p) => ({ slot: p.slot, userId: p.userId, name: p.name, bot: p.bot, rounds: p.qual, won: p.slot === this.winner })),
    };
  }

  // ---------------- networking helpers ----------------
  ev(...e) { this.evq.push(e); }
  flushEvents() { if (this.evq.length) { this.send(-1, { t: 'ev', k: this.tick, ep: this.epoch, e: this.evq }); this.evq = []; } }

  broadcastSnap() {
    const vis = [];
    for (const p of this.players) if (p.st && p.st.mode !== MODE.OUT && p.status !== 'gone' && (p.status === 'in' || this.phase === PHASE.LOBBY)) vis.push(p);
    const body = buildSnapBody(vis, this.world.balls);
    let alive = 0; for (const p of this.players) if (p.status === 'in') alive++;
    for (const p of this.players) {
      if (p.bot || !p.conn || p.left) continue;
      let own = null;
      if (p.st && p.st.mode !== MODE.OUT && (p.status === 'in' || this.phase === PHASE.LOBBY)) { packChar(p.st, F, 0); own = F; }
      const inbuf = p.newest >= 0 ? p.newest - this.tick : -99;
      this.send(p.slot, encodeSnap({ epoch: this.epoch, tick: this.tick, inbuf, q: this.qualCount, alive, Q: this.Q || 0 }, own, body));
    }
  }
}
