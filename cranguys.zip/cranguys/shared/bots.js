// CranGuys — bot AI. Bots produce exactly the same inputs a human would (stick + buttons), so the server
// simulates them through the identical character controller. Skill controls reactions, accuracy and mistakes.
import { BTN, MODE, DT } from './config.js';
import { mulberry32, clamp, wrapPi } from './math.js';
import { crownAt } from './levels/crownpeak.js';
import { TILE, LAYERS } from './levels/tiletumble.js';
import { T_PLAY } from './levels/kit.js';

const PI = Math.PI;

export class BotBrain {
  constructor(seed, skill) {
    this.rng = mulberry32(seed);
    this.skill = skill;
    this.aggro = this.rng() < 0.12;
    this.reset();
  }
  reset() {
    const r = this.rng;
    this.node = 0; this.lane = r() * 2 - 1; this.side = r() < 0.5 ? -1 : 1;
    this.stuck = 0; this.grabT = 0; this.hes = 0; this.doorPick = {}; this.bad = new Set();
    this.target = -1; this.retarget = 0; this.rc = -1; this.wander = null; this.jumpCD = 0; this.diveCD = 0;
    this.react = 0.16 + (1 - this.skill) * 0.2 + r() * 0.06;
    this.noise = (1 - this.skill) * 0.35;
    this.lead = 0;
  }

  // m: Match, pl: player record, returns {mx, mz, b}
  input(m, pl) {
    const s = pl.st, L = m.level, W = m.world, tick = m.tick, t = tick * DT, r = this.rng;
    const out = { mx: 0, mz: 0, b: 0 };
    if (!s || s.mode === MODE.OUT || s.mode === MODE.RESPAWN) return out;
    if (m.phase !== 4 && L.type !== 'lobby') return out; // only act during PLAY
    if (this.jumpCD > 0) this.jumpCD -= DT; if (this.diveCD > 0) this.diveCD -= DT;
    // human-like hesitation
    if (this.hes > 0) { this.hes -= DT; return out; }
    if (r() < (1 - this.skill) * 0.006) { this.hes = 0.2 + r() * 0.5; return out; }
    if (s.rc !== this.rc) { this.rc = s.rc; this.node = 0; this.target = -1; this.stuck = 0; }

    let tx, tz, throttle = 1, wantJump = false, wantDive = false, wantGrab = false;
    const p = s.p;
    if (L.type === 'lobby') ({ tx, tz, throttle, wantJump } = this.lobby(p, t));
    else if (L.type === 'survival') { let hop; ({ tx, tz, throttle, hop } = this.survival(m, s, tick)); if (hop) wantJump = true; }
    else ({ tx, tz, wantGrab, wantJump } = this.route(m, s, tick));

    let dx = tx - p[0], dz = tz - p[2]; const dl = Math.hypot(dx, dz);
    if (dl > 0.05) { dx /= dl; dz /= dl; } else { dx = 0; dz = 0; throttle = 0; }
    // steering noise
    if (this.noise > 0 && dl > 0.05) { const a = Math.atan2(dx, dz) + (r() - 0.5) * this.noise; dx = Math.sin(a); dz = Math.cos(a); }
    out.mx = dx * throttle; out.mz = dz * throttle;

    // ----- obstacle / gap sensing (every other tick, staggered) -----
    if (s.gr && dl > 0.3 && ((tick + pl.slot) & 1) === 0 && s.mode === MODE.NORMAL) {
      const sp = Math.hypot(s.v[0], s.v[2]), ahead = 0.55 + sp * 0.07;
      const g = W.groundBelow(p[0] + dx * ahead, p[1] + 0.4, p[2] + dz * ahead, 4.5, tick);
      if (!g && L.type !== 'survival') wantJump = true;
      const hit = W.raycast([p[0], p[1] - 0.45, p[2]], [dx, 0, dz], 0.95, tick, (c) => !c.kin && c.tag !== 'door' && c.surf !== 4);
      if (hit && hit.n[1] < 0.5) { wantJump = true; this.grabT = 0.9; }
    }
    // stuck detection
    const sp2 = Math.hypot(s.v[0] - s.gv[0], s.v[2] - s.gv[2]);
    if (s.mode === MODE.NORMAL && throttle > 0.5 && dl > 1 && sp2 < 1.0) this.stuck += DT; else this.stuck = Math.max(0, this.stuck - DT * 2);
    if (this.stuck > 0.8 && L.type !== 'survival') {
      const nd = L.bot.route && L.bot.route[this.node];
      if (nd && nd.act === 'doors' && this.doorPick[nd.row] !== undefined) { this.bad.add(this.doorPick[nd.row]); delete this.doorPick[nd.row]; }
      else { wantJump = true; this.grabT = 1.0; this.lane = clamp(this.lane + (r() - 0.5) * 1.2, -1, 1); }
      this.stuck = 0;
    }

    // ----- hazards: sweeper arms & lasers -----
    const hz = this.hazards(m, s, t);
    if (hz === 'jump') wantJump = true; else if (hz === 'dive') wantDive = true;

    // ----- air control: extend long jumps with a dive -----
    if (!s.gr && s.mode === MODE.NORMAL && s.cd && s.v[1] < -1.5 && this.diveCD <= 0 && L.type !== 'survival' && ((tick + pl.slot) % 3) === 0) {
      const g = W.groundBelow(p[0] + s.v[0] * 0.25, p[1], p[2] + s.v[2] * 0.25, 7, tick);
      if (!g && r() < 0.35 + this.skill * 0.6) wantDive = true;
    }
    // ledge: keep pushing forward and holding grab to climb
    if (s.mode === MODE.LEDGE) { out.mx = Math.sin(s.ln); out.mz = Math.cos(s.ln); wantGrab = true; if (s.mt > 0.25) wantJump = true; }
    if (this.grabT > 0) { this.grabT -= DT; wantGrab = true; }
    // occasional chaos grabs
    if (this.aggro && s.mode === MODE.NORMAL && ((tick + pl.slot) % 15) === 0 && r() < 0.3 && m.nearestAhead(pl, 1.2)) this.grabT = 1.2 + r();
    // random silly jumps
    if (s.gr && r() < 0.004 * (1.4 - this.skill)) wantJump = true;

    if (wantJump && this.jumpCD <= 0 && (s.gr || s.co > 0 || s.mode === MODE.LEDGE)) { out.b |= BTN.JUMP; this.jumpCD = 0.25; }
    if (wantDive && this.diveCD <= 0 && s.mode === MODE.NORMAL) { out.b |= BTN.DIVE; this.diveCD = 0.8; }
    if (wantGrab) out.b |= BTN.GRAB;
    return out;
  }

  lobby(p, t) {
    const r = this.rng;
    if (!this.wander || Math.hypot(this.wander[0] - p[0], this.wander[1] - p[2]) < 1 || r() < 0.005) {
      const a = r() * PI * 2, d = r() * 13;
      this.wander = [Math.cos(a) * d, Math.sin(a) * d];
    }
    return { tx: this.wander[0], tz: this.wander[1], throttle: 0.55 + r() * 0.1, wantJump: r() < 0.008 };
  }

  route(m, s, tick) {
    const L = m.level, route = L.bot.route, p = s.p, r = this.rng;
    while (this.node < route.length - 1 && p[2] > route[this.node].p[2] - 0.4) this.node++;
    const nd = route[this.node];
    let tx = nd.p[0] * (nd.mirror ? this.side : 1) + this.lane * nd.w, tz = nd.p[2] + 1.5, wantGrab = false, wantJump = false;
    if (nd.act === 'doors') tx = this.pickDoor(m, nd.row, s, tick);
    if (nd.act === 'crown' || (L.type === 'final' && p[1] > 25 && p[2] > 123)) {
      const c = crownAt((tick + 10) * DT);
      tx = c[0]; tz = c[2];
      const dh = Math.hypot(c[0] - p[0], c[2] - p[2]);
      if (dh < 2.4 + this.skill && s.gr && r() < 0.25 + this.skill * 0.35) { this.grabT = 0.9; this.jumpCD = 0; wantJump = true; }
      if (dh < 3) wantGrab = true;
    }
    // final: dodge boulders rolling at us
    if (L.type === 'final' && m.world.balls.length) {
      for (const b of m.world.balls) {
        const dz = b.p[2] - p[2], dx = b.p[0] - p[0];
        if (dz > -1 && dz < 11 && Math.abs(dx) < 2.8 && Math.abs(b.p[1] - p[1]) < 5 && b.v[2] < -1 && r() < 0.5 + this.skill * 0.5) { tx = p[0] + (dx > 0 ? -5 : 5); tz = p[2] + 1; break; }
      }
    }
    return { tx, tz, wantGrab, wantJump };
  }

  pickDoor(m, row, s, tick) {
    const doors = m.level.doors.filter((d) => d.row === row), W = m.world, r = this.rng;
    const open = doors.filter((d) => W.isDead(d.dyn, tick));
    let cur = this.doorPick[row];
    const curOpen = cur !== undefined && W.isDead(doors.find((d) => d.id === cur).dyn, tick);
    if (cur === undefined || this.bad.has(cur) || (!curOpen && open.length && r() < 0.06)) {
      let c = open.length ? open : doors.filter((d) => !this.bad.has(d.id));
      if (!c.length) { c = doors; this.bad.clear(); }
      let best = null, bs = 1e9;
      for (const d of c) { const sc = Math.abs(d.x - s.p[0]) + r() * 5; if (sc < bs) { bs = sc; best = d; } }
      cur = this.doorPick[row] = best.id;
    }
    return doors.find((d) => d.id === cur).x + (r() - 0.5) * 0.4;
  }

  survival(m, s, tick) {
    const p = s.p, r = this.rng, tiles = m.level.tiles, touch = m.tileTouch, W = m.world;
    // tile currently under us (or the nearest one below while airborne)
    let cur = -1;
    const g = W.groundBelow(p[0], p[1] + 0.2, p[2], s.gr ? 1.5 : 12, tick);
    if (g && g.c.tag === 'tile') cur = g.c.vis.ti;
    const free = (id) => touch[id] < 0;
    const tt = this.target >= 0 ? tiles[this.target] : null;
    const reached = tt && Math.hypot(tt.x - p[0], tt.z - p[2]) < 0.8;
    this.retarget -= DT;
    if (!tt || !free(tt.id) || reached || this.retarget <= 0 || (cur >= 0 && tiles[cur].layer !== tt.layer)) {
      let best = -1, bs = -1e9;
      const pool = cur >= 0 ? tiles[cur].nb : [];
      for (const id of pool) {
        if (!free(id)) continue;
        const t = tiles[id], d = Math.hypot(t.x - p[0], t.z - p[2]);
        let freeN = 0; for (const k of t.nb) if (free(k)) freeN++;
        const sc = -Math.abs(d - 2.4) * 0.6 + freeN * 0.15 - t.ring * 0.05 + r() * 1.2 * (1.3 - this.skill);
        if (sc > bs) { bs = sc; best = id; }
      }
      if (best < 0) { // nothing adjacent: head for the nearest free tile on this layer
        const layer = cur >= 0 ? tiles[cur].layer : 2; let bd = 1e9;
        for (const t of tiles) if (t.layer === layer && free(t.id)) { const d = Math.hypot(t.x - p[0], t.z - p[2]); if (d < bd) { bd = d; best = t.id; } }
      }
      this.target = best; this.retarget = 0.5 + r() * 0.6;
    }
    const T = this.target >= 0 ? tiles[this.target] : { x: p[0] + s.v[0], z: p[2] + s.v[2] };
    const dT = Math.hypot(T.x - p[0], T.z - p[2]);
    let hop = false, throttle = 0.45 + this.skill * 0.15;
    if (s.gr && s.mode === MODE.NORMAL) {
      const dx = (T.x - p[0]) / (dT || 1), dz = (T.z - p[2]) / (dT || 1);
      const vToward = (s.v[0] - s.gv[0]) * dx + (s.v[2] - s.gv[2]) * dz;
      const age = cur >= 0 && touch[cur] >= 0 ? tick - touch[cur] : -1;
      if (dT > 2.7) { throttle = 1; if (vToward > 3.4 + (1 - this.skill)) hop = r() < 0.5 + this.skill * 0.5; }
      else if (age >= 0 && age < 8 + this.skill * 8 && dT > 0.8) throttle = 0;   // patience: use the whole tile before moving on
      if (age > 17 + (1 - this.skill) * 6) hop = true;               // about to drop: jump now!
    } else if (!s.gr) throttle = clamp(dT / 0.45 / 7.6, 0.2, 1);
    if (dT < 0.8) throttle = 0.25;
    return { tx: T.x, tz: T.z, throttle, hop };
  }

  hazards(m, s, t) {
    const p = s.p, L = m.level, r = this.rng;
    if (s.mode !== MODE.NORMAL || !s.gr) return null;
    const look = this.react + (r() - 0.5) * 0.1 * (1.5 - this.skill);
    for (const h of L.hazards) if (h.type === 'arm') {
      const res = armThreat(h.c, h.hl, h.w, h.ph, p, t, h.high);
      if (res !== null && res < (h.high ? 0.55 : 0.24 + look * 0.4) && res > (h.high ? 0 : 0.06)) return succeed(this, h.high ? 'dive' : 'jump');
    }
    if (L.lasers) for (const lz of L.lasers) {
      if (Math.abs(p[1] - lz.y) > 1.6) continue;
      if (lz.type === 'beam') {
        if (t < lz.start) continue;
        const res = armThreat(lz.c, lz.hl, lz.w, 0, p, t, false);
        if (res !== null && res < 0.22 + look * 0.4 && res > 0.05) return succeed(this, 'jump');
      } else {
        const tt = t - lz.t0; if (tt < 0) continue;
        const ph = tt % lz.period; if (ph > lz.move + 0.1) continue;
        const flip = lz.alt && Math.floor(tt / lz.period) & 1;
        const u = ph / lz.move, pos = lz.from + lz.travel * (flip ? 1 - u : u), vel = (lz.travel / lz.move) * (flip ? -1 : 1);
        const me = p[lz.axis], dt = (me - pos) / vel;
        if (lz.low && dt > 0.04 && dt < 0.2 + look * 0.4) return succeed(this, 'jump');
        if (!lz.low && dt > 0 && dt < 0.5 + look * 0.3) return succeed(this, 'dive');
      }
    }
    return null;
  }
}

function succeed(b, act) {
  // skilled bots nail the timing; weaker ones sometimes freeze
  if (b.rng() < 0.55 + b.skill * 0.45) return act;
  b.hes = 0.15; return null;
}

// time (s) until a spinning arm line sweeps over point p, or null if not reachable
function armThreat(c, hl, w, ph, p, t, high) {
  const dx = p[0] - c[0], dz = p[2] - c[2], dist = Math.hypot(dx, dz);
  if (dist > hl + 0.7 || dist < 0.9 || Math.abs(p[1] - c[1]) > (high ? 2.4 : 1.6)) return null;
  const botAng = Math.atan2(-dz, dx), armAng = ph + w * t;
  let d = wrapPi((botAng - armAng) * Math.sign(w));
  d = ((d % PI) + PI) % PI;                 // arm is a full line through the pivot
  const arc = 0.9 / dist;                   // angular half-width of the arm+bean contact
  return Math.max(0, d - arc) / Math.abs(w);
}
