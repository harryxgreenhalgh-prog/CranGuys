// CranGuys — zero-dependency bundler. Produces dist/cranguys.html: one self-contained file with the whole
// client + shared simulation inlined (ES modules flattened into scoped module functions). It runs offline
// against 59 bots, and can still connect to a CranGuys server set in Settings.
//   node tools/build.js
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ENTRY = path.join(ROOT, 'client/js/main.js');
const rel = (f) => path.relative(ROOT, f).split(path.sep).join('/');

const mods = new Map(); const order = [];
const IMPORT_RE = /^\s*import\s+(?:(\*\s+as\s+\w+)|\{([^}]*)\}|(\w+))?\s*(?:from\s*)?['"]([^'"]+)['"];?\s*$/gm;

function load(file, stack = []) {
  if (mods.has(file)) return;
  if (stack.includes(file)) throw new Error('circular import: ' + [...stack, file].map(rel).join(' -> '));
  let src = fs.readFileSync(file, 'utf8');
  const deps = [];
  src = src.replace(IMPORT_RE, (m, star, named, def, spec) => {
    if (!spec.startsWith('.')) throw new Error(`${rel(file)}: only relative imports can be bundled (${spec})`);
    const dep = path.resolve(path.dirname(file), spec);
    deps.push(dep);
    const key = JSON.stringify(rel(dep));
    if (star) return `const ${star.replace(/\*\s+as\s+/, '').trim()} = __m[${key}];`;
    if (named) {
      const parts = named.split(',').map((s) => s.trim()).filter(Boolean).map((s) => { const [a, b] = s.split(/\s+as\s+/); return b ? `${a.trim()}: ${b.trim()}` : a.trim(); });
      return `const { ${parts.join(', ')} } = __m[${key}];`;
    }
    if (def) return `const ${def} = __m[${key}].default;`;
    return '';
  });
  if (/\bimport\s*\(/.test(src)) throw new Error(`${rel(file)}: dynamic import() is not supported by the bundler`);
  const exports = [];
  src = src.replace(/^export\s+(async\s+function|function|class|const|let|var)\s+([A-Za-z_$][\w$]*)/gm, (m, kw, name) => { exports.push([name, name]); return `${kw} ${name}`; });
  src = src.replace(/^export\s*\{([^}]*)\};?\s*$/gm, (m, list) => { for (const s of list.split(',').map((x) => x.trim()).filter(Boolean)) { const [a, b] = s.split(/\s+as\s+/); exports.push([(b || a).trim(), a.trim()]); } return ''; });
  if (/^export\s/m.test(src)) throw new Error(`${rel(file)}: unsupported export form`);
  mods.set(file, { src, exports });
  for (const d of deps) load(d, [...stack, file]);
  order.push(file);
}
load(ENTRY);

let js = `/* CranGuys bundle — ${order.length} modules */\n(() => {\n'use strict';\nconst __m = {};\n`;
for (const f of order) {
  const { src, exports } = mods.get(f);
  js += `\n// ---- ${rel(f)} ----\n__m[${JSON.stringify(rel(f))}] = (() => {\n${src}\nreturn { ${exports.map(([k, v]) => (k === v ? k : `${k}: ${v}`)).join(', ')} };\n})();\n`;
}
js += '\n})();\n';

const html = fs.readFileSync(path.join(ROOT, 'client/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'client/style.css'), 'utf8');
let out = html.replace('<link rel="stylesheet" href="style.css">', () => `<style>\n${css}\n</style>`)
  .replace('<script type="module" src="js/main.js"></script>', () => `<script>\n${js.replace(/<\/script/g, '<\\/script')}</script>`);
fs.mkdirSync(path.join(ROOT, 'dist'), { recursive: true });
const dest = path.join(ROOT, 'dist/cranguys.html');
fs.writeFileSync(dest, out);
console.log(`built ${rel(dest)}: ${order.length} modules, ${(out.length / 1024).toFixed(0)} KB`);
