// Character controller behaviour: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { World } from '../shared/world.js';
import { newChar, stepChar } from '../shared/character.js';
import { PHYS, MODE, BTN, SURF } from '../shared/config.js';

const W = () => new World({ colliders: [
  { shape: 'box', p: [0, -0.5, 0], h: [20, 0.5, 20] },
  { shape: 'box', p: [0, 1, 10], h: [3, 1, 0.5] },
  { shape: 'box', p: [30, -0.5, 0], h: [5, 0.5, 20], surf: SURF.ICE },
  { shape: 'box', p: [-30, -0.5, 0], h: [5, 0.5, 20], surf: SURF.CONVEYOR, conv: [0, 0, -3.5] },
  { shape: 'box', p: [12, -0.4, -15], h: [1.5, 0.5, 1.5], surf: SURF.BOUNCY, launch: [0, 15, 6] },
  { shape: 'cap', p: [-6, 0.6, -8], r: 0.35, hl: 6, knock: 10, kin: { type: 'spin', c: [-6, 0.6, -8], axis: [0, 1, 0], w: 1.4 } },
] });
const rules = { killY: -20, respawn: true, checkpoints: [{ spawn: [0, 0, 0], spread: [2, 2], box: [0, 0, 0, 0, 0, 0] }] };
function run(world, s, inp, n, t0 = 0) {
  const ev = []; let maxY = -1e9;
  for (let t = t0; t < t0 + n; t++) { stepChar(s, typeof inp === 'function' ? inp(t) : inp, world, t, { rules, ev }); maxY = Math.max(maxY, s.p[1]); }
  return { ev: ev.filter((x) => typeof x === 'string'), maxY };
}
const idle = { mx: 0, mz: 0, b: 0 };

test('bean settles on the floor at standing height', () => {
  const s = newChar([0, 3, 0]); run(W(), s, idle, 60);
  assert.ok(Math.abs(s.p[1] - PHYS.STAND) < 0.01 && s.gr === 1);
});
test('runs at top speed', () => {
  const w = W(), s = newChar([0, PHYS.STAND, 0]); run(w, s, { mx: 0, mz: -1, b: 0 }, 45);
  assert.ok(Math.abs(Math.hypot(s.v[0], s.v[2]) - PHYS.RUN) < 0.05);
});
test('jump reaches ~1.7 m', () => {
  const w = W(), s = newChar([0, PHYS.STAND, 0]); run(w, s, idle, 5);
  const r = run(w, s, (t) => ({ mx: 0, mz: 0, b: t < 8 ? BTN.JUMP : 0 }), 40, 5);
  assert.ok(r.maxY - PHYS.STAND > 1.55 && r.maxY - PHYS.STAND < 1.9, 'apex ' + (r.maxY - PHYS.STAND));
});
test('dive -> belly slide -> get up', () => {
  const w = W(), s = newChar([0, PHYS.STAND, 0]); run(w, s, idle, 5);
  const r = run(w, s, (t) => ({ mx: 0, mz: -1, b: t === 13 ? BTN.DIVE : 0 }), 70, 5);
  assert.deepEqual(r.ev.filter((e) => ['dive', 'belly'].includes(e)), ['dive', 'belly']);
  assert.equal(s.mode, MODE.NORMAL);
});
test('ledge grab and climb onto a 2 m wall', () => {
  const w = W(), s = newChar([0, PHYS.STAND, 6]); run(w, s, idle, 5);
  const r = run(w, s, (t) => ({ mx: 0, mz: 1, b: (t >= 13 && t < 15 ? BTN.JUMP : 0) | BTN.GRAB }), 40, 5);
  assert.ok(r.ev.includes('ledge') && r.ev.includes('climb'));
  assert.ok(s.p[1] > 2.5, 'on top of wall: y=' + s.p[1]);
});
test('ice is slippery, conveyors push, bouncy pads launch', () => {
  const w = W();
  const ice = newChar([30, PHYS.STAND, 0]); run(w, ice, { mx: 0, mz: 1, b: 0 }, 40); run(w, ice, idle, 30, 40);
  assert.ok(ice.v[2] > 3, 'still sliding on ice');
  const cv = newChar([-30, PHYS.STAND, 0]); run(w, cv, idle, 30);
  assert.ok(Math.abs(cv.v[2] + 3.5) < 0.1, 'carried by conveyor');
  const b = newChar([12, 2, -15]); const r = run(w, b, idle, 40);
  assert.ok(r.ev.includes('bounce') && r.maxY > 4);
});
test('spinning sweeper ragdolls a standing bean, jumping avoids it', () => {
  const w = W();
  const a = newChar([-6, PHYS.STAND, -3]); const r = run(w, a, idle, 90);
  assert.ok(r.ev.includes('rag'), 'knocked');
  const b = newChar([-6, PHYS.STAND, -3]); const r2 = run(W(), b, (t) => ({ mx: 0, mz: 0, b: t % 20 === 0 ? BTN.JUMP : 0 }), 90);
  assert.ok(!r2.ev.includes('rag'), 'timed jumps clear the low arm');
});
test('falling off respawns at the checkpoint', () => {
  const s = newChar([0, PHYS.STAND, 19.5]); const r = run(W(), s, (t) => ({ mx: 0, mz: t < 20 ? 1 : 0, b: 0 }), 120);
  assert.ok(r.ev.includes('fall') && r.ev.includes('respawn'));
  assert.ok(Math.abs(s.p[2]) < 2);
});
