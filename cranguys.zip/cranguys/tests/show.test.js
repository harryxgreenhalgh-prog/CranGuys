// A whole 60-bean show runs to a crowned winner, within the server's per-tick budget.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Match } from '../shared/game.js';

test('full 60-bot show produces a winner', () => {
  const rounds = []; let podium = null, worst = 0;
  const m = new Match({ seed: 21, testMode: true, lobbySecs: 1, send: (s, msg) => {
    if (s !== -1 || msg instanceof Uint8Array) return;
    if (msg.t === 'round') rounds.push([msg.level, msg.count, msg.Q]);
    if (msg.t === 'podium') podium = msg;
  } });
  let n = 0;
  while (!m.ended && n < 30 * 60 * 15) { const t = performance.now(); m.step(); worst = Math.max(worst, performance.now() - t); n++; }
  assert.ok(m.ended);
  assert.deepEqual(rounds.map((r) => r[0]), ['whirlway', 'tiletumble', 'crownpeak']);
  assert.equal(rounds[0][1], 60);
  assert.ok(podium && podium.winner, 'someone won the crown');
  assert.ok(worst < 150, 'worst tick ' + worst.toFixed(1) + 'ms');
});
