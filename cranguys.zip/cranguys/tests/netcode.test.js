// Protocol encoding + prediction determinism + reconciliation.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Match, TP } from '../shared/game.js';
import { World } from '../shared/world.js';
import { freshLevel } from '../shared/levels/index.js';
import { encodeInput, decodeInput, decodeSnap, qAxis } from '../shared/protocol.js';
import { newChar, stepChar, unpackChar, packChar, NFIELDS } from '../shared/character.js';
import { BTN, PHASE } from '../shared/config.js';

test('input encode/decode round-trip', () => {
  const d = decodeInput(encodeInput(7, 123456, 0.5, -1, BTN.JUMP | BTN.GRAB));
  assert.equal(d.epoch, 7); assert.equal(d.tick, 123456); assert.equal(d.b, BTN.JUMP | BTN.GRAB);
  assert.equal(d.mx, qAxis(0.5) / 127); assert.equal(d.mz, -1);
});

// Run a real Match with one "human" whose inputs we feed exactly on time, while an independent client
// world predicts the same inputs. With no other interference the predicted state must match the server.
test('client prediction matches the authoritative server', () => {
  let snaps = [];
  const m = new Match({ seed: 99, show: ['whirlway'], lobbySecs: 1, botFill: false, testMode: true, send: (slot, msg) => { if (slot === 0 && msg instanceof Uint8Array) snaps.push(decodeSnap(msg)); } });
  const slot = m.addPlayer({ userId: 'u', name: 'Me', cos: null });
  while (m.phase === PHASE.LOBBY) m.step();
  assert.equal(m.levelId, 'whirlway');
  // client world built from the same level id + seed
  const L = freshLevel(m.levelId, m.levelSeed), W = new World(L);
  const inputs = (t) => ({ mx: qAxis(Math.sin(t * 0.05) * 0.6) / 127, mz: 1, b: t % 37 === 0 ? BTN.JUMP : t % 53 === 0 ? BTN.DIVE : 0 });
  let client = null, maxErr = 0;
  for (let i = 0; i < TP + 400; i++) {
    const t = m.tick;
    if (t >= TP) m.input(slot, m.epoch, t, ...Object.values(inputs(t)));
    m.step();
    if (!client && snaps.length && snaps[snaps.length - 1].own) { const s = snaps[snaps.length - 1]; client = unpackChar(s.own, 0, newChar([0, 0, 0])); client._t = s.tick + 1; }
    if (client) {
      while (client._t <= t) { stepChar(client, client._t >= TP ? inputs(client._t) : { mx: 0, mz: 0, b: 0 }, W, client._t, { rules: L.rules, ev: null, slot }); client._t++; }
      const sv = m.players[slot].st;
      maxErr = Math.max(maxErr, Math.hypot(sv.p[0] - client.p[0], sv.p[1] - client.p[1], sv.p[2] - client.p[2]));
    }
  }
  assert.ok(m.players[slot].st.p[2] > 30, 'bean made progress: z=' + m.players[slot].st.p[2]);
  assert.ok(maxErr < 0.01, 'prediction drift ' + maxErr);
});

test('reconciliation replays unacknowledged inputs from the server state', () => {
  const L = freshLevel('lobby', 1), W = new World(L);
  const ctx = { rules: L.rules, ev: null, slot: 0 };
  const server = newChar([0, 0.78, 5]); const client = newChar([0, 0.78, 5]);
  const hist = new Map();
  for (let t = 0; t < 30; t++) { const inp = { mx: 1, mz: 0, b: t === 10 ? BTN.JUMP : 0 }; hist.set(t, inp); stepChar(client, inp, W, t, ctx); }
  // server only processed ticks 0..19 (and got the same inputs)
  for (let t = 0; t < 20; t++) stepChar(server, hist.get(t), W, t, ctx);
  const packed = new Float32Array(NFIELDS);
  packChar(server, packed, 0);
  const rep = unpackChar(packed, 0, newChar([0, 0, 0]));
  for (let t = 20; t < 30; t++) stepChar(rep, hist.get(t), W, t, ctx);
  assert.ok(Math.hypot(rep.p[0] - client.p[0], rep.p[1] - client.p[1], rep.p[2] - client.p[2]) < 0.005);
});
