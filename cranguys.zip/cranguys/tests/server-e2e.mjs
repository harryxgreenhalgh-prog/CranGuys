// End-to-end: real server process + real WebSocket clients (Node's built-in WebSocket) + REST economy.
import { spawn } from 'node:child_process';
import { encodeInput, decodeSnap } from '../shared/protocol.js';
import { PROTO, BTN } from '../shared/config.js';
import assert from 'node:assert/strict';
const PORT = 18000 + Math.floor(Math.random() * 1000), BASE = `http://127.0.0.1:${PORT}`;
const srv = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, PORT, DATA_DIR: '/tmp/cg-test-' + PORT, LOBBY_SECONDS: '3', TIME_SCALE: '8' }, stdio: ['ignore', 'pipe', 'pipe'] });
let out = ''; srv.stdout.on('data', d => out += d); srv.stderr.on('data', d => out += d);
const sleep = ms => new Promise(r => setTimeout(r, ms));
for (let i = 0; i < 50 && !out.includes('listening'); i++) await sleep(100);
const api = async (method, path, body, token) => { const r = await fetch(BASE + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined }); return { status: r.status, ...(await r.json()) }; };
try {
  // ---- REST: accounts & economy ----
  const g1 = await api('POST', '/api/auth/guest', { name: 'Tester' });
  assert.ok(g1.token && g1.profile.berries === 1200, 'guest created with starter balance');
  const me = await api('GET', '/api/me', null, g1.token); assert.equal(me.profile.name, 'Tester');
  const bad = await api('GET', '/api/me', null, g1.token + 'x'); assert.equal(bad.status, 401, 'tampered token rejected');
  const shop = await api('GET', '/api/shop'); assert.equal(shop.items.length, 6);
  const cheap = shop.catalog.find(i => i.price.b && i.price.b <= 1200);
  const buy = await api('POST', '/api/shop/buy', { itemId: cheap.id }, g1.token);
  assert.ok(buy.profile.owned.includes(cheap.id) && buy.profile.berries === 1200 - cheap.price.b, 'purchase debits & grants');
  const again = await api('POST', '/api/shop/buy', { itemId: cheap.id }, g1.token); assert.equal(again.error, 'owned', 'no double buy');
  const notShop = await api('POST', '/api/shop/buy', { itemId: 'c_rainbow' }, g1.token); assert.ok(['not_in_shop', 'funds'].includes(notShop.error));
  const eq = await api('POST', '/api/locker/equip', { loadout: { [cheap.slot === 'color' ? 'color' : cheap.slot]: cheap.id } }, g1.token); assert.ok(Object.values(eq.profile.loadout).includes(cheap.id), 'equip owned item');
  const eqBad = await api('POST', '/api/locker/equip', { loadout: { hat: 'h_pirate' } }, g1.token); assert.equal(eqBad.error, 'not_owned');
  const reg = await api('POST', '/api/auth/register', { username: 'tester_' + PORT, password: 'hunter22' }, g1.token); assert.ok(reg.token && !reg.profile.guest, 'guest upgraded');
  const oldTok = await api('GET', '/api/me', null, g1.token); assert.equal(oldTok.status, 401, 'old guest token revoked after upgrade');
  const login = await api('POST', '/api/auth/login', { username: 'tester_' + PORT, password: 'hunter22' }); assert.ok(login.token);
  const wrong = await api('POST', '/api/auth/login', { username: 'tester_' + PORT, password: 'nope123' }); assert.equal(wrong.status, 401);
  console.log('REST ok: guest, shop, buy, equip, register, login');

  // ---- realtime: two humans join the same show and play ----
  const tokens = [login.token, (await api('POST', '/api/auth/guest', { name: 'Buddy' })).token];
  const clients = tokens.map((tok, k) => new Promise((resolve) => {
    const ws = new WebSocket(`ws://127.0.0.1:${PORT}/ws`); ws.binaryType = 'arraybuffer';
    const st = { k, snaps: 0, msgs: {}, you: -1, epoch: 0, tick: 0, rounds: [], reward: null, ended: false, own: 0, maxPlayers: 0 };
    ws.onopen = () => ws.send(JSON.stringify({ t: 'hello', token: tok, v: PROTO }));
    let iv;
    ws.onmessage = (e) => {
      if (typeof e.data !== 'string') {
        const s = decodeSnap(e.data); st.snaps++; st.epoch = s.epoch; st.tick = s.tick; if (s.own) st.own++; st.maxPlayers = Math.max(st.maxPlayers, s.players.length);
        return;
      }
      const m = JSON.parse(e.data); st.msgs[m.t] = (st.msgs[m.t] || 0) + 1;
      if (m.t === 'welcome') ws.send(JSON.stringify({ t: 'queue' }));
      if (m.t === 'match') { st.you = m.you; st.epoch = m.epoch; iv = setInterval(() => { st.tick++; ws.send(encodeInput(st.epoch, st.tick + 3, 0, 1, st.tick % 20 === 0 ? BTN.JUMP : 0)); }, 33); }
      if (m.t === 'round') st.rounds.push(m.level);
      if (m.t === 'reward') st.reward = m;
      if (m.t === 'end') { st.ended = true; clearInterval(iv); ws.close(); resolve(st); }
    };
    setTimeout(() => { clearInterval(iv); ws.close(); resolve(st); }, 90000);
  }));
  const [a, b] = await Promise.all(clients);
  for (const s of [a, b]) console.log(`client${s.k}: slot=${s.you} snaps=${s.snaps} withOwnState=${s.own} maxVisible=${s.maxPlayers} rounds=${s.rounds.join('>')} ended=${s.ended} reward=${s.reward && JSON.stringify(s.reward.reward)} msgs=${JSON.stringify(s.msgs)}`);
  assert.ok(a.you >= 0 && b.you >= 0 && a.you !== b.you, 'both humans placed in the same show');
  assert.ok(a.snaps > 50 && a.maxPlayers === 60, 'snapshots carry all 60 beans');
  assert.ok(a.reward && a.reward.reward.applied, 'server granted rewards');
  const after = await api('GET', '/api/me', null, login.token);
  assert.ok(after.profile.shows === 1 && after.profile.xp > 0, 'profile stats updated');
  const lb = await api('GET', '/api/leaderboard'); assert.ok(lb.top.length >= 1);
  const status = await api('GET', '/api/status'); console.log('status', JSON.stringify(status));
  console.log('E2E PASSED');
} catch (e) { console.error('E2E FAILED', e); console.error(out.slice(-3000)); process.exitCode = 1; }
finally { srv.kill('SIGTERM'); }
