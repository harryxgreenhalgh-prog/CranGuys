// iPad-sized UI screenshots of the single-file build (dist/cranguys.html), touch enabled.
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const http = require('http'); const fs = require('fs'); const path = require('path');
const ROOT = path.resolve(__dirname, '..'), SHOTS = ROOT + '/shots/ui'; fs.mkdirSync(SHOTS, { recursive: true });
const srv = http.createServer((req, res) => { if (req.url === '/' || req.url.startsWith('/?')) { res.writeHead(200, { 'Content-Type': 'text/html' }); return fs.createReadStream(ROOT + '/dist/cranguys.html').pipe(res); } res.writeHead(404); res.end(); }).listen(0);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await browser.newContext({ viewport: { width: 1180, height: 820 }, hasTouch: true, isMobile: false, deviceScaleFactor: 1 });
  const page = await ctx.newPage(); const errs = new Set();
  page.on('pageerror', (e) => errs.add('pageerror ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/TUNNEL|Failed to load/.test(m.text())) errs.add('console ' + m.text().slice(0, 200)); });
  await page.addInitScript(() => { localStorage.setItem('cg.settings', JSON.stringify({ quality: 'medium' })); Object.defineProperty(window, 'ontouchstart', { value: null }); });
  await page.goto(`http://127.0.0.1:${srv.address().port}/`); await sleep(3500);
  const shot = async (n) => page.screenshot({ path: `${SHOTS}/${n}.png` });
  await shot('01-menu');
  await page.evaluate(() => CG.goto('locker')); await sleep(800); await page.click('#lockerTabs button[data-tab=hat]'); await sleep(300);
  await page.evaluate(() => CG.equip('hat', 'h_party')); await sleep(900); await shot('02-locker');
  await page.click('#lockerTabs button[data-tab=pattern]'); await sleep(200); await page.evaluate(() => { CG.equip('pattern', 'p_stripes'); CG.equip('color2', 'c_sunny'); }); await sleep(900); await shot('03-locker-pattern');
  await page.evaluate(() => CG.goto('shop')); await sleep(1500); await shot('04-shop');
  await page.evaluate(() => CG.goto('menu')); await sleep(300); await page.click('[data-act=settings]'); await sleep(600); await shot('05-settings'); await page.click('[data-act=closeModal]');
  await page.click('[data-act=account]'); await sleep(800); await shot('06-account'); await page.click('[data-act=closeModal]'); await sleep(300);
  await page.evaluate(() => CG.play()); await sleep(4000); await shot('07-lobby-touch');
  const t0 = Date.now(); let introShot = false, playShots = 0;
  while (Date.now() - t0 < 70000 && playShots < 3) {
    await sleep(800);
    const ph = await page.evaluate(() => CG.game && CG.game.phase);
    if (ph === 2 && !introShot) { await sleep(1500); await shot('08-intro'); introShot = true; }
    if (ph === 4) { await sleep(2500); await shot('09-play-touch-' + playShots); playShots++; }
  }
  console.log('errors:', errs.size ? [...errs].join('\n') : 'none');
  await browser.close(); srv.close();
})();
