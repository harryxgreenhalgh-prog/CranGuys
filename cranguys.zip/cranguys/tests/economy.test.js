// Accounts, purchases and rewards against both storage backends.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { openStore } from '../server/db.js';
import { Economy } from '../server/economy.js';
import { Auth } from '../server/auth.js';
import { dailyShop, itemById, CATALOG } from '../shared/cosmetics.js';

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'cg-'));

test('guest profile, purchase, equip, idempotent rewards', async () => {
  const store = await openStore(tmp()); const econ = new Economy(store), auth = new Auth('x'.repeat(32), store);
  const u = econ.newGuest('Tester');
  let p = econ.profile(u.id);
  assert.equal(p.berries, 1200); assert.equal(p.loadout.color, 'c_bubblegum');
  // token round-trip & tamper rejection
  const tok = auth.sign(u); assert.equal(auth.verify(tok).id, u.id); assert.equal(auth.verify(tok.slice(0, -2) + 'xx'), null);
  // buy the cheapest item in today's shop
  const s = dailyShop(); const it = [s.featured, ...s.items].map(itemById).filter((i) => i.price.b).sort((a, b) => a.price.b - b.price.b)[0];
  p = econ.buy(u.id, it.id);
  assert.ok(p.owned.includes(it.id)); assert.equal(p.berries, 1200 - it.price.b);
  assert.throws(() => econ.buy(u.id, it.id), /already own/);
  const notInShop = CATALOG.find((i) => i.price.b && i.id !== s.featured && !s.items.includes(i.id) && !p.owned.includes(i.id));
  assert.throws(() => econ.buy(u.id, notInShop.id), /not in today/);
  // equip
  const slot = it.slot === 'color' ? 'color2' : it.slot;
  p = econ.equip(u.id, { [slot]: it.id }); assert.equal(p.loadout[slot], it.id);
  assert.throws(() => econ.equip(u.id, { hat: 'h_pirate' }), /own/);
  // rewards are applied exactly once per match
  const r1 = econ.reward(u.id, { matchId: 'm1', rounds: 3, won: true, totalRounds: 3 });
  const r2 = econ.reward(u.id, { matchId: 'm1', rounds: 3, won: true, totalRounds: 3 });
  assert.ok(r1.applied && !r2.applied);
  p = econ.profile(u.id);
  assert.equal(p.wins, 1); assert.equal(p.crowns, 1); assert.ok(p.owned.includes('h_crown'), 'first win unlocks the crown');
});

test('cannot overspend (atomic purchase)', async () => {
  const store = await openStore(tmp()); const econ = new Economy(store);
  const u = econ.newGuest('Broke');
  const s = dailyShop();
  let spent = 0;
  for (const id of [s.featured, ...s.items]) { try { econ.buy(u.id, id); spent++; } catch (e) { assert.match(e.message, /Not enough|already/); } }
  const p = econ.profile(u.id);
  assert.ok(p.berries >= 0 && p.crowns >= 0);
});
