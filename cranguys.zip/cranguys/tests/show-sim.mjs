// Headless 60-bot show: verifies every round can be completed by bots and measures server tick cost.
import { Match } from '../shared/game.js';
import { PHASE_NAME, TICK_HZ } from '../shared/config.js';
const seed = +(process.argv[2] || 7);
const log = [];
const m = new Match({ seed, testMode: true, lobbySecs: 1, send: (slot, msg) => {
  if (slot !== -1 || msg instanceof Uint8Array) return;
  if (msg.t === 'round') log.push(`ROUND ${msg.i} ${msg.level} players=${msg.count} Q=${msg.Q}`);
  if (msg.t === 'roundEnd') log.push(`  end reason=${msg.reason} at ${(m.tick/TICK_HZ).toFixed(1)}s q=${m.qualCount}`);
  if (msg.t === 'results') log.push(`  results qualified=${msg.qualified.length} eliminated=${msg.eliminated.length}`);
  if (msg.t === 'podium') log.push(`PODIUM winner=${msg.winner && msg.winner.n}`);
  if (msg.t === 'ev') for (const e of msg.e) { if (e[0]==='q' && (e[2]===1||e[2]%10===0)) log.push(`  q#${e[2]} at ${(m.tick/TICK_HZ).toFixed(1)}s`); if (e[0]==='crown') log.push(`  CROWN by ${e[1]} at ${(m.tick/TICK_HZ).toFixed(1)}s`); }
}});
m.botFill = true;
let ticks = 0, worst = 0; const t0 = performance.now();
const roundStats = {};
while (!m.ended && ticks < 30 * 60 * 14) {
  const a = performance.now(); m.step(); const d = performance.now() - a; if (d > worst) worst = d; ticks++;
  // track falls / tiles per round
  if (m.phase === 4 && m.tick % 300 === 0) {
    const ins = m.players.filter(p => p.status === 'in' && p.st);
    const cps = {}; for (const p of ins) cps[p.st.cp] = (cps[p.st.cp]||0)+1;
    const rag = ins.filter(p=>p.st.mode===4).length, resp = ins.filter(p=>p.st.mode===8).length;
    log.push(`    t=${(m.tick/TICK_HZ).toFixed(0)}s in=${ins.length} cps=${JSON.stringify(cps)} rag=${rag} respawning=${resp} avgZ=${(ins.reduce((s,p)=>s+p.st.p[2],0)/Math.max(1,ins.length)).toFixed(1)} avgY=${(ins.reduce((s,p)=>s+p.st.p[1],0)/Math.max(1,ins.length)).toFixed(1)}`);
  }
}
const el = performance.now() - t0;
console.log(log.join('\n'));
console.log(`ended=${m.ended} ticks=${ticks} wall=${(el/1000).toFixed(1)}s avg=${(el/ticks).toFixed(2)}ms/tick worst=${worst.toFixed(1)}ms`);
