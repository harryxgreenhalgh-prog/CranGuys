// Full offline show in the browser with the autopilot driving the player's bean; screenshots each stage.
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const http = require('http'); const fs = require('fs'); const path = require('path');
const ROOT = path.resolve(__dirname, '..'), SHOTS = ROOT + '/shots/show'; fs.mkdirSync(SHOTS, { recursive: true });
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
// static-only server (no API): the client falls back to offline mode
const srv = http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname); if (p === '/') p = '/index.html';
  const f = p.startsWith('/shared/') ? path.join(ROOT, p) : path.join(ROOT, 'client', p);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' }); fs.createReadStream(f).pipe(res);
}).listen(0);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const port = srv.address().port;
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const W = +(process.env.W || 640), H = +(process.env.H || 400);
  const ctx = await browser.newContext({ viewport: { width: W, height: H }, hasTouch: !!process.env.TOUCH });
  const page = await ctx.newPage(); const errs = new Set();
  page.on('pageerror', (e) => errs.add('pageerror ' + e.message + ' ' + (e.stack || '').split('\n').slice(0, 3).join(' | ')));
  page.on('console', (m) => { if (m.type() === 'error' && !m.text().includes('TUNNEL') && !m.text().includes('Failed to load')) errs.add('console ' + m.text().slice(0, 300)); });
  await page.addInitScript((q) => localStorage.setItem('cg.settings', JSON.stringify({ quality: q, fps: true })), process.env.Q || 'low');
  await page.goto(`http://127.0.0.1:${port}/`); await sleep(2500);
  await page.evaluate(() => { CG.autopilot = true; CG.play(); });
  const seen = {}; const t0 = Date.now(); let last = '';
  while (Date.now() - t0 < (+process.env.MAXS || 420) * 1000) {
    await sleep(700);
    const s = await page.evaluate(() => { const g = CG.game; return { st: CG.state, ph: g ? g.phase : 0, lvl: g ? g.levelId : '', active: g ? g.meActive : false, fps: Math.round(CG.fpsVal), mode: g ? g.me.mode : -1, z: g ? +g.me.p[2].toFixed(1) : 0, y: g ? +g.me.p[1].toFixed(1) : 0, counts: g ? g.counts : null, stats: g ? g.stats : null, lead: g ? +g.lead.toFixed(1) : 0, buf: g ? g.inbuf : 0, rewards: document.querySelector('#rewards').classList.contains('show') }; });
    const key = `${s.st}-${s.lvl}-${s.ph}`;
    if (key !== last) { console.log(((Date.now() - t0) / 1000).toFixed(0) + 's', JSON.stringify(s)); last = key; }
    const shotKey = key + (s.ph === 4 ? '-' + Math.floor((Date.now() - t0) / 15000) : '');
    if (!seen[shotKey]) { seen[shotKey] = 1; await page.screenshot({ path: `${SHOTS}/${String(Object.keys(seen).length).padStart(2, '0')}-${shotKey}.png` }); }
    if (s.rewards) { await sleep(2500); await page.screenshot({ path: `${SHOTS}/99-rewards.png` }); break; }
  }
  console.log('errors:', errs.size ? [...errs].slice(0, 8).join('\n') : 'none');
  await browser.close(); srv.close();
})();
