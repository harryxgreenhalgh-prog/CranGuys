// Browser smoke test: real server + Chrome (SwiftShader WebGL2). Screenshots every screen and a live show.
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const { spawn } = require('child_process');
const fs = require('fs');
const PORT = 18500 + Math.floor(Math.random() * 400);
const ARGS = ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'];
const SHOTS = __dirname + '/../shots'; fs.mkdirSync(SHOTS, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const srv = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { cwd: __dirname + '/..', env: { ...process.env, PORT, DATA_DIR: '/tmp/cg-b-' + PORT, LOBBY_SECONDS: process.env.LOBBY || '6' }, stdio: ['ignore', 'pipe', 'pipe'] });
  let slog = ''; srv.stdout.on('data', (d) => (slog += d)); srv.stderr.on('data', (d) => (slog += d));
  for (let i = 0; i < 50 && !slog.includes('listening'); i++) await sleep(100);
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ARGS });
  const ctx = await browser.newContext({ viewport: { width: +(process.env.W || 1280), height: +(process.env.H || 800) }, hasTouch: !!process.env.TOUCH, isMobile: false });
  const page = await ctx.newPage(); const errs = [];
  page.on('pageerror', (e) => errs.push('pageerror ' + e.message + '\n' + e.stack));
  page.on('console', (m) => { if (m.type() === 'error') errs.push('console ' + m.text()); });
  await page.goto(`http://127.0.0.1:${PORT}/`);
  await sleep(3500);
  await page.screenshot({ path: SHOTS + '/01-menu.png' });
  const steps = (process.env.STEPS || 'menu').split(',');
  if (steps.includes('locker')) { await page.click('[data-go=locker]'); await sleep(900); await page.screenshot({ path: SHOTS + '/02-locker.png' }); await page.click('#lockerTabs button[data-tab=hat]'); await sleep(300); await page.click('#lockerGrid .item:nth-child(2)'); await sleep(900); await page.screenshot({ path: SHOTS + '/03-locker-hat.png' }); }
  if (steps.includes('shop')) { await page.click('#locker .back, #menu [data-go=shop]').catch(()=>{}); await page.evaluate(() => CG.goto('shop')); await sleep(1200); await page.screenshot({ path: SHOTS + '/04-shop.png' }); }
  if (steps.includes('settings')) { await page.evaluate(() => CG.goto('menu')); await page.click('[data-act=settings]'); await sleep(600); await page.screenshot({ path: SHOTS + '/05-settings.png' }); await page.click('[data-act=closeModal]'); await sleep(300); }
  if (steps.includes('play')) {
    await page.evaluate(() => CG.goto('menu')); await sleep(300);
    if (process.env.OFFLINE) await page.evaluate(() => CG.setMode('offline'));
    await page.click('#playBtn', { force: true }); await sleep(2500);
    await page.screenshot({ path: SHOTS + '/06-lobby.png' });
    // drive the bean forward + jump periodically
    await page.keyboard.down('KeyW');
    const t0 = Date.now(); let n = 0; const want = (process.env.SHOTS_AT || '9,13,17,24,32,45').split(',').map(Number);
    while (Date.now() - t0 < +(process.env.DUR || 60) * 1000) {
      await sleep(500);
      const el = (Date.now() - t0) / 1000;
      if (Math.floor(el * 2) % 5 === 0) { await page.keyboard.press('Space'); }
      if (n < want.length && el > want[n]) { await page.screenshot({ path: `${SHOTS}/07-show-${String(n).padStart(2, '0')}.png` }); n++; }
    }
    const st = await page.evaluate(() => { const g = CG.game; return g ? { phase: g.phase, level: g.levelId, active: g.meActive, lead: g.lead, inbuf: g.inbuf, stats: g.stats, me: g.me.p.map((x) => +x.toFixed(2)), mode: g.me.mode, counts: g.counts, roster: g.roster.size } : { state: CG.state }; });
    console.log('game state', JSON.stringify(st));
  }
  console.log('errors:', errs.length ? errs.slice(0, 8).join('\n') : 'none');
  await browser.close(); srv.kill();
  if (process.env.SLOG) console.log(slog.slice(-2000));
})();
