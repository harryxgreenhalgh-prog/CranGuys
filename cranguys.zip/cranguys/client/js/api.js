// CranGuys — backends. RemoteBackend talks to the CranGuys cloud API (auth, profile, locker, shop).
// LocalBackend is the offline economy (same rules, stored on this device) used for bot shows.
import { store } from './util.js';
import { dailyShop, itemById, DEFAULT_OWNED, DEFAULT_LOADOUT, START_BALANCE, sanitizeLoadout, computeRewards, levelForXp, LEVEL_UP_BONUS } from '../../shared/cosmetics.js';
import { beanName } from '../../shared/names.js';

export class RemoteBackend {
  constructor(base) { this.kind = 'online'; this.base = base.replace(/\/$/, ''); this.token = store.get('cg.token:' + this.base); this.profile = null; }
  async req(method, path, body) {
    const r = await fetch(this.base + path, { method, headers: { 'Content-Type': 'application/json', ...(this.token ? { Authorization: 'Bearer ' + this.token } : {}) }, body: body ? JSON.stringify(body) : undefined });
    let j = {}; try { j = await r.json(); } catch {}
    if (!r.ok) { const e = new Error(j.message || 'Request failed (' + r.status + ')'); e.code = j.error; e.status = r.status; throw e; }
    if (j.token) { this.token = j.token; store.set('cg.token:' + this.base, j.token); }
    if (j.profile) this.profile = j.profile;
    return j;
  }
  async init(name) {
    if (this.token) { try { await this.req('GET', '/api/me'); return this.profile; } catch (e) { if (e.status !== 401) throw e; this.token = null; } }
    await this.req('POST', '/api/auth/guest', { name }); return this.profile;
  }
  async status() { return this.req('GET', '/api/status'); }
  async equip(loadout) { return (await this.req('POST', '/api/locker/equip', { loadout })).profile; }
  async buy(itemId) { return (await this.req('POST', '/api/shop/buy', { itemId })).profile; }
  async shop() { return this.req('GET', '/api/shop'); }
  async rename(name) { return (await this.req('POST', '/api/me/name', { name })).profile; }
  async register(username, password) { return (await this.req('POST', '/api/auth/register', { username, password })).profile; }
  async login(username, password) { return (await this.req('POST', '/api/auth/login', { username, password })).profile; }
  async leaderboard() { return (await this.req('GET', '/api/leaderboard')).top; }
  async logout() { this.token = null; store.del('cg.token:' + this.base); return this.init(); }
  wsUrl() { return this.base.replace(/^http/, 'ws') + '/ws'; }
  setProfile(p) { this.profile = p; }
}

const KEY = 'cg.local.profile';
export class LocalBackend {
  constructor() { this.kind = 'offline'; this.profile = null; }
  load() {
    let p = store.get(KEY);
    if (!p) {
      p = { id: 'local', name: beanName(Math.random), username: null, guest: true, ...START_BALANCE, xp: 0, wins: 0, shows: 0, finals: 0, rounds: 0, owned: DEFAULT_OWNED.slice(), loadout: { ...DEFAULT_LOADOUT }, refs: [] };
      store.set(KEY, p);
    }
    return p;
  }
  pub(p) { const { refs, ...rest } = p; return { ...rest, level: levelForXp(p.xp), loadout: sanitizeLoadout(p.loadout, new Set(p.owned)) }; }
  save(p) { store.set(KEY, p); this.profile = this.pub(p); return this.profile; }
  async init() { this.profile = this.pub(this.load()); return this.profile; }
  async status() { return { online: 1, queue: 0, shows: 0, lobbies: 0 }; }
  async equip(lo) {
    const p = this.load(), owned = new Set(p.owned);
    for (const id of Object.values(lo)) if (id && !owned.has(id)) throw new Error('You don’t own that yet');
    p.loadout = sanitizeLoadout({ ...p.loadout, ...lo }, owned); return this.save(p);
  }
  async shop() { const s = dailyShop(); return { ...s, catalog: [s.featured, ...s.items].map(itemById) }; }
  async buy(id) {
    const p = this.load(), it = itemById(id), s = dailyShop();
    if (!it || (id !== s.featured && !s.items.includes(id))) throw new Error('That item is not in today’s shop');
    if (p.owned.includes(id)) throw new Error('You already own this');
    const b = it.price.b || 0, c = it.price.c || 0;
    if (p.berries < b || p.crowns < c) throw new Error('Not enough ' + (b ? 'Cranberries' : 'Crowns'));
    p.berries -= b; p.crowns -= c; p.owned.push(id); return this.save(p);
  }
  async rename(name) { const n = String(name || '').replace(/[^\p{L}\p{N}_ .-]/gu, '').trim().slice(0, 16); if (n.length < 2) throw new Error('Names need 2–16 letters or numbers'); const p = this.load(); p.name = n; return this.save(p); }
  async register() { throw new Error('Accounts need an online CranGuys server'); }
  async login() { throw new Error('Accounts need an online CranGuys server'); }
  async leaderboard() { const p = this.load(); return [{ name: p.name + ' (you)', wins: p.wins, crowns: p.crowns, xp: p.xp, shows: p.shows }]; }
  async logout() { return this.init(); }
  // authoritative-on-device rewards for offline shows
  reward(res) {
    const p = this.load(), ref = 'match:' + res.matchId;
    if (p.refs.includes(ref)) return null;
    const r = computeRewards(res), l0 = levelForXp(p.xp);
    p.berries += r.berries; p.crowns += r.crowns; p.xp += r.xp; p.shows++; p.rounds += res.rounds; if (res.won) p.wins++; if (res.rounds >= res.totalRounds - 1) p.finals++;
    const l1 = levelForXp(p.xp); let levelUp = 0;
    if (l1 > l0) { levelUp = l1; p.berries += LEVEL_UP_BONUS * (l1 - l0); }
    if (res.won && !p.owned.includes('h_crown') && p.wins === 1) p.owned.push('h_crown');
    p.refs.push(ref); if (p.refs.length > 50) p.refs.shift();
    this.save(p);
    return { ...r, applied: true, levelUp, bonus: levelUp ? LEVEL_UP_BONUS : 0 };
  }
}
