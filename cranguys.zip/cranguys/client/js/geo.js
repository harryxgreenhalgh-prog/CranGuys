// CranGuys — procedural geometry: soft rounded primitives for the candy-plastic look, the skinned
// jelly-bean body, 16 hats, and whole-level meshes generated straight from the shared collider data.
import { MAT } from './gl.js';
import { hex2rgb } from './util.js';
import { quatToMat } from '../../shared/math.js';

const MATID = (m) => (m in MAT ? MAT[m] : 0);

// ---------------- world mesh builder (16 floats / vertex) ----------------
export class MB {
  constructor() { this.v = []; this.i = []; this.n = 0; this.R = [1, 0, 0, 0, 1, 0, 0, 0, 1]; this.P = [0, 0, 0]; this.S = [1, 1, 1]; }
  xf(R, P, S = [1, 1, 1]) { this.R = R; this.P = P; this.S = S; return this; }
  reset() { return this.xf([1, 0, 0, 0, 1, 0, 0, 0, 1], [0, 0, 0]); }
  vert(p, n, c, c2, uv, mat, aux) {
    const R = this.R, S = this.S, x = p[0] * S[0], y = p[1] * S[1], z = p[2] * S[2];
    const nx = n[0] / S[0], ny = n[1] / S[1], nz = n[2] / S[2];
    let wx = R[0] * nx + R[1] * ny + R[2] * nz, wy = R[3] * nx + R[4] * ny + R[5] * nz, wz = R[6] * nx + R[7] * ny + R[8] * nz;
    const l = Math.hypot(wx, wy, wz) || 1;
    this.v.push(R[0] * x + R[1] * y + R[2] * z + this.P[0], R[3] * x + R[4] * y + R[5] * z + this.P[1], R[6] * x + R[7] * y + R[8] * z + this.P[2],
      wx / l, wy / l, wz / l, c[0], c[1], c[2], c2[0], c2[1], c2[2], uv[0], uv[1], mat, aux);
    return this.n++;
  }
  tri(a, b, c) { this.i.push(a, b, c); }
  quad(a, b, c, d) { this.i.push(a, b, c, a, c, d); }
  get empty() { return this.n === 0; }
  build(R) { return R.mesh(new Float32Array(this.v), new Uint32Array(this.i)); }
}

// style: {c, c2, mat, aux, uv: fn(local, normal) -> [u,v]}
const st = (o) => ({ c: o.c || [1, 1, 1], c2: o.c2 || o.c || [1, 1, 1], mat: o.mat || 0, aux: o.aux || 0, uv: o.uv || ((p) => [p[0], p[2]]) });

// Rounded box: smooth bevels make everything look like soft injection-moulded plastic.
export function roundBox(mb, h, r, s) {
  s = st(s);
  r = Math.min(r, h[0] * 0.98, h[1] * 0.98, h[2] * 0.98);
  const arc = r > 0.05 ? [Math.sin(Math.PI / 2), Math.sin(Math.PI / 3), Math.sin(Math.PI / 6)] : [1];
  const axisVals = (hh) => { const a = []; for (const k of arc) a.push(-(hh - r) - r * k); a.push(-(hh - r)); a.push(hh - r); for (let i = arc.length - 1; i >= 0; i--) a.push(hh - r + r * arc[i]); return a; };
  const V = [axisVals(h[0]), axisVals(h[1]), axisVals(h[2])];
  const faces = [[0, 1, 2, 1], [0, 1, 2, -1], [1, 2, 0, 1], [1, 2, 0, -1], [2, 0, 1, 1], [2, 0, 1, -1]]; // [u-axis, v-axis, normal-axis, sign]
  for (const [ua, va, na, sg] of faces) {
    const us = V[ua], vs = V[va], base = mb.n;
    for (let j = 0; j < vs.length; j++) for (let i = 0; i < us.length; i++) {
      const sp = [0, 0, 0]; sp[ua] = us[i]; sp[va] = vs[j]; sp[na] = sg * h[na];
      const inner = [Math.max(-(h[0] - r), Math.min(h[0] - r, sp[0])), Math.max(-(h[1] - r), Math.min(h[1] - r, sp[1])), Math.max(-(h[2] - r), Math.min(h[2] - r, sp[2]))];
      let nx = sp[0] - inner[0], ny = sp[1] - inner[1], nz = sp[2] - inner[2]; const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
      const p = r > 0 ? [inner[0] + nx * r, inner[1] + ny * r, inner[2] + nz * r] : sp;
      mb.vert(p, [nx, ny, nz], s.c, s.c2, s.uv(p, [nx, ny, nz], h), s.mat, s.aux);
    }
    const W = us.length;
    for (let j = 0; j < vs.length - 1; j++) for (let i = 0; i < W - 1; i++) {
      const a = base + j * W + i, b = a + 1, c = a + W + 1, d = a + W;
      // winding: outward normal
      if ((sg > 0) === ((na === 0 && ua === 1) || (na === 1 && ua === 2) || (na === 2 && ua === 0))) mb.quad(a, b, c, d); else mb.quad(a, d, c, b);
    }
  }
}

// Vertical cylinder with rounded rims (bumpers, discs, poles, platforms).
export function cylinder(mb, R, hh, s, seg = 0, bevel = 0.12) {
  s = st(s); seg = seg || Math.max(14, Math.min(56, Math.round(R * 12)));
  bevel = Math.min(bevel, R * 0.45, hh * 0.9);
  const prof = []; // [radius, y, nr, ny]
  prof.push([0, -hh, 0, -1], [R - bevel, -hh, 0, -1]);
  for (let k = 1; k <= 3; k++) { const a = (k / 3) * (Math.PI / 2); prof.push([R - bevel + Math.sin(a) * bevel, -hh + bevel - Math.cos(a) * bevel, Math.sin(a), -Math.cos(a)]); }
  prof.push([R, hh - bevel, 1, 0]);
  for (let k = 1; k <= 3; k++) { const a = (k / 3) * (Math.PI / 2); prof.push([R - bevel + Math.cos(a) * bevel, hh - bevel + Math.sin(a) * bevel, Math.cos(a), Math.sin(a)]); }
  prof.push([R - bevel, hh, 0, 1], [0, hh, 0, 1]);
  lathe(mb, prof, seg, s);
}

// generic lathe around local Y. prof: [r, y, nr, ny]; flat profile segments duplicate verts for crisp normals
export function lathe(mb, prof, seg, s) {
  s = st(s);
  const base = mb.n;
  for (let j = 0; j < prof.length; j++) {
    const [r, y, nr, ny] = prof[j];
    for (let i = 0; i <= seg; i++) {
      const a = (i / seg) * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a);
      const p = [ca * r, y, sa * r], n = [ca * nr, ny, sa * nr];
      mb.vert(p, n, s.c, s.c2, s.uv(p, n), s.mat, s.aux);
    }
  }
  const W = seg + 1;
  for (let j = 0; j < prof.length - 1; j++) for (let i = 0; i < seg; i++) { const a = base + j * W + i; mb.quad(a, a + W, a + W + 1, a + 1); }
}

export function sphere(mb, r, s, seg = 18, ry = r) {
  const prof = [];
  for (let j = 0; j <= seg / 2; j++) { const a = -Math.PI / 2 + (j / (seg / 2)) * Math.PI; prof.push([Math.cos(a) * r, Math.sin(a) * ry, Math.cos(a), Math.sin(a)]); }
  lathe(mb, prof, seg, s);
}

// capsule along local X (sweeper arms)
export function capsuleX(mb, r, hl, s, seg = 14) {
  const prof = [];
  for (let j = 0; j <= 5; j++) { const a = -Math.PI / 2 + (j / 5) * (Math.PI / 2); prof.push([Math.cos(a) * r, -hl + Math.sin(a) * r, Math.cos(a), Math.sin(a)]); }
  for (let j = 0; j <= 5; j++) { const a = (j / 5) * (Math.PI / 2); prof.push([Math.cos(a) * r, hl + Math.sin(a) * r, Math.cos(a), Math.sin(a)]); }
  const save = [mb.R, mb.P, mb.S];
  // rotate local Y->X by composing: x' = y, y' = -x
  const R = mb.R, rot = [R[1], -R[0], R[2], R[4], -R[3], R[5], R[7], -R[6], R[8]];
  mb.R = rot;
  s = { ...s, uv: (p) => [p[1], Math.atan2(p[2], p[0])] };
  lathe(mb, prof, seg, s);
  [mb.R, mb.P, mb.S] = save;
}

export function cone(mb, r, h, s, seg = 20, r2 = 0) {
  const sl = Math.atan2(r - r2, h), nr = Math.cos(sl), ny = Math.sin(sl);
  lathe(mb, [[0, 0, 0, -1], [r, 0, 0, -1], [r, 0, nr, ny], [r2, h, nr, ny], [r2, h, 0, 1], [0, h, 0, 1]], seg, s);
}

export function torus(mb, R, r, s, seg = 32, tseg = 10) {
  s = st(s); const base = mb.n;
  for (let i = 0; i <= seg; i++) {
    const a = (i / seg) * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a);
    for (let j = 0; j <= tseg; j++) {
      const b = (j / tseg) * Math.PI * 2, cb = Math.cos(b), sb = Math.sin(b);
      const p = [(R + r * cb) * ca, r * sb, (R + r * cb) * sa], n = [cb * ca, sb, cb * sa];
      mb.vert(p, n, s.c, s.c2, [i / seg, j / tseg], s.mat, s.aux);
    }
  }
  const W = tseg + 1;
  for (let i = 0; i < seg; i++) for (let j = 0; j < tseg; j++) { const a = base + i * W + j; mb.quad(a, a + 1, a + W + 1, a + W); }
}

// flat-top hexagonal tile with a chamfered top edge
export function hexTile(mb, R, hh, s) {
  s = st(s);
  const ch = 0.12, top = hh, base = -hh;
  const C = (rad, k) => [Math.cos((k * Math.PI) / 3) * rad, Math.sin((k * Math.PI) / 3) * rad];
  const v = (p, n) => mb.vert(p, n, s.c, s.c2, [p[0] / R, p[2] / R], s.mat, s.aux);
  const c0 = v([0, top, 0], [0, 1, 0]);
  const inner = []; for (let k = 0; k < 6; k++) { const [x, z] = C(R - ch, k); inner.push(v([x, top, z], [0, 1, 0])); }
  for (let k = 0; k < 6; k++) mb.tri(c0, inner[(k + 1) % 6], inner[k]);
  for (let k = 0; k < 6; k++) {
    const am = ((k + 0.5) * Math.PI) / 3, nx = Math.cos(am), nz = Math.sin(am), k2 = (k + 1) % 6;
    const [x0, z0] = C(R - ch, k), [x1, z1] = C(R - ch, k2), [X0, Z0] = C(R, k), [X1, Z1] = C(R, k2);
    const n45 = [nx * 0.7071, 0.7071, nz * 0.7071];
    const a = v([x0, top, z0], n45), b = v([x1, top, z1], n45), c = v([X1, top - ch, Z1], n45), d = v([X0, top - ch, Z0], n45);
    mb.quad(a, b, c, d);
    const e = v([X0, top - ch, Z0], [nx, 0, nz]), f = v([X1, top - ch, Z1], [nx, 0, nz]), g = v([X1, base, Z1], [nx, 0, nz]), h = v([X0, base, Z0], [nx, 0, nz]);
    mb.quad(e, f, g, h);
  }
}

// ---------------- the jelly bean (11 floats / vertex: pos3 nrm3 lp3 bone region) ----------------
export function buildBean(R) {
  const v = [], idx = []; let n = 0;
  const add = (p, nn, lp, bone, reg) => { v.push(p[0], p[1], p[2], nn[0], nn[1], nn[2], lp[0], lp[1], lp[2], bone, reg); return n++; };
  const latheB = (prof, seg, bone, reg, off = [0, 0, 0]) => {
    const base = n;
    for (const [r, y, nr, ny] of prof) for (let i = 0; i <= seg; i++) {
      const a = (i / seg) * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a);
      const p = [sa * r + off[0], y + off[1], ca * r + off[2]];
      add(p, [sa * nr, ny, ca * nr], bone === 0 ? p : [p[0] + (bone === 1 ? -0.4 : bone === 2 ? 0.4 : 0), p[1], p[2]], bone, reg);
    }
    const W = seg + 1;
    for (let j = 0; j < prof.length - 1; j++) for (let i = 0; i < seg; i++) { const a = base + j * W + i; idx.push(a, a + 1, a + W + 1, a, a + W + 1, a + W); }
  };
  // body: bean-capsule, a touch wider at the bottom
  const prof = [], RB = 0.42;
  for (let j = 0; j <= 10; j++) { const a = -Math.PI / 2 + (j / 10) * (Math.PI / 2); prof.push([Math.cos(a) * RB * 1.04, -0.24 + Math.sin(a) * RB, Math.cos(a), Math.sin(a)]); }
  for (let j = 1; j <= 6; j++) { const y = -0.24 + (j / 6) * 0.6; prof.push([RB * (1.04 - 0.06 * (j / 6)), y, 1, 0.04]); }
  for (let j = 1; j <= 12; j++) { const a = (j / 12) * (Math.PI / 2); prof.push([Math.cos(a) * RB * 0.98, 0.36 + Math.sin(a) * RB, Math.cos(a), Math.sin(a)]); }
  latheB(prof, 32, 0, 0);
  // little limbs (capsules hanging from their pivots)
  const limb = (r, len) => { const p = []; for (let j = 0; j <= 4; j++) { const a = -Math.PI / 2 + (j / 4) * (Math.PI / 2); p.push([Math.cos(a) * r, -len + Math.sin(a) * r, Math.cos(a), Math.sin(a)]); } for (let j = 0; j <= 4; j++) { const a = (j / 4) * (Math.PI / 2); p.push([Math.cos(a) * r, Math.sin(a) * r, Math.cos(a), Math.sin(a)]); } return p; };
  latheB(limb(0.095, 0.27), 12, 1, 1); latheB(limb(0.095, 0.27), 12, 2, 1);
  latheB(limb(0.125, 0.15), 12, 3, 2); latheB(limb(0.125, 0.15), 12, 4, 2);
  return R.mesh(new Float32Array(v), new Uint32Array(idx), 'bean');
}
export const BEAN_RIG = { shoulder: [0.41, 0.02, 0.03], hip: [0.17, -0.6, 0.02], top: 0.78 };

// ---------------- hats (world meshes in head space: origin = top of head) ----------------
export function buildHats(R) {
  const H = [null];
  const C = (h) => hex2rgb(h);
  const mk = (fn) => { const mb = new MB(); fn(mb); return mb.build(R); };
  const at = (mb, p, q = [0, 0, 0, 1], s) => mb.xf(quatToMat(q), p, s);
  const ax = (a, ang) => { const s = Math.sin(ang / 2); return [a[0] * s, a[1] * s, a[2] * s, Math.cos(ang / 2)]; };
  // 1 party cone
  H.push(mk((mb) => { at(mb, [0, -0.06, 0]); cone(mb, 0.2, 0.5, { c: C('#ff5fa2'), c2: C('#ffd23f'), mat: MAT.flagcloth, uv: (p) => [0, p[1] * 5] }); at(mb, [0, 0.47, 0]); sphere(mb, 0.07, { c: C('#ffd23f') }, 12); }));
  // 2 royal crown
  H.push(mk((mb) => {
    at(mb, [0, -0.04, 0]); cylinder(mb, 0.24, 0.07, { c: C('#ffc83d'), mat: MAT.gold }, 24, 0.03);
    for (let k = 0; k < 5; k++) { const a = (k / 5) * Math.PI * 2; at(mb, [Math.cos(a) * 0.2, 0.03, Math.sin(a) * 0.2]); cone(mb, 0.07, 0.2, { c: C('#ffc83d'), mat: MAT.gold }, 8); at(mb, [Math.cos(a) * 0.2, 0.24, Math.sin(a) * 0.2]); sphere(mb, 0.035, { c: C(['#ff2e88', '#36b9ff', '#40e0a8', '#b07bff', '#ff8a3d'][k]) }, 8); }
  }));
  // 3 bunny ears
  H.push(mk((mb) => { for (const s of [-1, 1]) { at(mb, [s * 0.13, 0.12, -0.02], ax([0, 0, 1], -s * 0.22)); sphere(mb, 0.07, { c: C('#fff4fb') }, 12, 0.24); at(mb, [s * 0.13 - s * 0.01, 0.13, 0.03], ax([0, 0, 1], -s * 0.22)); sphere(mb, 0.035, { c: C('#ff9cc9') }, 10, 0.17); } }));
  // 4 propeller cap
  H.push(mk((mb) => {
    at(mb, [0, -0.1, 0]); sphere(mb, 0.3, { c: C('#36b9ff'), c2: C('#ffd23f'), mat: MAT.flagcloth, uv: (p) => [0, Math.atan2(p[2], p[0]) * 1.27] }, 20, 0.22);
    at(mb, [0, 0.12, 0]); cylinder(mb, 0.02, 0.06, { c: C('#ff4757') }, 8, 0.01);
    at(mb, [0, 0.19, 0]); roundBox(mb, [0.26, 0.012, 0.04], 0.01, { c: C('#ff4757') }); at(mb, [0, 0.19, 0], ax([0, 1, 0], Math.PI / 2)); roundBox(mb, [0.26, 0.012, 0.04], 0.01, { c: C('#ffd23f') });
  }));
  // 5 halo
  H.push(mk((mb) => { at(mb, [0, 0.22, 0]); torus(mb, 0.2, 0.035, { c: C('#fff2a8'), mat: MAT.gold }, 28, 8); }));
  // 6 top hat
  H.push(mk((mb) => { at(mb, [0, 0.0, 0]); cylinder(mb, 0.34, 0.02, { c: C('#2b2350') }, 28, 0.015); at(mb, [0, 0.2, 0]); cylinder(mb, 0.2, 0.2, { c: C('#2b2350') }, 24, 0.03); at(mb, [0, 0.06, 0]); cylinder(mb, 0.205, 0.04, { c: C('#ff2e88') }, 24, 0.01); }));
  // 7 traffic cone
  H.push(mk((mb) => { at(mb, [0, -0.02, 0]); roundBox(mb, [0.26, 0.025, 0.26], 0.02, { c: C('#ff8a3d') }); at(mb, [0, 0, 0]); cone(mb, 0.18, 0.46, { c: C('#ff8a3d'), c2: C('#fff4fb'), mat: MAT.flagcloth, uv: (p) => [0, p[1] * 3.2 + 0.25] }, 18, 0.03); }));
  // 8 viking horns
  H.push(mk((mb) => {
    at(mb, [0, -0.12, 0]); sphere(mb, 0.36, { c: C('#9aa3b5'), mat: MAT.gold }, 20, 0.26);
    for (const s of [-1, 1]) { at(mb, [s * 0.3, 0.02, 0], ax([0, 0, 1], -s * 1.0)); cone(mb, 0.07, 0.3, { c: C('#fff1d6') }, 12); }
  }));
  // 9 chef hat
  H.push(mk((mb) => { at(mb, [0, 0.03, 0]); cylinder(mb, 0.22, 0.08, { c: C('#ffffff') }, 24, 0.03); for (const [x, z] of [[0, 0], [0.12, 0.06], [-0.12, 0.06], [0.05, -0.12], [-0.08, -0.08]]) { at(mb, [x, 0.25, z]); sphere(mb, 0.16, { c: C('#ffffff') }, 14); } }));
  // 10 cranberry sprig (CranGuys signature!)
  H.push(mk((mb) => {
    at(mb, [0, 0.05, 0]); cylinder(mb, 0.015, 0.1, { c: C('#3d8b37') }, 6, 0.005);
    for (const s of [-1, 1]) { at(mb, [s * 0.09, 0.14, 0], ax([0, 0, 1], s * 0.9)); sphere(mb, 0.05, { c: C('#46c45a') }, 10, 0.13); }
    for (const [x, y, z] of [[0, 0.2, 0.03], [0.06, 0.17, -0.04], [-0.06, 0.16, -0.03]]) { at(mb, [x, y, z]); sphere(mb, 0.055, { c: C('#d6195a') }, 12); }
  }));
  // 11 antennae
  H.push(mk((mb) => { for (const s of [-1, 1]) { at(mb, [s * 0.12, 0.1, 0], ax([0, 0, 1], -s * 0.3)); cylinder(mb, 0.015, 0.14, { c: C('#2b2350') }, 6, 0.005); at(mb, [s * 0.2, 0.27, 0]); sphere(mb, 0.06, { c: C('#ffd23f') }, 10); } }));
  // 12 daisy
  H.push(mk((mb) => { for (let k = 0; k < 8; k++) { const a = (k / 8) * Math.PI * 2; at(mb, [Math.cos(a) * 0.12, 0.05, Math.sin(a) * 0.12], ax([0, 1, 0], -a)); sphere(mb, 0.09, { c: C('#ffffff') }, 10, 0.03); } at(mb, [0, 0.07, 0]); sphere(mb, 0.07, { c: C('#ffd23f') }, 12, 0.04); }));
  // 13 bobble beanie
  H.push(mk((mb) => { at(mb, [0, -0.13, 0]); sphere(mb, 0.36, { c: C('#ff4757'), c2: C('#fff4fb'), mat: MAT.flagcloth, uv: (p) => [0, p[1] * 6] }, 22, 0.3); at(mb, [0, 0.19, 0]); sphere(mb, 0.1, { c: C('#fff4fb') }, 12); }));
  // 14 pirate hat
  H.push(mk((mb) => { at(mb, [0, 0.04, 0]); sphere(mb, 0.46, { c: C('#1f1a33') }, 3, 0.16); at(mb, [0, 0.14, 0.23]); sphere(mb, 0.05, { c: C('#ffffff') }, 10); }));
  // 15 headphones
  H.push(mk((mb) => { at(mb, [0, -0.08, 0], ax([1, 0, 0], Math.PI / 2)); torus(mb, 0.43, 0.035, { c: C('#2b2350') }, 28, 8); for (const s of [-1, 1]) { at(mb, [s * 0.43, -0.32, 0], ax([0, 0, 1], Math.PI / 2)); cylinder(mb, 0.12, 0.06, { c: C('#ff2e88') }, 16, 0.03); } }));
  return H;
}

// ---------------- level meshes ----------------
const rgb = (h) => (typeof h === 'string' ? hex2rgb(h) : h || [1, 1, 1]);
function colliderStyle(c) {
  const vis = c.vis || {}, m = vis.m || 'plain', mat = MATID(m);
  const s = { c: rgb(vis.c || '#ffffff'), c2: rgb(vis.c2 || vis.c || '#ffffff'), mat, aux: 0 };
  if (c.shape === 'box') {
    if (m === 'conveyor') { s.aux = vis.spd || 0; s.uv = (p) => [p[0] / c.h[0], p[2]]; }
    else if (m === 'door' || m === 'slab') s.uv = (p) => [p[0] / c.h[0], p[1] / c.h[1]];
  }
  if (c.shape === 'cyl') { s.uv = (p) => [p[0], p[2]]; s.aux = c.r; }
  if (c.shape === 'cap') s.uv = (p) => [p[1], 0];
  return s;
}
function emitShape(mb, c, s) {
  if (c.shape === 'box') roundBox(mb, c.h, Math.min(0.24, Math.min(c.h[0], c.h[1], c.h[2]) * 0.5), s);
  else if (c.shape === 'cyl') cylinder(mb, c.r, c.hh, s, 0, Math.min(0.2, c.hh * 0.6));
  else if (c.shape === 'sph') sphere(mb, c.r, s, 20);
  else if (c.shape === 'cap') capsuleX(mb, c.r, c.hl, s, 14);
}

export function buildLevelMeshes(R, level, world) {
  const out = { chunks: [], kin: [], dyn: null, lasers: [], decor: null, text: [], props: null };
  const groups = new Map();
  const dyn = new MB();
  for (const c of world.cols) {
    const s = colliderStyle(c);
    if (c.kin) { const mb = new MB(); emitShape(mb, c, s); out.kin.push({ c, mesh: mb.build(R) }); continue; }
    if (c.dyn >= 0) {
      s.aux = c.dyn; dyn.xf(c.m0, c.p);
      if (c.tag === 'tile') { s.mat = MAT.tile; s.uv = null; hexTile(dyn, 1.3, c.hh, { ...s, uv: null }); }
      else emitShape(dyn, c, s);
      continue;
    }
    const key = level.type === 'survival' || level.type === 'lobby' ? 0 : Math.floor(c.p[2] / 32);
    let g = groups.get(key); if (!g) groups.set(key, (g = { mb: new MB(), mn: [1e9, 1e9, 1e9], mx: [-1e9, -1e9, -1e9] }));
    g.mb.xf(c.m0, c.p); emitShape(g.mb, c, s);
    for (let i = 0; i < 3; i++) { g.mn[i] = Math.min(g.mn[i], c.aabb[i]); g.mx[i] = Math.max(g.mx[i], c.aabb[i + 3]); }
  }
  // decor (static, merged into a chunk of its own)
  const dec = new MB(); const dmn = [1e9, 1e9, 1e9], dmx = [-1e9, -1e9, -1e9];
  for (const d of level.decor || []) decorShape(dec, d, out, dmn, dmx);
  for (const [, g] of groups) if (!g.mb.empty) out.chunks.push({ mesh: g.mb.build(R), mn: g.mn, mx: g.mx });
  if (!dec.empty) out.chunks.push({ mesh: dec.build(R), mn: dmn, mx: dmx });
  if (!dyn.empty) out.dyn = dyn.build(R);
  // lasers: emissive kinematic triggers
  for (const t of world.trigs) {
    if (t.kind !== 'laser') continue;
    const mb = new MB(), low = t.vis && t.vis.low, hi = t.vis && t.vis.high;
    const col = hi ? [1, 0.35, 0.9] : low ? [1, 0.25, 0.3] : [1, 0.2, 0.45];
    if (t.shape === 'cap') capsuleX(mb, t.r * 0.9, t.hl, { c: col, mat: MAT.laser }, 10);
    else roundBox(mb, [t.h[0], t.h[1], t.h[2] * 0.6], 0.05, { c: col, mat: MAT.laser });
    out.lasers.push({ c: t, mesh: mb.build(R), col });
  }
  out.props = buildBackdrop(R, level);
  return out;
}

function decorShape(mb, d, out, mn, mx) {
  const v = d.vis || {}, c = rgb(v.c), c2 = rgb(v.c2 || v.c);
  const I = [1, 0, 0, 0, 1, 0, 0, 0, 1], p = d.p;
  const grow = (x0, y0, z0, x1, y1, z1) => { mn[0] = Math.min(mn[0], x0); mn[1] = Math.min(mn[1], y0); mn[2] = Math.min(mn[2], z0); mx[0] = Math.max(mx[0], x1); mx[1] = Math.max(mx[1], y1); mx[2] = Math.max(mx[2], z1); };
  if (d.shape === 'sph') { mb.xf(I, p); sphere(mb, d.r, { c, mat: MAT.plain }, 18); grow(p[0] - d.r, p[1] - d.r, p[2] - d.r, p[0] + d.r, p[1] + d.r, p[2] + d.r); }
  else if (d.shape === 'gate' || d.shape === 'arch') {
    const w = d.w / 2, h = d.h;
    for (const s of [-1, 1]) { mb.xf(I, [p[0] + s * (w + 0.6), p[1] + h / 2, p[2]]); roundBox(mb, [0.6, h / 2, 0.6], 0.25, { c, c2, mat: MAT.stripes }); }
    mb.xf(I, [p[0], p[1] + h + 0.7, p[2]]); roundBox(mb, [w + 1.2, 0.8, 0.6], 0.3, { c: d.shape === 'arch' ? [1, 1, 1] : c2, c2: [0.12, 0.08, 0.2], mat: d.shape === 'arch' ? MAT.checker : MAT.plain });
    for (const s of [-1, 1]) { mb.xf(I, [p[0] + s * (w + 0.6), p[1] + h + 1.9, p[2]]); sphere(mb, 0.55, { c: c2 }, 14); }
    if (v.text) out.text.push({ text: v.text, p: [p[0], p[1] + h + 0.72, p[2] - 0.62], w: Math.min(d.w * 0.6, v.text.length * 1.4), h: 1.2 }, { text: v.text, p: [p[0], p[1] + h + 0.72, p[2] + 0.62], w: Math.min(d.w * 0.6, v.text.length * 1.4), h: 1.2, back: true });
    grow(p[0] - w - 1.5, p[1], p[2] - 1, p[0] + w + 1.5, p[1] + h + 2.5, p[2] + 1);
  } else if (d.shape === 'flag') {
    mb.xf(I, [p[0], p[1] + 2.2, p[2]]); cylinder(mb, 0.07, 2.2, { c: [1, 1, 1] }, 8, 0.03);
    mb.xf(I, [p[0] + (p[0] < 0 ? 0.6 : -0.6), p[1] + 3.8, p[2]]); roundBox(mb, [0.6, 0.4, 0.04], 0.03, { c, c2: [1, 1, 1], mat: MAT.flagcloth, uv: (q) => [q[0], q[1] * 1.2] });
    mb.xf(I, [p[0], p[1] + 4.5, p[2]]); sphere(mb, 0.13, { c: [1, 0.85, 0.2] }, 10);
    grow(p[0] - 1.3, p[1], p[2] - 0.2, p[0] + 1.3, p[1] + 4.7, p[2] + 0.2);
  } else if (d.shape === 'ring') {
    mb.xf(I, p); torus(mb, d.r, 0.35, { c, mat: MAT.plain }, Math.max(32, Math.round(d.r * 4)), 10);
    grow(p[0] - d.r - 0.4, p[1] - 0.4, p[2] - d.r - 0.4, p[0] + d.r + 0.4, p[1] + 0.4, p[2] + d.r + 0.4);
  } else if (d.shape === 'pillar') {
    mb.xf(I, [p[0], p[1] + d.h / 2, p[2]]); cylinder(mb, d.r, d.h / 2, { c, c2, mat: MAT.stripes }, 28, 0.3);
    grow(p[0] - d.r, p[1], p[2] - d.r, p[0] + d.r, p[1] + d.h, p[2] + d.r);
  } else if (d.shape === 'cannon') {
    mb.xf(I, [p[0], p[1] + 0.5, p[2]]); roundBox(mb, [0.8, 0.5, 0.8], 0.25, { c: c2 });
    const q = [Math.sin(-0.6), 0, 0, Math.cos(-0.6)];
    mb.xf(quatToMat(q), [p[0], p[1] + 1.25, p[2] - 0.2]); cylinder(mb, 0.55, 0.9, { c, c2, mat: MAT.stripes }, 18, 0.15);
    grow(p[0] - 1, p[1], p[2] - 1.5, p[0] + 1, p[1] + 2.4, p[2] + 1);
  }
}

// floating candy props around the course (purely visual, deterministic per level)
function buildBackdrop(R, level) {
  const mb = new MB();
  let seed = 1234567 + level.id.length * 999;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  const cols = ['#ff5fa2', '#8b4dff', '#ffd23f', '#36b9ff', '#40e0a8', '#ff8a3d', '#b07bff', '#9be15d'].map(hex2rgb);
  let zMin = -20, zMax = 40, xR = 30;
  for (const c of level.colliders) { zMin = Math.min(zMin, c.p[2]); zMax = Math.max(zMax, c.p[2]); xR = Math.max(xR, Math.abs(c.p[0]) + 10); }
  const cx = 0, cz = (zMin + zMax) / 2, span = (zMax - zMin) / 2 + 60;
  for (let k = 0; k < 46; k++) {
    const a = rnd() * Math.PI * 2, r = Math.max(xR + 25, 55) + rnd() * 90;
    const x = cx + Math.cos(a) * r * 1.1, z = cz + Math.sin(a) * Math.max(r, span * (0.55 + rnd() * 0.6));
    const y = -6 + rnd() * 50, col = cols[k % cols.length], col2 = cols[(k + 3) % cols.length];
    const I = [1, 0, 0, 0, 1, 0, 0, 0, 1];
    const kind = k % 6;
    if (kind === 0) { mb.xf(I, [x, y, z]); sphere(mb, 3 + rnd() * 6, { c: col, c2: col2, mat: MAT.stripes }, 20); }
    else if (kind === 1) { mb.xf(quatToMat([Math.sin(rnd()), 0, 0, Math.cos(rnd())]), [x, y, z]); torus(mb, 5 + rnd() * 6, 1 + rnd(), { c: col }, 36, 10); }
    else if (kind === 2) { mb.xf(I, [x, y - 20, z]); cylinder(mb, 2 + rnd() * 2, 20 + rnd() * 10, { c: col, c2: col2, mat: MAT.stripes }, 24, 1); mb.xf(I, [x, y + 10, z]); sphere(mb, 4, { c: col2 }, 16); }
    else if (kind === 3) { mb.xf(quatToMat([0, Math.sin(rnd() * 3), 0, Math.cos(rnd() * 3)]), [x, y, z]); roundBox(mb, [3 + rnd() * 4, 3 + rnd() * 4, 3 + rnd() * 4], 1.2, { c: col, c2: col2, mat: MAT.checker }); }
    else if (kind === 4) { for (let j = 0; j < 4; j++) { mb.xf(I, [x + (rnd() - 0.5) * 10, y + (rnd() - 0.5) * 6, z + (rnd() - 0.5) * 10]); sphere(mb, 2.5 + rnd() * 3, { c: [1, 1, 1], mat: MAT.cloud }, 14); } }
    else { mb.xf(I, [x, y, z]); cone(mb, 3 + rnd() * 2, 8 + rnd() * 8, { c: col, c2: col2, mat: MAT.flagcloth, uv: (p) => [0, p[1] * 0.4] }, 20); }
  }
  return mb.build(R);
}

// crown objective mesh
export function buildCrown(R) {
  const mb = new MB(); const gold = { c: hex2rgb('#ffc83d'), mat: MAT.gold };
  mb.xf([1, 0, 0, 0, 1, 0, 0, 0, 1], [0, -0.15, 0]); cylinder(mb, 0.55, 0.14, gold, 32, 0.06);
  for (let k = 0; k < 6; k++) {
    const a = (k / 6) * Math.PI * 2;
    mb.xf([1, 0, 0, 0, 1, 0, 0, 0, 1], [Math.cos(a) * 0.48, -0.02, Math.sin(a) * 0.48]); cone(mb, 0.16, 0.5, gold, 10);
    mb.xf([1, 0, 0, 0, 1, 0, 0, 0, 1], [Math.cos(a) * 0.48, 0.52, Math.sin(a) * 0.48]); sphere(mb, 0.08, { c: hex2rgb(['#ff2e88', '#36b9ff', '#40e0a8'][k % 3]) }, 10);
  }
  return mb.build(R);
}
export function buildBoulder(R) { const mb = new MB(); sphere(mb, 1.3, { c: hex2rgb('#7b55c9'), c2: hex2rgb('#a98cf0'), mat: MAT.boulder, uv: (p) => [p[0] + p[2], p[1]] }, 22); return mb.build(R); }
export function buildDoorPanel(R) { const mb = new MB(); roundBox(mb, [1.88, 1.5, 0.24], 0.12, { c: [1, 1, 1], c2: [1, 1, 1], mat: MAT.door, uv: (p) => [p[0] / 1.88, p[1] / 1.5] }); return mb.build(R); }
export function buildPedestal(R) {
  const mb = new MB();
  cylinder(mb, 2.2, 0.35, { c: hex2rgb('#ffd23f'), c2: hex2rgb('#ffffff'), mat: MAT.bumper, aux: 2.2 }, 48, 0.15);
  mb.xf([1, 0, 0, 0, 1, 0, 0, 0, 1], [0, -0.9, 0]); cylinder(mb, 1.8, 0.6, { c: hex2rgb('#ff5fa2'), c2: hex2rgb('#ffffff'), mat: MAT.stripes }, 48, 0.2);
  return mb.build(R);
}
export function buildPodium(R) {
  const mb = new MB(), I = [1, 0, 0, 0, 1, 0, 0, 0, 1];
  const blocks = [[0, 1.6, '#ffc83d'], [-2.6, 1.0, '#c9d2e3'], [2.6, 0.65, '#ff9a5a']];
  for (const [x, h, col] of blocks) { mb.xf(I, [x, h / 2, 0]); roundBox(mb, [1.25, h / 2, 1.25], 0.2, { c: hex2rgb(col), c2: [1, 1, 1], mat: MAT.slab, uv: (p) => [p[0] / 1.25, p[1] / (h / 2)] }); }
  mb.xf(I, [0, -0.25, 0]); cylinder(mb, 7, 0.25, { c: hex2rgb('#b07bff'), c2: hex2rgb('#d7b8ff'), mat: MAT.rings }, 64, 0.15);
  return mb.build(R);
}
