// CranGuys — client entry point: boots renderer/audio/input, picks online (CranGuys server) or offline (bots),
// runs the frame loop and drives the show flow between menu, lobby, rounds, podium and rewards.
import { Scene } from './scene.js';
import { Sound } from './audio.js';
import { Input } from './input.js';
import { Cam } from './camera.js';
import { UI } from './ui.js';
import { ClientGame } from './play.js';
import { RemoteConn, LocalServer } from './net.js';
import { RemoteBackend, LocalBackend } from './api.js';
import { BeanVis } from './bean.js';
import { BotBrain } from '../../shared/bots.js';
import { watchIcons } from './icons.js';
import { $, settings, beanLook, isTouch } from './util.js';
import { PHASE, TICK_HZ, DT, MODE, TIMING, INTERP_TICKS } from '../../shared/config.js';
import { crownAt } from '../../shared/levels/crownpeak.js';
import { qt, clamp } from '../../shared/math.js';
import { itemById } from '../../shared/cosmetics.js';

const MENU_STATES = new Set(['menu', 'locker', 'shop']);

class App {
  constructor() {
    this.state = 'boot'; this.game = null; this.conn = null; this.mode = 'offline'; this.onlineOK = false;
    this.menuYaw = 0.35; this.ballRot = new Map(); this.remoteFx = new Map(); this.spectate = -1;
    this.frames = 0; this.fpsT = 0; this.fpsVal = 60; this.lowFps = 0; this.lastHud = 0;
  }

  async boot() {
    watchIcons();
    if (isTouch()) document.body.classList.add('touch');
    this.sound = new Sound();
    this.scene = new Scene($('#gl'), this.sound);
    this.ui = new UI(this);
    if (!this.scene.ok) { $('#nogl').classList.add('show'); $('#boot').classList.remove('show'); return; }
    this.fx = this.scene.fx;
    this.input = new Input($('#gl'));
    this.input.buildTouch($('#touch'));
    this.cam = new Cam();
    this.applySettings();
    // iPad Safari: block pinch/double-tap zoom gestures, and recover if iOS drops the GL context in the background
    document.addEventListener('gesturestart', (e) => e.preventDefault());
    document.addEventListener('dblclick', (e) => e.preventDefault());
    $('#gl').addEventListener('webglcontextlost', (e) => { e.preventDefault(); this.ui.toast('Graphics paused…'); });
    $('#gl').addEventListener('webglcontextrestored', () => location.reload());
    const unlock = () => this.sound.unlock();
    addEventListener('pointerdown', unlock); addEventListener('keydown', unlock); addEventListener('touchend', unlock);
    this.ui.boot(0.3, 'Inflating jelly beans…');
    // drag to spin the bean on the menu / locker
    let drag = null;
    $('#gl').addEventListener('pointerdown', (e) => { if (MENU_STATES.has(this.state)) drag = e.clientX; });
    addEventListener('pointermove', (e) => { if (drag !== null) { this.menuYaw += (e.clientX - drag) * 0.012; drag = e.clientX; } });
    addEventListener('pointerup', () => (drag = null));

    // backends: offline always available; online if a CranGuys server answers
    this.local = new LocalBackend(); await this.local.init();
    const base = settings.server || (location.protocol.startsWith('http') ? location.origin : '');
    if (base && settings.mode !== 'offline') {
      this.ui.boot(0.55, 'Looking for the CranGuys server…');
      try {
        this.remote = new RemoteBackend(base);
        const st = await Promise.race([this.remote.status(), new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 3000))]);
        if (st && st.name === 'CranGuys') { await this.remote.init(this.local.profile.name); this.onlineOK = true; }
      } catch (e) { console.info('[cranguys] online unavailable:', e.message); }
    }
    this.mode = this.onlineOK && settings.mode !== 'offline' ? 'online' : 'offline';
    this.backend = this.mode === 'online' ? this.remote : this.local;
    this.ui.boot(0.9, 'Polishing the crown…');
    this.ui.setProfile(this.backend.profile);
    this.ui.setMode(this.mode, this.onlineOK);
    this.menuBean = new BeanVis(beanLook(this.backend.profile.loadout));
    this.connect();
    this.ui.boot(1);
    setTimeout(() => { this.goto('menu'); }, 250);
    this.last = performance.now();
    requestAnimationFrame((t) => this.loop(t));
  }

  applySettings() {
    const q = settings.quality === 'auto' ? (isTouch() ? 1 : 2) : { low: 0, medium: 1, high: 2 }[settings.quality] ?? 1;
    this.scene.setQuality(this.autoDrop ? Math.max(0, q - this.autoDrop) : q);
    this.sound.setVol({ master: settings.master, music: settings.music, sfx: settings.sfx });
    document.documentElement.style.setProperty('--tsize', settings.touchSize);
    for (const b of document.querySelectorAll('.tbtn')) b.style.scale = settings.touchSize;
  }

  // ---------------- connection ----------------
  connect() {
    if (this.conn) { this.conn.close(); this.conn = null; }
    if (this.mode === 'online') {
      this.conn = new RemoteConn(this.remote.wsUrl(), this.remote.token, (m) => this.onMsg(m), (st, code) => this.onConnState(st, code));
    } else { this.ui.setStatus('Offline · 59 bots ready'); }
  }
  onConnState(st, code) {
    if (st === 'open') this.ui.setStatus('Connected');
    else if (st === 'reconnecting') { this.ui.setStatus('Reconnecting…', false); if (this.state === 'show') this.ui.toast('Connection lost — reconnecting…', 'bad'); }
    else if (st === 'closed' && code === 4002) this.ui.setStatus('Signed in elsewhere', false);
  }
  setMode(mode) {
    if (mode === this.mode) return;
    if (mode === 'online' && !this.onlineOK) return this.ui.toast('No CranGuys server found — set one in Settings.', 'bad');
    if (this.state !== 'menu' && !MENU_STATES.has(this.state)) return;
    this.cancel();
    this.mode = mode; settings.mode = mode === 'offline' ? 'offline' : 'auto';
    this.backend = mode === 'online' ? this.remote : this.local;
    this.ui.setMode(mode, this.onlineOK); this.ui.setProfile(this.backend.profile); this.menuBean.setLook(beanLook(this.backend.profile.loadout));
    this.connect();
  }

  onMsg(m) {
    if (m instanceof Uint8Array) { if (this.game) this.game.onMessage(m); return; }
    switch (m.t) {
      case 'welcome': if (m.profile && this.mode === 'online') { this.remote.setProfile(m.profile); this.ui.setProfile(m.profile); } this.mmStatus(m); return;
      case 'mm': return this.mmStatus(m);
      case 'err':
        if (m.code === 'auth' && this.mode === 'online') { this.remote.token = null; this.remote.init().then(() => this.connect()); return; }
        if (m.code === 'version') { this.ui.toast(m.msg, 'bad'); setTimeout(() => location.reload(), 2500); return; }
        this.ui.toast(m.msg || 'Server error', 'bad'); return;
      case 'left': if (this.state === 'show') this.endShow(); return;
      case 'reward':
        this.pendingReward = m;
        if (m.profile) { this.backend.profile = m.profile; if (this.backend.setProfile) this.backend.setProfile(m.profile); this.ui.setProfile(m.profile); this.menuBean.setLook(beanLook(m.profile.loadout)); }
        return;
      case 'match':
        if (!this.game) this.game = new ClientGame(this);
        this.game.onMessage(m); return;
      default: if (this.game) this.game.onMessage(m);
    }
  }
  mmStatus(m) {
    if (this.mode !== 'online') return;
    if (m.st === 'queued') this.ui.setSearching(true, `Finding a show… ${Math.floor(m.waited || 0)}s`);
    else if (m.st === 'found') this.ui.setSearching(true, 'Show found! Joining…');
    else if (this.state !== 'searching') this.ui.setStatus(`${m.online} online · ${m.shows} show${m.shows === 1 ? '' : 's'} live`);
  }

  // ---------------- menu actions ----------------
  goto(s) {
    if (s === 'menu' && this.state === 'searching') { this.ui.show('menu'); return; }
    this.state = s; this.ui.show(s); this.input.enabled = false; this.input.release(); this.ui.touch(false);
    this.sound.music('menu');
    $('#nametags').innerHTML = ''; this.ui.tags = [];
  }
  play() {
    this.sound.unlock();
    if (this.state === 'searching' || this.state === 'show') return;
    this.pendingReward = null;
    this.ui.hideOverlay('rewards');
    if (this.mode === 'offline') {
      if (this.conn) this.conn.close();
      this.conn = new LocalServer(this.local, (m) => this.onMsg(m), () => {});
      this.ui.setSearching(true, 'Filling the lobby with bots…');
    } else {
      if (!this.conn || !this.conn.open) { this.ui.toast('Not connected yet…', 'bad'); return; }
      this.ui.setSearching(true, 'Finding a show…');
    }
    this.state = 'searching';
    this.conn.send({ t: 'queue' });
    this.sound.play('whoosh');
  }
  cancel() {
    if (this.state !== 'searching') return;
    if (this.conn) this.conn.send({ t: 'unqueue' });
    this.state = 'menu'; this.ui.setSearching(false); this.ui.setStatus(this.mode === 'online' ? 'Connected' : 'Offline · 59 bots ready');
  }
  equip(slot, id) {
    const p = this.backend.profile; const prev = p.loadout[slot];
    p.loadout = { ...p.loadout, [slot]: id };
    this.menuBean.setLook(beanLook(p.loadout)); this.ui.setProfile(p);
    this.fx.sparkle([0, 1, 0], 8, [1, 1, 1, 1]);
    clearTimeout(this.eqT);
    this.eqT = setTimeout(async () => {
      try { const np = await this.backend.equip(p.loadout); this.ui.setProfile(np); }
      catch (e) { p.loadout = { ...p.loadout, [slot]: prev }; this.menuBean.setLook(beanLook(p.loadout)); this.ui.setProfile(p); this.ui.toast(e.message, 'bad'); }
    }, 350);
  }
  async buy(id) {
    const it = itemById(id);
    const price = it.price.c ? `${it.price.c} Crowns` : `${it.price.b} Cranberries`;
    this.ui.confirm(`Buy ${it.name}?`, `This costs ${price}.`, 'Buy it!', async () => {
      try {
        const p = await this.backend.buy(id); this.ui.setProfile(p);
        this.sound.play('buy'); this.fx.confetti([0, 1, 0], 50, 7); this.ui.toast(`🎉 ${it.name} is yours! Equip it in the Locker.`, 'good');
        this.ui.renderShop();
      } catch (e) { this.sound.play('error'); this.ui.toast(e.message, 'bad'); }
    });
  }
  async rename(n) { const p = await this.backend.rename(n); this.ui.setProfile(p); }
  async account(kind, u, pw) {
    const p = kind === 'register' ? await this.remote.register(u, pw) : kind === 'login' ? await this.remote.login(u, pw) : await this.remote.logout();
    this.ui.setProfile(p); this.menuBean.setLook(beanLook(p.loadout)); this.connect();
  }

  // ---------------- show flow (called by ClientGame) ----------------
  onMatch(m) {
    const g = this.game;
    this.state = 'show'; this.ui.setSearching(false);
    this.ballRot.clear(); this.remoteFx.clear(); this.spectate = -1;
    if (g.phase === PHASE.LOBBY) { this.ui.show('lobby'); this.ui.lobbyInit(g); this.sound.music('lobby'); this.setControls(true); }
    else { this.ui.show('hud'); this.ui.hudRound(g); this.sound.music(g.level.type === 'final' ? 'final' : 'round'); this.setControls(g.phase === PHASE.PLAY); }
    this.cam.reset(Math.PI, null);
  }
  onRound(m) {
    const g = this.game;
    this.ui.show('hud'); this.ui.hudRound(g); this.ui.hideOverlay('results'); this.ui.clearBanner();
    this.ui.intro(m, g.level);
    this.setControls(false);
    this.sound.music(g.level.type === 'final' ? 'final' : 'round'); this.sound.play('whoosh');
    this.ballRot.clear(); this.remoteFx.clear(); this.spectate = -1; this.myResult = null;
    $('#nametags').innerHTML = ''; this.ui.tags = [];
  }
  onSpawn(me) { if (this.game && this.game.phase !== PHASE.PLAY) this.cam.reset(me.yaw, me.p); }
  onPhase(p, m) {
    const g = this.game;
    if (p === PHASE.COUNTDOWN) {
      this.ui.hideOverlay('intro');
      if (g.meActive) this.cam.reset(g.me.yaw, g.me.p);
      const left = m.left;
      clearTimeout(this.cdT1); clearTimeout(this.cdT2); clearTimeout(this.cdT3);
      [[3, left - 3], [2, left - 2], [1, left - 1]].forEach(([n, at], i) => { this['cdT' + (i + 1)] = setTimeout(() => { this.ui.countdown(n); this.sound.play('count'); }, Math.max(0, at) * 1000); });
    } else if (p === PHASE.PLAY) {
      this.ui.countdown('GO!'); this.sound.play('go'); this.setControls(true);
      const L = g.level;
      this.ui.objective(L.type === 'race' ? 'Reach the finish line!' : L.type === 'survival' ? 'Don’t fall!' : 'Grab the crown at the summit!');
      setTimeout(() => this.ui.objective(''), 3500);
    } else if (p === PHASE.ROUND_END) {
      this.setControls(false); this.sound.play('whistle');
      if (!this.myResult) this.ui.banner(g.level.type === 'survival' ? 'TIME’S UP!' : 'ROUND OVER!', 'info');
    } else if (p === PHASE.LOBBY) { this.ui.show('lobby'); }
  }
  onQualify(slot, place) {
    const g = this.game, r = g.roster.get(slot); if (!r) return;
    const surv = g.level.type === 'survival';
    if (slot === g.you) {
      this.myResult = 'q';
      this.ui.banner(surv ? 'SURVIVED!' : 'QUALIFIED!', 'good', surv ? '' : `#${place}`);
      this.sound.play('qualify'); this.fx.confetti(g.me.p, 70, 10); this.setControls(false);
    } else if (!surv && (place <= 3 || g.roster.get(slot).userId)) this.ui.feed(`${r.name} qualified #${place}`, 'good');
  }
  onEliminate(slot) {
    const g = this.game, r = g.roster.get(slot); if (!r) return;
    if (slot === g.you) { this.myResult = 'x'; this.ui.banner('ELIMINATED!', 'bad', 'You can keep spectating'); this.sound.play('eliminated'); this.setControls(false); }
    else if (g.level.type === 'survival' && g.phase === PHASE.PLAY) this.ui.feed(`${r.name} fell!`, 'bad');
  }
  onCrown(slot) {
    const g = this.game, r = g.roster.get(slot);
    this.sound.play('crown');
    if (slot === g.you) { this.myResult = 'q'; this.ui.banner('CROWNED!', 'gold', 'YOU WIN THE SHOW!', true); this.fx.confetti(g.me.p, 120, 12); }
    else if (r) this.ui.banner(r.name.toUpperCase(), 'gold', 'GRABBED THE CROWN!');
  }
  onRoundEnd() {}
  onResults(m) { this.ui.clearBanner(); this.ui.results(m, this.game); }
  onPodium(m) {
    this.state = 'podium'; this.podiumTop = m.top || []; this.ui.hideOverlay('results'); this.ui.clearBanner();
    this.ui.show('podium'); this.ui.podium(m, this.game); this.setControls(false); this.ui.nametags([]);
    this.sound.music('podium'); this.sound.play('confetti'); this.podiumT = 0;
  }
  onShowEnd() { this.endShow(); }
  endShow() {
    this.game = null; this.setControls(false); this.ui.hideOverlay('results'); this.ui.hideOverlay('intro'); this.ui.clearBanner();
    if (this.mode === 'offline' && this.conn) { this.conn.close(); this.conn = null; }
    this.goto('menu'); this.ui.setSearching(false); this.ui.setStatus(this.mode === 'online' ? 'Connected' : 'Offline · 59 bots ready');
    if (this.pendingReward) { this.ui.rewards(this.pendingReward, this.backend.profile); this.pendingReward = null; this.sound.play('qualify', 0.6); }
  }
  leaveShow() { if (this.conn) this.conn.send({ t: 'leave' }); this.endShow(); }
  setControls(on) { this.input.enabled = on; this.ui.touch(on); if (!on) this.input.release(); }
  cycleSpectate(d) {
    const ids = this.lastRemotes ? this.lastRemotes.map((s) => s.slot) : []; if (!ids.length) return;
    const i = ids.indexOf(this.spectate); this.spectate = ids[(i + d + ids.length) % ids.length];
  }

  onLocalEvents(ev, me) {
    const S = this.sound, F = this.fx, C = this.cam;
    for (let i = 0; i < ev.length; i += 2) {
      const n = ev[i], v = ev[i + 1], p = me.p;
      switch (n) {
        case 'jump': S.play('jump'); F.dust([p[0], p[1] - 0.75, p[2]], 4, [1, 1, 1, 0.5], 1.2); break;
        case 'hop': S.play('hop'); break;
        case 'land': if (v > 6) { S.play('land', clamp(v / 16, 0.2, 1)); F.dust([p[0], p[1] - 0.75, p[2]], v > 14 ? 12 : 6); if (v > 18) C.shake(0.12, 0.2); } break;
        case 'dive': S.play('dive'); break;
        case 'belly': S.play('belly'); F.dust([p[0], p[1] - 0.45, p[2]], 8); break;
        case 'bounce': S.play('bounce'); F.ring([p[0], p[1] - 0.6, p[2]], [0.7, 1, 0.4, 0.9]); C.shake(0.08, 0.2); break;
        case 'bump': S.play('bump'); F.stars([p[0], p[1] - 0.4, p[2]]); break;
        case 'rag': S.play('rag'); F.stars(p); C.shake(0.35, 0.35); break;
        case 'zap': S.play('zap'); F.sparkle(p, 10, [1, 0.3, 0.6, 1]); C.shake(0.3, 0.3); break;
        case 'getup': S.play('getup'); break;
        case 'ledge': S.play('ledge'); break;
        case 'climb': S.play('climb'); break;
        case 'cp': S.play('cp'); this.ui.feed('✔ Checkpoint!', 'good'); break;
        case 'fall': S.play('fall'); F.splash([p[0], this.game ? this.game.level.slimeY + 0.5 : p[1], p[2]]); break;
        case 'respawn': S.play('respawn'); F.sparkle(p, 12); break;
      }
    }
  }

  // ---------------- frame loop ----------------
  loop(ts) {
    requestAnimationFrame((t) => this.loop(t));
    const raw = Math.max(0, (ts - this.last) / 1000), dt = clamp(raw, 0, 0.1); this.last = ts;
    if (this.conn && this.conn.update) this.conn.update(dt);
    let inp = this.input.poll(this.cam.yaw, dt); inp.lastCam = this.input.lastCamInput;
    // debug/test hook: let the bot AI drive your bean in offline shows (CG.autopilot = true)
    if (this.autopilot && this.conn instanceof LocalServer && this.conn.match && this.input.enabled) {
      const m = this.conn.match, pl = m.players[this.conn.slot];
      if (pl && pl.st) { this._ap = this._ap || new BotBrain(4242, 0.97); const a = this._ap.input(m, pl); inp = { ...inp, mx: a.mx, mz: a.mz, b: a.b }; }
    }
    try {
      if ((this.state === 'show') && this.game && this.game.level) this.renderShow(dt, inp);
      else if (this.state === 'podium' && this.game) this.renderPodium(dt);
      else if (this.state !== 'boot') this.renderMenu(dt);
    } catch (e) { console.error(e); }
    // fps + adaptive quality
    this.frames++; this.fpsT += raw;
    if (this.fpsT > 1) {
      this.fpsVal = this.frames / this.fpsT; this.frames = 0; this.fpsT = 0;
      this.ui.fps(`${Math.round(this.fpsVal)} fps · ${this.scene.R.stats.draws} draws` + (this.game && this.game.predTick ? ` · lead ${this.game.lead.toFixed(1)} · buf ${this.game.inbuf}` : ''));
      if (settings.quality === 'auto' && this.state === 'show') {
        this.lowFps = this.fpsVal < 40 ? this.lowFps + 1 : 0;
        if (this.lowFps >= 4 && (this.autoDrop || 0) < 2) { this.autoDrop = (this.autoDrop || 0) + 1; this.lowFps = 0; this.applySettings(); }
      }
    }
  }

  renderMenu(dt) {
    const t = performance.now() / 1000;
    const st = { p: [0, 0.78, 0], v: [0, 0, 0], yaw: this.menuYaw + Math.sin(t * 0.4) * 0.15, mode: MODE.NORMAL, gr: 1, mt: 0 };
    this.menuBean.update(dt, st, t, { menu: true, wave: this.state === 'menu' });
    const narrow = innerWidth < 640, side = this.state !== 'menu';
    const lookX = side && !narrow ? 1.25 * Math.min(1.6, innerWidth / innerHeight) : 0, lookY = side && narrow ? -0.9 : 0.85;
    this.cam.fixed([lookX, 1.25 + (side && narrow ? -1 : 0), 4.4 + (narrow ? 1.6 : 0)], [lookX, lookY, 0], 0.72);
    this.scene.renderStage(this.cam, dt, [{ vis: this.menuBean, look: this.menuBean.look, p: st.p, st }]);
  }

  renderPodium(dt) {
    const g = this.game, t = performance.now() / 1000;
    this.podiumT += dt;
    const spots = [[0, 1.6 + 0.78, 0], [-2.6, 1.0 + 0.78, 0], [2.6, 0.65 + 0.78, 0]];
    const beans = [];
    (this.podiumTop || []).slice(0, 3).forEach((slot, i) => {
      const r = g.roster.get(slot); if (!r) return;
      const hop = i === 0 ? Math.max(0, Math.sin(t * 5)) * 0.45 : Math.max(0, Math.sin(t * 4 + i)) * 0.2;
      const p = [spots[i][0], spots[i][1] + hop, spots[i][2]];
      const st = { p, v: [0, hop > 0.01 ? 1 : 0, 0], yaw: 0, mode: MODE.NORMAL, gr: hop < 0.02, mt: 0 };
      r.vis.update(dt, st, t, { celebrate: i === 0, wave: i > 0 });
      beans.push({ vis: r.vis, look: r.look, p, st });
    });
    if (Math.random() < dt * 1.6) this.fx.confetti([(Math.random() - 0.5) * 6, 6, (Math.random() - 0.5) * 3], 30, 4);
    this.cam.fixed([Math.sin(t * 0.25) * 2.2, 3.2, 8.6], [0, 1.9, 0], 0.78);
    this.scene.renderStage(this.cam, dt, beans, { podium: true, crownAt: beans.length ? [0, spots[0][1] + 1.75 + Math.sin(t * 3) * 0.1, 0] : null });
  }

  renderShow(dt, inp) {
    const g = this.game, t = performance.now() / 1000;
    g.update(dt, inp);
    const worldTick = g.meActive && g.predTick !== null ? g.predTick - 1 + g.alpha : g.serverTick() - INTERP_TICKS;
    const worldTime = Math.max(0, worldTick * DT);
    const beans = [];
    let own = null;
    if (g.meActive && g.me.mode !== MODE.OUT) {
      own = g.ownRenderState(); const r = g.roster.get(g.you);
      if (g.me.mode === MODE.RESPAWN) { own.p = this.lastOwnP || own.p; own.v = [0, 0, 0]; }   // hold the camera where we fell
      else { this.lastOwnP = own.p; if (r) { r.vis.update(dt, own, t, { celebrate: this.myResult === 'q' }); beans.push({ p: own.p, st: own, vis: r.vis, look: r.look, slot: g.you }); } }
    }
    const { out, balls } = g.remotes();
    this.lastRemotes = out;
    const eye = this.cam.eye;
    for (const s of out) {
      if (s.mode === MODE.RESPAWN) continue;
      const r = g.roster.get(s.slot); if (!r) continue;
      r.vis.update(dt, s, t);
      beans.push({ p: s.p, st: s, vis: r.vis, look: r.look, slot: s.slot });
      // infer effects for other beans from state changes
      const pr = this.remoteFx.get(s.slot);
      if (pr) {
        const d = Math.hypot(s.p[0] - eye[0], s.p[1] - eye[1], s.p[2] - eye[2]);
        if (d < 32) {
          if (pr.mode !== MODE.RAG && s.mode === MODE.RAG) { this.fx.stars(s.p); this.fx.near(s.p, 'rag', 0.5); }
          if (!pr.gr && s.gr && pr.vy < -9) this.fx.dust([s.p[0], s.p[1] - 0.7, s.p[2]], 5);
          if (s.v[1] > 12 && pr.vy < 6) { this.fx.ring([s.p[0], s.p[1] - 0.6, s.p[2]], [0.7, 1, 0.4, 0.8]); this.fx.near(s.p, 'bounce', 0.4); }
          if (pr.mode !== MODE.DIVE && s.mode === MODE.DIVE) this.fx.near(s.p, 'dive', 0.35);
          if (s.gr && !pr.gr && s.v[1] < 2 && pr.vy > 3) this.fx.near(s.p, 'jump', 0.2);
        }
      }
      this.remoteFx.set(s.slot, { mode: s.mode, gr: s.gr, vy: s.v[1] });
    }
    // rolling boulders
    for (const b of balls) {
      let st = this.ballRot.get(b.id);
      if (!st || Math.hypot(b.p[0] - st.last[0], b.p[2] - st.last[2]) > 6) { st = { q: [0, 0, 0, 1], last: b.p.slice() }; this.ballRot.set(b.id, st); }
      const dx = b.p[0] - st.last[0], dz = b.p[2] - st.last[2], dl = Math.hypot(dx, dz);
      if (dl > 1e-4) st.q = qt.norm(qt.mul(qt.axis([dz / dl, 0, -dx / dl], dl / 1.3), st.q));
      st.last = b.p.slice(); b.q = st.q;
    }
    // ---- camera ----
    const ph = g.phase;
    let spect = null;
    if (ph === PHASE.INTRO && g.introStart && g.level.cam) this.cam.intro((performance.now() - g.introStart) / (TIMING.intro * 1000), g.level.cam);
    else if (own) this.cam.follow(dt, own.p, own.v, g.world, this.input.enabled ? inp : { camDX: 0, camDY: 0 }, Math.floor(worldTick));
    else if (out.length) {
      let tgt = out.find((s) => s.slot === this.spectate);
      if (!tgt) {
        const L = g.level;
        tgt = out.reduce((a, b) => (L.type === 'race' ? b.p[2] > a.p[2] : L.type === 'final' ? b.p[1] + b.p[2] * 0.2 > a.p[1] + a.p[2] * 0.2 : Math.random() < 0.02) ? b : a, out[0]);
        this.spectate = tgt.slot;
      }
      const r = g.roster.get(tgt.slot); spect = r ? r.name : '…';
      this.cam.follow(dt, tgt.p, tgt.v, g.world, inp, Math.floor(worldTick));
      this.ui.touch(false);
    }
    // ---- crown ----
    let crown = null;
    if (g.level.type === 'final') {
      if (g.winner < 0) crown = crownAt(worldTime);
      else { const w = beans.find((b) => b.slot === g.winner); crown = w ? [w.p[0], w.p[1] + 1.55, w.p[2]] : crownAt(worldTime); }
    }
    this.scene.renderGame(this.cam, dt, { worldTime, beans, balls, crown, debris: g.debris, tileStates: (d) => g.tileStates(d), doorStates: (d) => g.doorStates(d), focus: own ? own.p : this.cam.look });
    // ---- nametags ----
    const tags = [];
    if (settings.nametags && ph !== PHASE.INTRO) {
      const R = this.scene.R;
      const list = beans.filter((b) => b.slot !== g.you).map((b) => ({ b, d: Math.hypot(b.p[0] - eye[0], b.p[1] - eye[1], b.p[2] - eye[2]) })).filter((x) => x.d < 34).sort((a, b) => a.d - b.d).slice(0, 24);
      for (const { b, d } of list) {
        const pr = R.project([b.p[0], b.p[1] + 1.2, b.p[2]]);
        if (pr.behind || pr.z > 1) continue;
        tags.push({ name: g.roster.get(b.slot).name, x: pr.x, y: pr.y, s: clamp(1.25 - d / 34, 0.55, 1) });
      }
    }
    this.ui.nametags(tags);
    // ---- HUD (throttled) ----
    if (performance.now() - this.lastHud > 100) {
      this.lastHud = performance.now();
      if (ph === PHASE.LOBBY) this.ui.lobbyTick(g); else this.ui.hud(g, own ? null : spect);
    }
  }
}

const app = new App();
window.CG = app; // debug / test hook
app.boot();
