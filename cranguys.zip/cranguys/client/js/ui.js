// CranGuys — UI controller (DOM): menu, locker, shop, settings, account, lobby, HUD, banners, results, podium, rewards.
import { $, $$, el, esc, fmt, clock, settings, saveSettings, beanLook, isTouch } from './util.js';
import { CATALOG, itemById, RARITY, slotCategory, XP_PER_LEVEL, levelForXp } from '../../shared/cosmetics.js';
import { LEVELS } from '../../shared/levels/index.js';
import { PHASE } from '../../shared/config.js';

const HAT_EMOJI = ['⛔', '🥳', '👑', '🐰', '🧢', '😇', '🎩', '🚧', '🪖', '👨‍🍳', '🍒', '📡', '🌼', '🧶', '🏴‍☠️', '🎧'];
const TYPE = { race: { label: 'RACE', icon: 'fa-flag-checkered', col: '#22c8ff' }, survival: { label: 'SURVIVAL', icon: 'fa-shapes', col: '#ff2e88' }, final: { label: 'FINAL', icon: 'fa-crown', col: '#ffb300' }, lobby: { label: 'LOBBY', icon: 'fa-umbrella-beach', col: '#a66bff' } };
const TIPS = [
  'Dive (Ctrl / DIVE) to belly-flop under high sweepers.', 'Hold GRAB at a wall’s edge to climb up ledges.', 'Not every door breaks — follow the crowd!',
  'Hop between tiles in Tile Tumble: running wastes floor.', 'Jump the low lasers, dive under the high ones.', 'Bumpers bounce you — use them, or avoid them.',
  'Grab other beans to slow them down (it’s allowed!).', 'Win a show to unlock the Royal Crown hat!', 'Bouncy pads launch you over gaps — keep your speed up.',
];

function faceSVG(k) {
  const eye = { 0: '<ellipse cx="17" cy="15" rx="2.6" ry="3.8" fill="#2a1050"/><ellipse cx="27" cy="15" rx="2.6" ry="3.8" fill="#2a1050"/>',
    1: '<path d="M14 16q3-5 6 0M24 16q3-5 6 0" stroke="#2a1050" stroke-width="2.4" fill="none" stroke-linecap="round"/>',
    2: '<path d="M14 15h6M24 15h6" stroke="#2a1050" stroke-width="2.4" stroke-linecap="round"/>',
    3: '<rect x="11" y="11" width="22" height="7" rx="3" fill="#1d1033"/><path d="M14 13l4 0" stroke="#fff" stroke-width="1.4"/>',
    4: '<path d="M17 18l-3.5-3.5a2 2 0 013.5-2 2 2 0 013.5 2z M27 18l-3.5-3.5a2 2 0 013.5-2 2 2 0 013.5 2z" fill="#ff3d7a"/>',
    5: '<ellipse cx="17" cy="16" rx="2.4" ry="3.2" fill="#2a1050"/><ellipse cx="27" cy="16" rx="2.4" ry="3.2" fill="#2a1050"/><path d="M13 10l7 2.5M31 10l-7 2.5" stroke="#2a1050" stroke-width="2.2" stroke-linecap="round"/>',
    6: '<ellipse cx="17" cy="15" rx="2.6" ry="3.8" fill="#2a1050"/><path d="M24 16q3-5 6 0" stroke="#2a1050" stroke-width="2.4" fill="none" stroke-linecap="round"/>',
    7: '<path d="M17 11l1.2 2.6 2.8.3-2.1 1.9.6 2.8-2.5-1.4-2.5 1.4.6-2.8-2.1-1.9 2.8-.3z M27 11l1.2 2.6 2.8.3-2.1 1.9.6 2.8-2.5-1.4-2.5 1.4.6-2.8-2.1-1.9 2.8-.3z" fill="#ffb300"/>' }[k] || '';
  return `<svg viewBox="0 0 44 30" width="46"><ellipse cx="22" cy="15" rx="17" ry="11" fill="#fff3ec" stroke="#2a1050" stroke-width="2"/>${eye}</svg>`;
}
function patternCSS(k, a, b) {
  return [a, `repeating-linear-gradient(0deg, ${a} 0 8px, ${b} 8px 16px)`, `radial-gradient(${b} 28%, transparent 31%) 0 0/14px 14px, ${a}`,
    `linear-gradient(135deg, ${b} 25%, transparent 25%) -7px 0/14px 14px, linear-gradient(225deg, ${b} 25%, transparent 25%) -7px 0/14px 14px, ${a}`,
    `conic-gradient(${a} 25%, ${b} 0 50%, ${a} 0 75%, ${b} 0) 0 0/16px 16px`, `linear-gradient(90deg, ${b} 50%, ${a} 50%)`,
    `radial-gradient(circle at 30% 30%, ${b} 12%, transparent 14%) 0 0/16px 16px, ${a}`, `repeating-conic-gradient(${a} 0 30deg, ${b} 30deg 60deg)`,
    `linear-gradient(0deg, ${a}, ${b})`, `radial-gradient(circle at 35% 40%, ${b} 18%, transparent 20%) 0 0/18px 18px, ${a}`][k] || a;
}
export function itemIcon(it, look) {
  if (!it) return '';
  const A = look ? look.css : '#ff7ab8', B = look ? look.css2 : '#fff';
  if (it.slot === 'color') return `<div class="ic" style="background:${it.hex === 'rainbow' ? 'conic-gradient(#ff5fa2,#ffd23f,#40e0a8,#36b9ff,#b07bff,#ff5fa2)' : it.hex}"></div>`;
  if (it.slot === 'pattern') return `<div class="ic" style="background:${patternCSS(it.k, A.startsWith('linear') ? '#ff7ab8' : A, B)}"></div>`;
  if (it.slot === 'face') return `<div class="ic" style="background:${A.startsWith('linear') ? '#ff7ab8' : A}">${faceSVG(it.k)}</div>`;
  return `<div class="ic">${HAT_EMOJI[it.k] || '❓'}</div>`;
}
const priceHTML = (p) => (p.c ? `<span class="price"><i class="fa-solid fa-crown" style="color:#ffb300"></i>${p.c}</span>` : `<span class="price"><span class="ico-berry"></span>${fmt(p.b)}</span>`);

export class UI {
  constructor(app) {
    this.app = app; this.screen = null; this.lockerTab = 'color'; this.colorSlot = 'color'; this.feedItems = [];
    this.tags = []; this.lobbyChips = new Map();
    document.addEventListener('click', (e) => {
      const go = e.target.closest('[data-go]'); if (go) { this.app.sound.play('click'); this.app.goto(go.dataset.go); return; }
      const act = e.target.closest('[data-act]'); if (act) { this.app.sound.play('click'); this.action(act.dataset.act, act); }
    });
    $$('.mode-toggle button').forEach((b) => b.addEventListener('click', () => { this.app.sound.play('click'); this.app.setMode(b.dataset.mode); }));
    $('#playBtn').addEventListener('click', () => this.app.play());
    $('#cancelBtn').addEventListener('click', () => this.app.cancel());
    $('#lobbyToggle').addEventListener('click', () => $('.lobby-panel').classList.toggle('collapsed'));
    $$('#colorSlot button').forEach((b) => b.addEventListener('click', () => { this.colorSlot = b.dataset.slot; $$('#colorSlot button').forEach((x) => x.classList.toggle('on', x === b)); this.renderLocker(); }));
    this.renderShowCard();
  }

  action(a) {
    const app = this.app;
    switch (a) {
      case 'settings': return this.settingsModal();
      case 'account': return this.accountModal();
      case 'rename': return this.renameModal();
      case 'closeModal': return this.closeModal();
      case 'leave': return app.leaveShow();
      case 'leaveAsk': return this.confirm('Leave this show?', 'You’ll still get rewards for the rounds you’ve qualified from.', 'Leave', () => app.leaveShow());
      case 'specPrev': return app.cycleSpectate(-1);
      case 'specNext': return app.cycleSpectate(1);
      case 'toMenu': this.hideOverlay('rewards'); return app.goto('menu');
      case 'playAgain': this.hideOverlay('rewards'); app.goto('menu'); return app.play();
    }
  }

  // ---------------- screens ----------------
  show(id) {
    this.screen = id;
    for (const s of $$('.screen')) s.classList.toggle('show', s.id === id);
    $$('.tabs-main .tab').forEach((t) => t.classList.toggle('on', t.dataset.go === id));
    if (id === 'menu' || id === 'locker' || id === 'shop') { $('#menu').classList.add('show'); for (const x of $$('#menu > *')) x.style.visibility = id === 'menu' ? '' : 'hidden'; $('#menu .tabs-main').style.visibility = ''; }
    if (id === 'locker') this.renderLocker();
    if (id === 'shop') this.renderShop();
  }
  overlay(id, on = true) { $('#' + id).classList.toggle('show', on); }
  hideOverlay(id) { this.overlay(id, false); }
  touch(on) { $('#touch').classList.toggle('hide', !(on && (isTouch() || settings.forceTouch))); $('#touch').classList.toggle('show', on && (isTouch() || settings.forceTouch)); }
  boot(p, msg) { $('#boot .loadbar i').style.width = Math.round(p * 100) + '%'; if (msg) $('#boot .boot-msg').textContent = msg; }

  toast(msg, kind = '') {
    const t = el('div', { class: 'toast ' + kind }, msg); $('#toasts').append(t);
    setTimeout(() => { t.style.transition = 'opacity .3s'; t.style.opacity = '0'; setTimeout(() => t.remove(), 320); }, 2600);
  }

  // ---------------- profile & menu ----------------
  setProfile(p) {
    if (!p) return;
    this.profile = p;
    $$('.cur.berries b').forEach((b) => (b.textContent = fmt(p.berries)));
    $$('.cur.crowns b').forEach((b) => (b.textContent = fmt(p.crowns)));
    $('.lvl-n').textContent = p.level; $('.topbar .xpbar i').style.width = ((p.xp % XP_PER_LEVEL) / XP_PER_LEVEL) * 100 + '%';
    $('.nameplate .nm').textContent = p.name;
    if (this.screen === 'locker') this.renderLocker();
  }
  renderShowCard() {
    const rounds = ['whirlway', 'tiletumble', 'crownpeak'].map((id) => { const L = LEVELS[id], T = TYPE[L.type]; return `<div class="sc-round" style="background:${T.col}"><i class="fa-solid ${T.icon}"></i><b>${L.name}</b>${T.label}</div>`; });
    $('.sc-rounds').innerHTML = rounds.join('');
  }
  setMode(mode, onlineAvailable) {
    $$('.mode-toggle button').forEach((b) => { b.classList.toggle('on', b.dataset.mode === mode); if (b.dataset.mode === 'online') b.disabled = !onlineAvailable; });
  }
  setStatus(text, ok = true) { $('.pb-status').textContent = text; $('#playBtn').classList.toggle('off', !ok); }
  setSearching(on, text) {
    const b = $('#playBtn'); b.classList.toggle('searching', on);
    $('.pb-main').textContent = on ? 'FINDING SHOW' : 'PLAY';
    if (text) this.setStatus(text);
    $('#cancelBtn').classList.toggle('hide', !on);
  }

  // ---------------- locker ----------------
  renderLocker() {
    const p = this.profile; if (!p) return;
    const tabs = [['color', 'Colours', 'fa-palette'], ['pattern', 'Patterns', 'fa-shapes'], ['face', 'Faces', 'fa-face-smile'], ['hat', 'Hats', 'fa-hat-cowboy']];
    $('#lockerTabs').innerHTML = tabs.map(([k, n, i]) => `<button data-tab="${k}" class="${k === this.lockerTab ? 'on' : ''}"><i class="fa-solid ${i}"></i>${n}</button>`).join('');
    $$('#lockerTabs button').forEach((b) => b.addEventListener('click', () => { this.app.sound.play('click'); this.lockerTab = b.dataset.tab; this.renderLocker(); }));
    $('#colorSlot').classList.toggle('hide', this.lockerTab !== 'color');
    const slot = this.lockerTab === 'color' ? this.colorSlot : this.lockerTab;
    const owned = new Set(p.owned), look = beanLook(p.loadout);
    const items = CATALOG.filter((i) => i.slot === this.lockerTab).sort((a, b) => (owned.has(b.id) - owned.has(a.id)) || Object.keys(RARITY).indexOf(a.rarity) - Object.keys(RARITY).indexOf(b.rarity));
    const g = $('#lockerGrid'); g.innerHTML = '';
    for (const it of items) {
      const own = owned.has(it.id), eq = p.loadout[slot] === it.id;
      const d = el('div', { class: `item r-${it.rarity} ${own ? '' : 'locked'} ${eq ? 'eq' : ''}`, html: itemIcon(it, look) + `<div class="nm">${esc(it.name)}</div>` });
      d.addEventListener('click', () => {
        if (!own) { this.app.sound.play('error'); return this.toast(`🔒 ${it.name} — look for it in the Shop!`); }
        this.app.sound.play('pop'); this.app.equip(slot, it.id);
      });
      g.append(d);
    }
  }

  // ---------------- shop ----------------
  async renderShop() {
    const p = this.profile; let s;
    try { s = await this.app.backend.shop(); } catch (e) { this.toast(e.message, 'bad'); return; }
    this.shopData = s;
    const owned = new Set(p.owned), look = beanLook(p.loadout);
    const f = itemById(s.featured);
    const fo = owned.has(f.id);
    $('#shopFeatured').innerHTML = `<div class="feat card"><div class="ic">${itemIcon(f, look).replace('class="ic"', 'class="ic2"')}</div><div><span class="tag">★ FEATURED · ${RARITY[f.rarity].name.toUpperCase()}</span><h3>${esc(f.name)}</h3><p style="margin:4px 0 10px;color:#4b2a86">${f.slot === 'hat' ? 'Hat' : f.slot === 'color' ? 'Bean colour' : f.slot === 'face' ? 'Face' : 'Pattern'}</p>${fo ? '<div class="owned-tag">OWNED</div>' : `<button class="btn yellow buy" data-id="${f.id}">${priceHTML(f.price)}</button>`}</div></div>`;
    const g = $('#shopGrid'); g.innerHTML = '';
    for (const id of s.items) {
      const it = itemById(id), own = owned.has(id);
      g.append(el('div', { class: 'sitem card', html: `<span class="rib" style="background:${RARITY[it.rarity].col}">${RARITY[it.rarity].name}</span>${itemIcon(it, look)}<div class="nm">${esc(it.name)}</div>${own ? '<div class="owned-tag">OWNED</div>' : `<button class="btn small buy" data-id="${id}">${priceHTML(it.price)}</button>`}` }));
    }
    $$('#shop .buy').forEach((b) => b.addEventListener('click', () => this.app.buy(b.dataset.id)));
    clearInterval(this.shopIv);
    const tick = () => { const ms = s.refreshAt - Date.now(); $('#shopTimer').textContent = ms > 0 ? `New items in ${Math.floor(ms / 3.6e6)}h ${Math.floor((ms % 3.6e6) / 6e4)}m` : 'Refreshing…'; };
    tick(); this.shopIv = setInterval(tick, 30000);
  }

  // ---------------- modals ----------------
  modal(html, onMount) { $('#modalBody').innerHTML = html; $('#modal').classList.add('show'); if (onMount) onMount($('#modalBody')); }
  closeModal() { $('#modal').classList.remove('show'); }
  confirm(title, text, yes, fn) {
    this.modal(`<h3>${esc(title)}</h3><p>${esc(text)}</p><div class="seg2"><button class="btn ghost" data-act="closeModal">Stay</button><button class="btn pink" id="cfYes">${esc(yes)}</button></div>`, (b) => $('#cfYes', b).addEventListener('click', () => { this.closeModal(); fn(); }));
  }
  renameModal() {
    const p = this.profile;
    this.modal(`<h3>Your bean name</h3><input class="field" id="nmIn" maxlength="16" value="${esc(p.name)}"><button class="btn yellow" id="nmOk" style="width:100%"><i class="fa-solid fa-check"></i> Save</button>`, (b) => {
      const go = async () => { try { await this.app.rename($('#nmIn', b).value); this.closeModal(); } catch (e) { this.toast(e.message, 'bad'); } };
      $('#nmOk', b).addEventListener('click', go); $('#nmIn', b).addEventListener('keydown', (e) => e.key === 'Enter' && go());
    });
  }
  settingsModal() {
    const S = settings;
    const sw = (k) => `<div class="switch ${S[k] ? 'on' : ''}" data-k="${k}"></div>`;
    const sl = (k, min, max, step) => `<input type="range" data-k="${k}" min="${min}" max="${max}" step="${step}" value="${S[k]}">`;
    this.modal(`<h3><i class="fa-solid fa-gear"></i> Settings</h3>
      <h4>Gameplay</h4>
      <div class="row"><label>Camera sensitivity</label>${sl('sens', 0.3, 2.5, 0.05)}</div>
      <div class="row"><label>Invert camera Y</label>${sw('invertY')}</div>
      <div class="row"><label>Auto-follow camera</label>${sw('autoCam')}</div>
      <div class="row"><label>Show nametags</label>${sw('nametags')}</div>
      <h4>Graphics</h4>
      <div class="row"><label>Quality</label><select data-k="quality"><option value="auto">Auto</option><option value="low">Low (fastest)</option><option value="medium">Medium</option><option value="high">High (shadows)</option></select></div>
      <div class="row"><label>Show FPS</label>${sw('fps')}</div>
      <h4>Audio</h4>
      <div class="row"><label>Master</label>${sl('master', 0, 1, 0.05)}</div>
      <div class="row"><label>Music</label>${sl('music', 0, 1, 0.05)}</div>
      <div class="row"><label>Effects</label>${sl('sfx', 0, 1, 0.05)}</div>
      <h4>Controls</h4>
      <div class="row"><label>Touch button size</label>${sl('touchSize', 0.75, 1.35, 0.05)}</div>
      <div class="keys"><span><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd></span><span>Move (camera-relative)</span><span><kbd>Space</kbd></span><span>Jump</span><span><kbd>Ctrl</kbd> / <kbd>C</kbd></span><span>Dive</span><span><kbd>Shift</kbd> / <kbd>E</kbd> (hold)</span><span>Grab beans &amp; ledges</span><span>Mouse / <kbd>J</kbd><kbd>L</kbd></span><span>Camera (click to lock mouse)</span><span>Gamepad</span><span>A jump · X dive · RT grab · sticks</span><span>Touch</span><span>Left stick · drag right side to look</span></div>
      <h4>Server</h4>
      <div class="row"><label>CranGuys server URL<br><small style="color:#4b2a86">Blank = this website</small></label></div>
      <input class="field" data-k="server" placeholder="https://your-cranguys.onrender.com" value="${esc(S.server)}">
      <p class="note">Changing the server reloads the game.</p>`, (b) => {
      $$('.switch', b).forEach((s) => s.addEventListener('click', () => { S[s.dataset.k] = !S[s.dataset.k]; s.classList.toggle('on', S[s.dataset.k]); saveSettings(); this.app.applySettings(); }));
      $$('input[type=range]', b).forEach((r) => r.addEventListener('input', () => { S[r.dataset.k] = +r.value; saveSettings(); this.app.applySettings(); }));
      const q = $('select[data-k=quality]', b); q.value = S.quality; q.addEventListener('change', () => { S.quality = q.value; saveSettings(); this.app.applySettings(); });
      const sv = $('input[data-k=server]', b); sv.addEventListener('change', () => { S.server = sv.value.trim(); saveSettings(); location.reload(); });
    });
  }
  async accountModal() {
    const app = this.app, p = this.profile, online = app.mode === 'online';
    let lb = [];
    try { lb = await app.backend.leaderboard(); } catch {}
    const stats = `<div class="seg2"><div class="note"><b>${p.wins}</b> wins</div><div class="note"><b>${p.shows}</b> shows</div><div class="note"><b>${p.finals}</b> finals</div><div class="note">Lv <b>${p.level}</b></div></div>`;
    let acct;
    if (!online) acct = `<p class="note"><i class="fa-solid fa-robot"></i> You’re playing offline. Your bean, Cranberries and items are saved on this device. Connect to a CranGuys server for online shows, accounts and the global leaderboard.</p>`;
    else if (p.guest) acct = `<p class="note">You’re a <b>guest</b>. Create a login to keep your bean on any device.</p>
      <input class="field" id="acU" placeholder="Username" maxlength="16" autocapitalize="off" autocomplete="username"><input class="field" id="acP" type="password" placeholder="Password (6+ characters)" autocomplete="current-password">
      <div class="seg2"><button class="btn mint" id="acReg"><i class="fa-solid fa-user-plus"></i> Create login</button><button class="btn ghost" id="acLog"><i class="fa-solid fa-right-to-bracket"></i> Sign in</button></div>`;
    else acct = `<p class="note">Signed in as <b>${esc(p.username)}</b>.</p><button class="btn ghost" id="acOut"><i class="fa-solid fa-right-from-bracket"></i> Sign out</button>`;
    this.modal(`<h3><i class="fa-solid fa-user"></i> ${esc(p.name)}</h3>${stats}<h4>Account</h4>${acct}<h4><i class="fa-solid fa-trophy"></i> Top beans</h4><div class="lb">${lb.length ? lb.map((r, i) => `<div><b>#${i + 1}</b><span>${esc(r.name)}</span><span><i class="fa-solid fa-crown" style="color:#ffb300"></i> ${r.wins}</span></div>`).join('') : '<p class="note">No shows played yet — be the first!</p>'}</div>`, (b) => {
      const U = () => $('#acU', b).value.trim(), P = () => $('#acP', b).value;
      const run = (fn) => async () => { try { await fn(); this.closeModal(); this.toast('Welcome, ' + this.profile.name + '!', 'good'); } catch (e) { this.toast(e.message, 'bad'); } };
      if ($('#acReg', b)) $('#acReg', b).addEventListener('click', run(() => app.account('register', U(), P())));
      if ($('#acLog', b)) $('#acLog', b).addEventListener('click', run(() => app.account('login', U(), P())));
      if ($('#acOut', b)) $('#acOut', b).addEventListener('click', run(() => app.account('logout')));
    });
  }

  // ---------------- lobby ----------------
  lobbyInit(game) {
    this.lobbyChips.clear();
    const g = $('#lobbyGrid'); g.innerHTML = '';
    for (let i = 0; i < 60; i++) g.append(el('div', { class: 'chip empty' }, el('div', { class: 'bn' }), el('span', {}, '…')));
    for (const r of game.roster.values()) if (r.status !== 'gone') this.lobbyJoin(r, true);
    $('#lobbyMax').textContent = 60;
    this.tipI = Math.floor(Math.random() * TIPS.length); $('#lobbyTip').textContent = '💡 ' + TIPS[this.tipI];
  }
  lobbyJoin(r, silent) {
    if (!r || this.lobbyChips.has(r.slot) || this.app.game?.phase !== PHASE.LOBBY) return;
    const chips = $$('#lobbyGrid .chip.empty'); const c = chips[0]; if (!c) return;
    c.className = 'chip' + (r.slot === this.app.game.you ? ' me' : '');
    c.querySelector('.bn').style.background = r.look.css; c.querySelector('span').textContent = r.name;
    this.lobbyChips.set(r.slot, c);
    if (!silent) this.app.sound.play('join', 0.6);
  }
  lobbyLeave(slot) { const c = this.lobbyChips.get(slot); if (c) { c.className = 'chip empty'; c.querySelector('.bn').style.background = ''; c.querySelector('span').textContent = '…'; this.lobbyChips.delete(slot); } }
  lobbyTick(game) {
    $('#lobbyTimer').textContent = clock(game.timeLeft());
    let n = 0; for (const r of game.roster.values()) if (r.status !== 'gone') n++;
    $('#lobbyFill').textContent = n;
    if (Math.floor(performance.now() / 6000) !== this.tipT) { this.tipT = Math.floor(performance.now() / 6000); $('#lobbyTip').textContent = '💡 ' + TIPS[(this.tipI + this.tipT) % TIPS.length]; }
  }

  // ---------------- in-show HUD ----------------
  hudRound(game) {
    const L = game.level, T = TYPE[L.type];
    $('#hRoundN').textContent = `ROUND ${game.round + 1} · ${T.label}`; $('#hRoundName').textContent = L.name;
    $('#hFeed').innerHTML = ''; this.feedItems = [];
    $('#hObjective').textContent = '';
  }
  hud(game, spectName) {
    const L = game.level, c = game.counts, k = $('#hCounter .k'), b = $('#hCounter b');
    let key, val;
    if (L.type === 'race') { key = 'QUALIFIED'; val = `${c.q} / ${c.Q || game.Q}`; }
    else if (L.type === 'survival') { key = 'BEANS LEFT'; val = `${c.alive} → ${c.Q || game.Q}`; }
    else { key = 'GRAB THE CROWN'; val = `${c.alive} left`; }
    if (val !== this._cv) { if (this._cv) $('#hCounter').classList.remove('bump'), void $('#hCounter').offsetWidth, $('#hCounter').classList.add('bump'); this._cv = val; k.textContent = key; b.textContent = val; }
    const left = game.phase === PHASE.PLAY ? Math.max(0, game.timeLeft() - 2) : game.phase === PHASE.COUNTDOWN || game.phase === PHASE.INTRO ? L.timeLimit : 0;
    $('#hTimer').textContent = clock(left);
    $('.h-timer').classList.toggle('low', game.phase === PHASE.PLAY && left < 15);
    const sp = $('#spectate');
    sp.classList.toggle('hide', !spectName);
    if (spectName) $('#specName').textContent = spectName;
  }
  objective(text) { $('#hObjective').textContent = text || ''; }
  feed(text, kind = '') {
    const d = el('div', { class: kind }, text); $('#hFeed').prepend(d);
    this.feedItems.push(d); if (this.feedItems.length > 5) this.feedItems.shift().remove();
    setTimeout(() => { d.style.transition = 'opacity .5s'; d.style.opacity = 0; setTimeout(() => d.remove(), 500); }, 4000);
  }
  nametags(list) {
    const root = $('#nametags');
    while (this.tags.length < list.length) { const t = el('div', { class: 'tag' }); root.append(t); this.tags.push(t); }
    for (let i = 0; i < this.tags.length; i++) {
      const t = this.tags[i], d = list[i];
      if (!d) { if (t.style.opacity !== '0') t.style.opacity = '0'; continue; }
      if (t._n !== d.name) { t.textContent = d.name; t._n = d.name; }
      t.style.opacity = '1';
      t.style.transform = `translate(${d.x}px, ${d.y}px) translate(-50%, -100%) scale(${d.s})`;
    }
  }
  fps(text) { const f = $('#fps'); f.classList.toggle('hide', !settings.fps); if (settings.fps) f.textContent = text; }

  // ---------------- round flow ----------------
  intro(m, level) {
    const T = TYPE[level.type];
    $('#icRound').textContent = level.type === 'final' ? 'THE FINAL' : `ROUND ${m.i + 1} OF ${m.n}`;
    const ty = $('#icType'); ty.textContent = T.label; ty.className = 'ic-type ' + level.type;
    $('#icName').textContent = level.name; $('#icDesc').textContent = level.desc; $('#icTip').textContent = level.tip;
    $('#icQ').textContent = level.type === 'race' ? `🏁 ${m.Q} of ${m.count} beans qualify` : level.type === 'survival' ? `💥 Survive until only ${m.Q} remain` : `👑 ${m.count} finalists · 1 crown`;
    this.overlay('intro', true);
  }
  countdown(n) {
    const c = $('#countdown'); c.innerHTML = '';
    const s = el('span', { class: n === 'GO!' ? 'go' : '' }, String(n)); c.append(s);
    setTimeout(() => { if (c.contains(s)) s.remove(); }, 1000);
  }
  banner(text, kind = 'info', sub = '', stay = false) {
    const b = $('#banner'); b.innerHTML = '';
    const d = el('div', { class: `bn ${kind} ${stay ? 'stay' : ''}`, html: esc(text) + (sub ? `<small>${esc(sub)}</small>` : '') }); b.append(d);
    clearTimeout(this.bannerT); if (!stay) this.bannerT = setTimeout(() => { if (b.contains(d)) d.remove(); }, 2700);
  }
  clearBanner() { $('#banner').innerHTML = ''; }
  results(m, game) {
    const me = game.you, q = m.qualified.includes(me), x = m.eliminated.includes(me);
    const L = game.level;
    $('#resTitle').textContent = L.type === 'final' ? 'THE FINAL' : `ROUND ${m.round + 1} · ${L.name.toUpperCase()}`;
    const you = $('#resYou'); you.className = 'res-you ' + (q ? 'q' : x ? 'x' : 's');
    you.textContent = q ? (L.type === 'final' ? '👑 YOU WON!' : '✅ YOU QUALIFIED!') : x ? '❌ ELIMINATED' : '👀 SPECTATING';
    $('#resQn').textContent = m.qualified.length;
    $('#resGrid').innerHTML = m.qualified.map((s) => { const r = game.roster.get(s); return r ? `<div class="chip ${s === me ? 'me' : ''}"><div class="bn" style="background:${r.look.css}"></div><span>${esc(r.name)}</span></div>` : ''; }).join('');
    $('#resNext').innerHTML = m.next ? `NEXT UP: <b>${LEVELS[m.next].name}</b>` : m.qualified.length ? 'TO THE PODIUM! 🏆' : 'NO WINNER THIS TIME';
    this.overlay('results', true);
  }
  podium(m, game) {
    $('#podName').textContent = m.winner ? m.winner.n : 'Nobody';
    $('#podPlaces').innerHTML = (m.top || []).slice(1).map((s, i) => { const r = game.roster.get(s); return r ? `<div>${i === 0 ? '🥈' : '🥉'} ${esc(r.name)}</div>` : ''; }).join('');
  }
  rewards(m, profile) {
    const won = m && m.won, rounds = m ? m.rounds : 0, rw = (m && m.reward) || { berries: 0, crowns: 0, xp: 0 };
    $('#rwHead').textContent = won ? 'CROWNED!' : 'SHOW COMPLETE';
    $('#rwSub').textContent = won ? 'You won the whole show! 👑' : rounds === 0 ? 'Eliminated in round 1 — next time!' : `You qualified from ${rounds} round${rounds > 1 ? 's' : ''}!`;
    const rows = [[`<span class="ico-berry"></span> Cranberries`, '+' + fmt(rw.berries + (rw.bonus || 0))], ['<i class="fa-solid fa-star" style="color:#22c8ff"></i> Experience', '+' + fmt(rw.xp)]];
    if (rw.crowns) rows.push(['<i class="fa-solid fa-crown"></i> Crowns', '+' + rw.crowns]);
    $('#rwRows').innerHTML = rows.map(([a, b]) => `<div class="rw-row">${a}<b>${b}</b></div>`).join('');
    $$('#rwRows .rw-row').forEach((r, i) => setTimeout(() => { r.classList.add('in'); this.app.sound.play('pop'); }, 350 + i * 280));
    if (profile) { $('#rwLvl').textContent = profile.level; setTimeout(() => ($('#rwXp').style.width = ((profile.xp % XP_PER_LEVEL) / XP_PER_LEVEL) * 100 + '%'), 600); }
    $('#rwUp').classList.toggle('hide', !(rw.levelUp > 0));
    this.overlay('rewards', true);
  }
}
