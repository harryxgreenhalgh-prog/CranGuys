# CranGuys 🫘👑

A 60-player jelly-bean party battle royale for the browser, playable on iPad, desktop and phone. You race, survive collapsing floors and climb a boulder-filled mountain to grab the crown.

This is the whole game in one repo with **no dependencies**:

- **Server:** a Node.js server that runs the game authoritatively.
  - Its WebSocket implementation is hand-written.
  - Data is stored in SQLite using Node's built-in `node:sqlite`.
  - Accounts and the economy are served over REST.
  - It handles matchmaking and fills empty spots with bots.
- **Client:** a WebGL2 game client.
  - It uses client-side prediction and reconciles against the server.
  - It shares the exact same physics code as the server.
- **Offline build:** a single HTML file that runs a full show against 59 bots with no server at all.

| | | |
|---|---|---|
| ![Menu](docs/menu.png) | ![Race](docs/race.png) | ![Tile Tumble](docs/tiletumble.png) |
| ![Locker](docs/locker.png) | ![Shop](docs/shop.png) | ![Podium](docs/podium.png) |

```
npm start            # http://localhost:8080  (Node 22.5+, nothing to install)
npm test             # physics, netcode, economy, full 60-bot show
npm run test:e2e     # real server + real WebSocket clients + REST economy
npm run build        # dist/cranguys.html (self-contained offline build)
```

---

## The show

| Round | Type | What happens |
|---|---|---|
| **Whirl Way** | Race | Conveyor climb → spinning sweeper arms (jump the low ones, dive under the high ones) → **Door Dash** (only some doors break) → ice chute → bouncy pads over slime → spinning discs → bumper field → finish arch. About 50% qualify. |
| **Tile Tumble** | Survival | Four stacked layers of hex tiles; each tile drops 1 s after anything touches it. Spinning laser beams and travelling **laser walls** sweep each layer: jump the low walls, dive under the high ones. The round ends when only ~30% remain. |
| **Crown Peak** | Final | An ascending mountain: bumpers, a sweeper, downhill conveyors and bouncy pads. You grab a ledge to scale the terrace wall while **boulders** roll down at you. At the summit a **moving crown** circles and bobs, and you jump and grab it to win. |

Every show starts in the **Waiting Room**, a lobby island you can run around on while the player grid fills and the countdown runs. Bots trickle in during the last seconds so there are always 60 beans. A show ends on a **3D podium**, then the **rewards** screen.

## Controls

| | Keyboard / mouse | Gamepad | Touch (iPad) |
|---|---|---|---|
| Move | WASD / arrows (camera-relative) | Left stick | Floating stick (left half) |
| Camera | Mouse (click to lock) or drag, J/L | Right stick | Drag on the right half |
| Jump | Space | A | **JUMP** |
| Dive | Ctrl / C | X (or B) | **DIVE** |
| Grab (hold) | Shift / E | RT / RB | **GRAB** |

Grab works on other beans (it slows them down) and on ledges: hold it while you jump at a wall edge, then press forward or jump to climb.

## Architecture

```mermaid
flowchart LR
  subgraph Browser["Client (WebGL2)"]
    IN[Input: keys / pad / touch] --> PRED[Prediction: shared character.js]
    PRED -->|"30 Hz binary inputs (9 B)"| WS1((WebSocket))
    WS1 -->|"15 Hz snapshots (~800 B)"| REC[Reconcile: rewind + replay]
    REC --> PRED
    WS1 --> INTERP[Interpolate 59 others +133 ms]
    PRED --> R[Renderer: shadows, plastic, skinned beans]
    INTERP --> R
    UI[Menus, Locker, Shop, HUD] -->|REST| API
  end
  subgraph Server["Node server (authoritative)"]
    WS2((WS)) --> MM[Matchmaker queue]
    MM --> M1[Match: lobby → race → survival → final → podium]
    M1 --> SIM[30 Hz sim · 3 substeps · bots]
    SIM -->|"snapshots + events"| WS2
    M1 -->|rewards| ECO[Economy + ledger]
    API[REST: auth, profile, locker, shop, leaderboard] --> ECO
    ECO --> DB[(SQLite)]
  end
  WS1 <--> WS2
```

### Netcode
- **Fixed tick:** 30 Hz with 3 physics substeps. Every moving obstacle (sweepers, discs, lasers, the crown) is a *pure function of time*, so the server, client prediction and bots all agree on where everything is at any tick.
- **Inputs:** each input is stamped with the tick it's meant for. The server buffers it and applies it on exactly that tick, then reports back how far ahead the client is. The client speeds up or slows down its prediction lead to keep about 2–3 ticks of buffer (the Overwatch-style approach).
- **Reconciliation:** snapshots carry the player's full authoritative state (35 floats). The client rewinds to it and replays its unacknowledged inputs. Any visual error decays smoothly, so corrections don't pop.
- **Remote beans and boulders:** they're interpolated about 4 ticks (133 ms) in the past, with a short extrapolation if a packet is late.
- **Server-only state:** falling tiles and breaking doors arrive as tick-stamped events. Which doors are breakable is a **server secret**, so clients only find out when a door breaks.
- **Anti-cheat:** the server is authoritative over movement. Inputs are clamped and rate-limited. Rewards are computed only on the server and stored in an idempotent ledger.
- **Bandwidth:** about 13 KB/s down and 0.3 KB/s up per player. One 60-bean show costs the server about 0.45 ms of CPU per tick.

### Physics (`shared/character.js`)
The bean is a capsule when upright and a sphere when diving or ragdolled. It collides against boxes, cylinders, spheres and capsules (`shared/collide.js`) through a spatial grid. The controller handles:
- **Movement:** camera-relative running with acceleration curves, slower uphill, coyote time and jump buffering.
- **Dive and recovery:** dive into a belly-slide, then get up, or recover early with a hop.
- **Ledges:** detect and grab a ledge, then climb up.
- **Grabbing players:** they're slowed and tethered.
- **Ragdoll:** tumbling with bounce, plus an automatic recovery timer (settle → get up).
- **Moving platforms:** they carry you.
- **Surfaces:** ice, conveyors, bouncy pads and bumpers.
- **Respawning:** checkpoint respawns in races.

### Database
SQLite tables:
- `users`: guest or username, scrypt hash, token version.
- `profiles`: berries, crowns, xp, stats, loadout.
- `inventory`
- `ledger`: every balance change, unique per `(user, ref)` so rewards and purchases can never double-apply.
- `matches`: history.

If `node:sqlite` is missing, the server falls back to an atomic JSON file store behind the same interface.

## Economy & cosmetics
- **Cranberries 🍒:** earned every show (more for each round you qualify from). **Crowns 👑:** earned for wins.
- **Items:** 17 colours (including Gold and animated Rainbow), 10 patterns, 8 faces and 16 hats, all procedural (no image assets).
- **Daily shop:** six items plus one featured Legendary, the same for everyone each UTC day. Purchases are atomic transactions.
- **Unlocks:** your first win unlocks the Royal Crown hat. Levelling up (1,000 XP per level) pays a bonus.

## Deploying (so friends can play online)
The server is one process with no dependencies, so any Node 22 host works.

**Render (free, works from an iPad browser):**
1. Put this folder in a GitHub repo.
2. On render.com: **New + → Blueprint** → choose the repo. `render.yaml` does the rest.
3. Open the URL in Safari → Share → **Add to Home Screen** for full-screen play.

Free instances sleep when idle and don't keep their disk. For accounts that persist, use a paid plan with the disk block in `render.yaml` uncommented.

**Docker / Fly.io / Railway:**
```
docker build -t cranguys . && docker run -p 8080:8080 -v cranguys-data:/data cranguys
```

**Environment variables** (see `.env.example`): `PORT`, `CRANGUYS_SECRET`, `DATA_DIR`, `MAX_PLAYERS`, `MAX_HUMANS`, `LOBBY_SECONDS`, `BOT_FILL`, `CORS_ORIGINS`.

The single-file build (`dist/cranguys.html`) can also join a server: open **Settings → Server** and paste your server URL. That server needs `CORS_ORIGINS` set to the page's origin.

## API
REST (JSON; `Authorization: Bearer <token>` where marked 🔒):

| Method | Path | |
|---|---|---|
| POST | `/api/auth/guest` `{name?}` | New guest → `{token, profile}` |
| POST | `/api/auth/register` 🔒 `{username, password}` | Upgrade guest to a login |
| POST | `/api/auth/login` `{username, password}` | `{token, profile}` |
| GET | `/api/me` 🔒 | Profile, balances, inventory, loadout |
| POST | `/api/me/name` 🔒 `{name}` | Rename |
| POST | `/api/locker/equip` 🔒 `{loadout}` | Equip owned items |
| GET | `/api/shop` | Today's rotation |
| POST | `/api/shop/buy` 🔒 `{itemId}` | Atomic purchase |
| GET | `/api/leaderboard` | Top 20 by wins |
| GET | `/api/history` 🔒 | Ledger history |
| GET | `/api/status` · `/healthz` | Live counts / health |

**WebSocket `/ws`:**

| From | Message | Format |
|---|---|---|
| Client | `{t:'hello', token, v}` | JSON |
| Client | `{t:'queue'}`, `{t:'unqueue'}`, `{t:'leave'}`, `{t:'ping'}` | JSON |
| Client | Input: `[2][epoch][tick u32][mx i8][mz i8][buttons]` | Binary |
| Server | `welcome`, `mm` (live matchmaking status), `match` (full state / reconnect) | JSON |
| Server | `join`, `leave`, `round`, `phase`, `ev` (tiles, doors, qualify, eliminate, crown) | JSON |
| Server | `roundEnd`, `results`, `podium`, `end`, `reward` | JSON |
| Server | Snapshot: header + own state (f32 × 35) + 13 B per bean + 10 B per boulder | Binary |

## Project layout
```
shared/   isomorphic game code (runs on server, client and offline)
  config.js  math.js  collide.js  world.js  character.js  protocol.js
  game.js (Match)  bots.js  cosmetics.js  names.js  levels/{whirlway,tiletumble,crownpeak,lobby,kit}.js
server/   index.js  http.js (REST + gzip static)  ws.js (RFC 6455)  gameserver.js (sessions, queue, loop)
          db.js (SQLite/JSON)  auth.js (HS256 tokens, scrypt)  economy.js
client/   index.html  style.css  js/{main,play,net,api,scene,gl,geo,bean,camera,input,audio,ui,util}.js
tools/    build.js — bundles the client into dist/cranguys.html
tests/    *.test.js (node:test) · server-e2e.mjs · browser-*.cjs (Playwright screenshots)
```

## Tuning
- **Feel:** `shared/config.js → PHYS` (run speed, jump, dive, ragdoll, grab).
- **Timings:** `TIMING` (lobby, intro, countdown, results).
- **Levels:** pure data in `shared/levels/*`. Colliders carry their own look (`vis`), and meshes are generated from them.
- **Bot skill:** `shared/bots.js`.

MIT licence. CranGuys is an original game inspired by the party-royale genre.
